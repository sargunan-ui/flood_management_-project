@echo off
title Push AquaSentinel AI to GitHub
echo ======================================================================
echo   Pushing AquaSentinel AI to GitHub Repository:
echo   https://github.com/itssargu/Neuro-hackathon
echo ======================================================================
echo.

set GIT_CMD=git
where git >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Users\sargunan\AppData\Local\Programs\MinGit\cmd\git.exe" (
        set GIT_CMD="C:\Users\sargunan\AppData\Local\Programs\MinGit\cmd\git.exe"
    )
)

echo Please enter your GitHub Personal Access Token (PAT) below.
echo (If you do not have one yet, generate one at: https://github.com/settings/tokens)
echo.
set /p TOKEN="GitHub Token (PAT): "

if "%TOKEN%"=="" (
    echo.
    echo Attempting direct push...
    %GIT_CMD% push -u https://github.com/itssargu/Neuro-hackathon.git main --force
) else (
    echo.
    echo Pushing with your token...
    %GIT_CMD% push -u https://%TOKEN%@github.com/itssargu/Neuro-hackathon.git main --force
)

echo.
if %ERRORLEVEL% EQU 0 (
    echo ======================================================================
    echo   SUCCESS! The project was pushed to:
    echo   https://github.com/itssargu/Neuro-hackathon
    echo ======================================================================
) else (
    echo [ERROR] Push failed. Please verify your token has 'repo' permissions.
)
echo.
pause
