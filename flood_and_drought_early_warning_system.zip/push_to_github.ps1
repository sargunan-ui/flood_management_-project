# AquaSentinel AI - Interactive Push to GitHub Script
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "   Pushing AquaSentinel AI to GitHub: itssargu/Neuro-hackathon       " -ForegroundColor White
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$gitExe = "git"
if (-not (Get-Command "git" -ErrorAction SilentlyContinue)) {
    if (Test-Path "C:\Users\sargunan\AppData\Local\Programs\MinGit\cmd\git.exe") {
        $gitExe = "C:\Users\sargunan\AppData\Local\Programs\MinGit\cmd\git.exe"
    }
}

$token = Read-Host "Enter your GitHub Personal Access Token (or press Enter for standard login)"

if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host "Attempting direct push..." -ForegroundColor Yellow
    & $gitExe push -u https://github.com/itssargu/Neuro-hackathon.git main --force
} else {
    Write-Host "Pushing with your token..." -ForegroundColor Green
    & $gitExe push -u "https://$($token)@github.com/itssargu/Neuro-hackathon.git" main --force
}

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "======================================================================" -ForegroundColor Green
    Write-Host "   SUCCESS! Project pushed to https://github.com/itssargu/Neuro-hackathon" -ForegroundColor Green
    Write-Host "======================================================================" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "[ERROR] Push failed. Make sure your GitHub token has 'repo' write permissions." -ForegroundColor Red
}
