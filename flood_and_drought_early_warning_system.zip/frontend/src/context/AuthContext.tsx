import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: {
    name: string;
    email: string;
    password: string;
    role: string;
    organization?: string;
    location?: string;
  }) => Promise<void>;
  logout: () => void;
  switchRole: (role: UserRole) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    initAuth();
  }, []);

  const initAuth = async () => {
    try {
      const savedToken = localStorage.getItem('aquasentinel_token');
      const savedUser = localStorage.getItem('aquasentinel_user');

      if (savedToken && savedUser) {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
        
        // Background verify with backend
        try {
          const freshUser = await api.getCurrentUser();
          setUser(freshUser);
          localStorage.setItem('aquasentinel_user', JSON.stringify(freshUser));
        } catch {
          // Token expired or server unreachable, clear cache
          localStorage.removeItem('aquasentinel_token');
          localStorage.removeItem('aquasentinel_user');
          setToken(null);
          setUser(null);
        }
      } else {
        // Default to demo Citizen for zero-friction access
        await login('citizen@aquasentinel.org', 'citizen123');
      }
    } catch (err) {
      console.warn('Auth initialization fallback:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const res = await api.login({ email, password });
      setToken(res.token);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: {
    name: string;
    email: string;
    password: string;
    role: string;
    organization?: string;
    location?: string;
  }) => {
    setIsLoading(true);
    try {
      const res = await api.register(userData);
      setToken(res.token);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    api.logout();
    setToken(null);
    setUser(null);
  };

  const switchRole = async (role: UserRole) => {
    const roleCreds: Record<UserRole, { email: string; pass: string }> = {
      'Citizen': { email: 'citizen@aquasentinel.org', pass: 'citizen123' },
      'Farmer': { email: 'farmer@aquasentinel.org', pass: 'farmer123' },
      'Disaster Management Official': { email: 'official@aquasentinel.org', pass: 'official123' },
      'Administrator': { email: 'admin@aquasentinel.org', pass: 'admin123' }
    };
    const cred = roleCreds[role];
    if (cred) {
      await login(cred.email, cred.pass);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
        switchRole
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

