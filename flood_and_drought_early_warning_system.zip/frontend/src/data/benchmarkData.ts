import { DashboardSummary, DistrictProfile, AlertItem, RiverStation } from '../types';

export const BENCHMARK_DISTRICTS: DistrictProfile[] = [
  {
    "id": "assam_dhemaji",
    "name": "Dhemaji",
    "state": "Assam",
    "latitude": 27.48,
    "longitude": 94.58,
    "elevation": 104.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 88.5,
    "flood_category": "Severe",
    "drought_risk_score": 12.0,
    "drought_category": "Low",
    "river_basin": "Brahmaputra / Subansiri",
    "soil_type": "Alluvial Silt Loam",
    "vulnerability_index": 0.89,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 2800,
      "river_gauge_m": 16.8,
      "soil_moisture_pct": 89.2,
      "critical_warning": "Subansiri embankment vulnerable to overtopping"
    }
  },
  {
    "id": "assam_cachar",
    "name": "Cachar (Silchar)",
    "state": "Assam",
    "latitude": 24.83,
    "longitude": 92.8,
    "elevation": 26.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 84.0,
    "flood_category": "Severe",
    "drought_risk_score": 15.0,
    "drought_category": "Low",
    "river_basin": "Barak Valley",
    "soil_type": "Clayey Alluvial",
    "vulnerability_index": 0.86,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 3100,
      "river_gauge_m": 21.2,
      "soil_moisture_pct": 91.0,
      "critical_warning": "Betkundi dyke breach history; low lying urban waterlogging"
    }
  },
  {
    "id": "bihar_darbhanga",
    "name": "Darbhanga",
    "state": "Bihar",
    "latitude": 26.15,
    "longitude": 85.9,
    "elevation": 52.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 91.2,
    "flood_category": "Critical",
    "drought_risk_score": 18.0,
    "drought_category": "Low",
    "river_basin": "Bagmati / Kamla Balan / Kosi",
    "soil_type": "Calcareous Alluvial",
    "vulnerability_index": 0.93,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1150,
      "river_gauge_m": 13.4,
      "soil_moisture_pct": 86.5,
      "critical_warning": "Flash surging from Nepal foothills catchments"
    }
  },
  {
    "id": "bihar_patna",
    "name": "Patna",
    "state": "Bihar",
    "latitude": 25.61,
    "longitude": 85.14,
    "elevation": 53.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 76.5,
    "flood_category": "Severe",
    "drought_risk_score": 24.0,
    "drought_category": "Low",
    "river_basin": "Ganga / Punpun / Son",
    "soil_type": "Older Alluvium",
    "vulnerability_index": 0.78,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1050,
      "river_gauge_m": 50.1,
      "soil_moisture_pct": 78.4,
      "critical_warning": "Punpun backwaters backflow during high Ganges crest"
    }
  },
  {
    "id": "kerala_wayanad",
    "name": "Wayanad",
    "state": "Kerala",
    "latitude": 11.68,
    "longitude": 76.13,
    "elevation": 750.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 82.0,
    "flood_category": "Severe",
    "drought_risk_score": 14.0,
    "drought_category": "Low",
    "river_basin": "Kabini / Chaliyar",
    "soil_type": "Laterite Loam (High Slope)",
    "vulnerability_index": 0.88,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 3500,
      "river_gauge_m": 8.5,
      "soil_moisture_pct": 94.0,
      "critical_warning": "Slope saturation trigger for debris flow and river surge"
    }
  },
  {
    "id": "kerala_alappuzha",
    "name": "Alappuzha (Kuttanad)",
    "state": "Kerala",
    "latitude": 9.5,
    "longitude": 76.33,
    "elevation": -1.5,
    "primary_hazard": "Flood",
    "flood_risk_score": 89.0,
    "flood_category": "Severe",
    "drought_risk_score": 10.0,
    "drought_category": "Low",
    "river_basin": "Pamba / Achankovil / Vembanad",
    "soil_type": "Peat / Acid Coastal Alluvial",
    "vulnerability_index": 0.91,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 2900,
      "river_gauge_m": 3.8,
      "soil_moisture_pct": 98.0,
      "critical_warning": "Below sea level paddy basin; dependent on Thanneermukkom barrage release"
    }
  },
  {
    "id": "maharashtra_kolhapur",
    "name": "Kolhapur",
    "state": "Maharashtra",
    "latitude": 16.7,
    "longitude": 74.24,
    "elevation": 569.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 79.0,
    "flood_category": "Severe",
    "drought_risk_score": 28.0,
    "drought_category": "Moderate",
    "river_basin": "Panchganga / Krishna",
    "soil_type": "Black Cotton / Deep Clay",
    "vulnerability_index": 0.79,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1850,
      "river_gauge_m": 43.5,
      "soil_moisture_pct": 84.0,
      "critical_warning": "Backwater effect from Almatti dam discharge bottlenecks"
    }
  },
  {
    "id": "maharashtra_mumbai",
    "name": "Mumbai Suburban",
    "state": "Maharashtra",
    "latitude": 19.07,
    "longitude": 72.87,
    "elevation": 14.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 83.5,
    "flood_category": "Severe",
    "drought_risk_score": 8.0,
    "drought_category": "Low",
    "river_basin": "Mithi River / Arabian Sea",
    "soil_type": "Urban Coastal Fill / Clay",
    "vulnerability_index": 0.85,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 2400,
      "river_gauge_m": 4.2,
      "soil_moisture_pct": 88.0,
      "critical_warning": "High tide storm surge concurrent with >100mm cloudburst"
    }
  },
  {
    "id": "odisha_puri",
    "name": "Puri",
    "state": "Odisha",
    "latitude": 19.81,
    "longitude": 85.83,
    "elevation": 8.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 74.0,
    "flood_category": "High",
    "drought_risk_score": 25.0,
    "drought_category": "Moderate",
    "river_basin": "Mahanadi Delta / Daya / Bhargavi",
    "soil_type": "Coastal Saline Alluvial",
    "vulnerability_index": 0.75,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1450,
      "river_gauge_m": 9.2,
      "soil_moisture_pct": 82.0,
      "critical_warning": "Bay of Bengal cyclone storm surges combined with Hirakud peak releases"
    }
  },
  {
    "id": "up_gorakhpur",
    "name": "Gorakhpur",
    "state": "Uttar Pradesh",
    "latitude": 26.76,
    "longitude": 83.37,
    "elevation": 84.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 77.0,
    "flood_category": "Severe",
    "drought_risk_score": 22.0,
    "drought_category": "Low",
    "river_basin": "Rapti / Rohini",
    "soil_type": "Gangetic Alluvium",
    "vulnerability_index": 0.76,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1280,
      "river_gauge_m": 75.1,
      "soil_moisture_pct": 81.0,
      "critical_warning": "Rapti River breaches vulnerable embankments during Terai downpours"
    }
  },
  {
    "id": "wb_murshidabad",
    "name": "Murshidabad",
    "state": "West Bengal",
    "latitude": 24.18,
    "longitude": 88.27,
    "elevation": 19.0,
    "primary_hazard": "Flood",
    "flood_risk_score": 73.0,
    "flood_category": "High",
    "drought_risk_score": 29.0,
    "drought_category": "Moderate",
    "river_basin": "Bhagirathi / Padma / Jalangi",
    "soil_type": "Newer Alluvium (Entisols)",
    "vulnerability_index": 0.72,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 1380,
      "river_gauge_m": 12.8,
      "soil_moisture_pct": 80.0,
      "critical_warning": "Riverbank erosion and transboundary high water flow"
    }
  },
  {
    "id": "rajasthan_barmer",
    "name": "Barmer",
    "state": "Rajasthan",
    "latitude": 25.75,
    "longitude": 71.39,
    "elevation": 182.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 22.0,
    "flood_category": "Low",
    "drought_risk_score": 93.5,
    "drought_category": "Critical",
    "river_basin": "Luni Basin (Ephemeral)",
    "soil_type": "Desert / Aridisol Sand",
    "vulnerability_index": 0.94,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 270,
      "soil_moisture_pct": 9.5,
      "vegetation_condition_index": 18.0,
      "consecutive_dry_days": 82,
      "critical_warning": "Sub-surface salinity and severe pastoral fodder depletion"
    }
  },
  {
    "id": "rajasthan_jaisalmer",
    "name": "Jaisalmer",
    "state": "Rajasthan",
    "latitude": 26.91,
    "longitude": 70.91,
    "elevation": 225.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 15.0,
    "flood_category": "Low",
    "drought_risk_score": 96.0,
    "drought_category": "Critical",
    "river_basin": "Internal Thar Drainage",
    "soil_type": "Hyper-Arid Dune Sand",
    "vulnerability_index": 0.97,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 160,
      "soil_moisture_pct": 6.8,
      "vegetation_condition_index": 12.0,
      "consecutive_dry_days": 105,
      "critical_warning": "Extreme groundwater depletion; reliance on Indira Gandhi Canal feeder"
    }
  },
  {
    "id": "maharashtra_latur",
    "name": "Latur",
    "state": "Maharashtra",
    "latitude": 18.4,
    "longitude": 76.58,
    "elevation": 631.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 28.0,
    "flood_category": "Moderate",
    "drought_risk_score": 86.5,
    "drought_category": "Severe",
    "river_basin": "Manjara / Godavari Basin",
    "soil_type": "Deep Black Regur Soil",
    "vulnerability_index": 0.87,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 740,
      "soil_moisture_pct": 18.5,
      "vegetation_condition_index": 26.0,
      "consecutive_dry_days": 54,
      "critical_warning": "Soybean and pulse vegetative wilting; Manjara reservoir storage < 12%"
    }
  },
  {
    "id": "maharashtra_dharashiv",
    "name": "Dharashiv (Osmanabad)",
    "state": "Maharashtra",
    "latitude": 18.18,
    "longitude": 76.04,
    "elevation": 653.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 24.0,
    "flood_category": "Low",
    "drought_risk_score": 85.0,
    "drought_category": "Severe",
    "river_basin": "Sina / Bhima / Godavari",
    "soil_type": "Medium Shallow Black Soil",
    "vulnerability_index": 0.85,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 680,
      "soil_moisture_pct": 19.0,
      "vegetation_condition_index": 28.0,
      "consecutive_dry_days": 50,
      "critical_warning": "Rain shadow region; severely stressed rabi sowing prospects"
    }
  },
  {
    "id": "ap_anantapur",
    "name": "Anantapur",
    "state": "Andhra Pradesh",
    "latitude": 14.68,
    "longitude": 77.6,
    "elevation": 335.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 19.0,
    "flood_category": "Low",
    "drought_risk_score": 90.0,
    "drought_category": "Critical",
    "river_basin": "Pennar Basin",
    "soil_type": "Red Sandy Loam",
    "vulnerability_index": 0.92,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 550,
      "soil_moisture_pct": 12.0,
      "vegetation_condition_index": 21.0,
      "consecutive_dry_days": 68,
      "critical_warning": "Second lowest rainfall district in India; groundnut crop pod-formation failure"
    }
  },
  {
    "id": "karnataka_kalaburagi",
    "name": "Kalaburagi (Gulbarga)",
    "state": "Karnataka",
    "latitude": 17.33,
    "longitude": 76.83,
    "elevation": 454.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 30.0,
    "flood_category": "Moderate",
    "drought_risk_score": 84.5,
    "drought_category": "Severe",
    "river_basin": "Bhima / Krishna",
    "soil_type": "Deep Black Clay",
    "vulnerability_index": 0.84,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 750,
      "soil_moisture_pct": 17.2,
      "vegetation_condition_index": 29.0,
      "consecutive_dry_days": 46,
      "critical_warning": "Red gram (Tur) pulse distress; borewell depths exceeding 500ft"
    }
  },
  {
    "id": "karnataka_kolar",
    "name": "Kolar",
    "state": "Karnataka",
    "latitude": 13.13,
    "longitude": 78.13,
    "elevation": 822.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 18.0,
    "flood_category": "Low",
    "drought_risk_score": 81.0,
    "drought_category": "Severe",
    "river_basin": "Palar / Ponnaiyar",
    "soil_type": "Red Sandy Clay Loam",
    "vulnerability_index": 0.82,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 730,
      "soil_moisture_pct": 21.0,
      "vegetation_condition_index": 33.0,
      "consecutive_dry_days": 42,
      "critical_warning": "Horticultural irrigation deficit; tank cascade systems dry"
    }
  },
  {
    "id": "up_banda",
    "name": "Banda",
    "state": "Uttar Pradesh",
    "latitude": 25.48,
    "longitude": 80.33,
    "elevation": 123.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 38.0,
    "flood_category": "Moderate",
    "drought_risk_score": 87.0,
    "drought_category": "Severe",
    "river_basin": "Ken / Yamuna (Bundelkhand)",
    "soil_type": "Mixed Red & Black (Mar & Kabar)",
    "vulnerability_index": 0.88,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 890,
      "soil_moisture_pct": 16.5,
      "vegetation_condition_index": 25.0,
      "consecutive_dry_days": 58,
      "critical_warning": "Severe Bundelkhand agrarian drought; check-dams and dugwells depleted"
    }
  },
  {
    "id": "mp_tikamgarh",
    "name": "Tikamgarh",
    "state": "Madhya Pradesh",
    "latitude": 24.74,
    "longitude": 78.83,
    "elevation": 326.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 32.0,
    "flood_category": "Moderate",
    "drought_risk_score": 83.0,
    "drought_category": "Severe",
    "river_basin": "Betwa / Jamni",
    "soil_type": "Bundelkhand Granitic / Red Soil",
    "vulnerability_index": 0.83,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 850,
      "soil_moisture_pct": 19.4,
      "vegetation_condition_index": 31.0,
      "consecutive_dry_days": 47,
      "critical_warning": "Chandela tank cascade dry; livestock water availability scarce"
    }
  },
  {
    "id": "tn_ramanathapuram",
    "name": "Ramanathapuram",
    "state": "Tamil Nadu",
    "latitude": 9.36,
    "longitude": 78.83,
    "elevation": 10.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 42.0,
    "flood_category": "Moderate",
    "drought_risk_score": 82.5,
    "drought_category": "Severe",
    "river_basin": "Vaigai / Gundar",
    "soil_type": "Coastal Saline & Red Sandy",
    "vulnerability_index": 0.81,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 840,
      "soil_moisture_pct": 20.1,
      "vegetation_condition_index": 30.0,
      "consecutive_dry_days": 52,
      "critical_warning": "Rain-fed chili and paddy failure; coastal aquifer saline intrusion"
    }
  },
  {
    "id": "gujarat_kutch",
    "name": "Kutch",
    "state": "Gujarat",
    "latitude": 23.24,
    "longitude": 69.66,
    "elevation": 110.0,
    "primary_hazard": "Drought",
    "flood_risk_score": 26.0,
    "flood_category": "Moderate",
    "drought_risk_score": 89.5,
    "drought_category": "Severe",
    "river_basin": "Rann of Kutch Salt Flats",
    "soil_type": "Saline Coastal Desert",
    "vulnerability_index": 0.9,
    "key_metrics": {
      "avg_monsoon_rainfall_mm": 380,
      "soil_moisture_pct": 13.5,
      "vegetation_condition_index": 22.0,
      "consecutive_dry_days": 75,
      "critical_warning": "Banni grassland desiccation; Maldhari pastoralists migration alert"
    }
  }
];

export const BENCHMARK_SUMMARY: DashboardSummary = {
  "current_flood_risk_avg": 54.2,
  "current_drought_risk_avg": 52.9,
  "total_monitored_locations": 22,
  "high_risk_flood_count": 9,
  "high_risk_drought_count": 11,
  "active_alerts_count": 6,
  "immediate_attention_locations": [
    {
      "id": "rajasthan_jaisalmer",
      "name": "Jaisalmer",
      "state": "Rajasthan",
      "primary_hazard": "Drought",
      "risk_score": 96.0,
      "category": "Critical",
      "alert": "Extreme groundwater depletion; reliance on Indira Gandhi Canal feeder"
    },
    {
      "id": "rajasthan_barmer",
      "name": "Barmer",
      "state": "Rajasthan",
      "primary_hazard": "Drought",
      "risk_score": 93.5,
      "category": "Critical",
      "alert": "Sub-surface salinity and severe pastoral fodder depletion"
    },
    {
      "id": "bihar_darbhanga",
      "name": "Darbhanga",
      "state": "Bihar",
      "primary_hazard": "Flood",
      "risk_score": 91.2,
      "category": "Critical",
      "alert": "Flash surging from Nepal foothills catchments"
    },
    {
      "id": "ap_anantapur",
      "name": "Anantapur",
      "state": "Andhra Pradesh",
      "primary_hazard": "Drought",
      "risk_score": 90.0,
      "category": "Critical",
      "alert": "Second lowest rainfall district in India; groundnut crop pod-formation failure"
    },
    {
      "id": "gujarat_kutch",
      "name": "Kutch",
      "state": "Gujarat",
      "primary_hazard": "Drought",
      "risk_score": 89.5,
      "category": "Severe",
      "alert": "Banni grassland desiccation; Maldhari pastoralists migration alert"
    },
    {
      "id": "kerala_alappuzha",
      "name": "Alappuzha (Kuttanad)",
      "state": "Kerala",
      "primary_hazard": "Flood",
      "risk_score": 89.0,
      "category": "Severe",
      "alert": "Below sea level paddy basin; dependent on Thanneermukkom barrage release"
    },
    {
      "id": "assam_dhemaji",
      "name": "Dhemaji",
      "state": "Assam",
      "primary_hazard": "Flood",
      "risk_score": 88.5,
      "category": "Severe",
      "alert": "Subansiri embankment vulnerable to overtopping"
    },
    {
      "id": "up_banda",
      "name": "Banda",
      "state": "Uttar Pradesh",
      "primary_hazard": "Drought",
      "risk_score": 87.0,
      "category": "Severe",
      "alert": "Severe Bundelkhand agrarian drought; check-dams and dugwells depleted"
    },
    {
      "id": "maharashtra_latur",
      "name": "Latur",
      "state": "Maharashtra",
      "primary_hazard": "Drought",
      "risk_score": 86.5,
      "category": "Severe",
      "alert": "Soybean and pulse vegetative wilting; Manjara reservoir storage < 12%"
    },
    {
      "id": "maharashtra_dharashiv",
      "name": "Dharashiv (Osmanabad)",
      "state": "Maharashtra",
      "primary_hazard": "Drought",
      "risk_score": 85.0,
      "category": "Severe",
      "alert": "Rain shadow region; severely stressed rabi sowing prospects"
    },
    {
      "id": "karnataka_kalaburagi",
      "name": "Kalaburagi (Gulbarga)",
      "state": "Karnataka",
      "primary_hazard": "Drought",
      "risk_score": 84.5,
      "category": "Severe",
      "alert": "Red gram (Tur) pulse distress; borewell depths exceeding 500ft"
    },
    {
      "id": "assam_cachar",
      "name": "Cachar (Silchar)",
      "state": "Assam",
      "primary_hazard": "Flood",
      "risk_score": 84.0,
      "category": "Severe",
      "alert": "Betkundi dyke breach history; low lying urban waterlogging"
    },
    {
      "id": "maharashtra_mumbai",
      "name": "Mumbai Suburban",
      "state": "Maharashtra",
      "primary_hazard": "Flood",
      "risk_score": 83.5,
      "category": "Severe",
      "alert": "High tide storm surge concurrent with >100mm cloudburst"
    },
    {
      "id": "mp_tikamgarh",
      "name": "Tikamgarh",
      "state": "Madhya Pradesh",
      "primary_hazard": "Drought",
      "risk_score": 83.0,
      "category": "Severe",
      "alert": "Chandela tank cascade dry; livestock water availability scarce"
    },
    {
      "id": "tn_ramanathapuram",
      "name": "Ramanathapuram",
      "state": "Tamil Nadu",
      "primary_hazard": "Drought",
      "risk_score": 82.5,
      "category": "Severe",
      "alert": "Rain-fed chili and paddy failure; coastal aquifer saline intrusion"
    },
    {
      "id": "kerala_wayanad",
      "name": "Wayanad",
      "state": "Kerala",
      "primary_hazard": "Flood",
      "risk_score": 82.0,
      "category": "Severe",
      "alert": "Slope saturation trigger for debris flow and river surge"
    },
    {
      "id": "karnataka_kolar",
      "name": "Kolar",
      "state": "Karnataka",
      "primary_hazard": "Drought",
      "risk_score": 81.0,
      "category": "Severe",
      "alert": "Horticultural irrigation deficit; tank cascade systems dry"
    }
  ],
  "rainfall_summary": {
    "national_trend": "Active monsoon active over Northeast and Western Ghats; deficient across Marathwada.",
    "highest_rainfall_point": "Dhemaji, Assam (190.0 mm/24h)",
    "highest_deficit_point": "Barmer, Rajasthan (-78% deficit)"
  },
  "soil_moisture_summary": {
    "saturated_hotspots": [
      "Dhemaji, Assam (89%)",
      "Cachar, Assam (91%)",
      "Darbhanga, Bihar (88%)"
    ],
    "parched_hotspots": [
      "Barmer, Rajasthan (8%)",
      "Anantapur, Andhra Pradesh (14%)",
      "Jaisalmer, Rajasthan (6%)"
    ]
  },
  "recent_alerts": [
    {
      "id": "alt_001",
      "location": "Darbhanga",
      "state": "Bihar",
      "hazard_type": "Flash Flood Risk",
      "risk_level": "Critical",
      "timestamp": "2026-11-03T07:15:00Z",
      "title": "Severe Flash Flood Warning \u2014 Kamla Balan Basin",
      "description": "Continuous cloudburst precipitation in upstream catchment (185mm / 24h) coupled with 94% soil saturation is causing rapid river surge nearing embankment crest.",
      "recommended_action": "Evacuate low-lying riverbed settlements in Ghanshyampur and Kiratpur blocks immediately. Stock emergency drinking water.",
      "status": "Active",
      "coordinates": [
        26.15,
        85.9
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    },
    {
      "id": "alt_002",
      "location": "Barmer",
      "state": "Rajasthan",
      "hazard_type": "Agricultural Drought",
      "risk_level": "Critical",
      "timestamp": "2026-11-03T06:30:00Z",
      "title": "Severe Agrarian Moisture Drought Warning",
      "description": "82 consecutive rainless days with 86% seasonal precipitation deficit. Topsoil moisture collapsed to 9.5%, triggering acute crop desiccation.",
      "recommended_action": "Deploy emergency GPS-tracked water tankers to pastoral habitations. Release subsidised fodder rations at panchayat points.",
      "status": "Active",
      "coordinates": [
        25.75,
        71.39
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    },
    {
      "id": "alt_003",
      "location": "Dhemaji",
      "state": "Assam",
      "hazard_type": "Flood Warning",
      "risk_level": "Severe",
      "timestamp": "2026-11-03T08:00:00Z",
      "title": "Subansiri River Embankment Inundation Alert",
      "description": "River level at 16.8m, exceeding danger mark by 1.2m. Jiadhal and Gainadi tributaries experiencing high discharge into farmland.",
      "recommended_action": "Move livestock and farm equipment to elevated community platforms (Chaprash). SDRF team on standby with rescue boats.",
      "status": "Active",
      "coordinates": [
        27.48,
        94.58
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    },
    {
      "id": "alt_004",
      "location": "Anantapur",
      "state": "Andhra Pradesh",
      "hazard_type": "Water Scarcity",
      "risk_level": "Critical",
      "timestamp": "2026-11-03T05:45:00Z",
      "title": "Groundwater Depletion & Rain-fed Pod Distress",
      "description": "68 consecutive rainless days with soil moisture at 12%. Groundwater tables declining below critical recharge thresholds.",
      "recommended_action": "Prioritize protective sprinkler irrigation for surviving horticulture; restrict industrial groundwater abstraction.",
      "status": "Active",
      "coordinates": [
        14.68,
        77.6
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    },
    {
      "id": "alt_005",
      "location": "Alappuzha (Kuttanad)",
      "state": "Kerala",
      "hazard_type": "Flood Warning",
      "risk_level": "Severe",
      "timestamp": "2026-11-03T07:45:00Z",
      "title": "Kuttanad Below-Sea-Level Polder Inundation",
      "description": "Pamba and Achankovil river discharge accumulating in Vembanad Lake. Thanneermukkom shutters operating at full capacity.",
      "recommended_action": "Maintain diesel dewatering pumps along polder bunds; relocate vulnerable houseboats to designated moorings.",
      "status": "Active",
      "coordinates": [
        9.5,
        76.33
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    },
    {
      "id": "alt_006",
      "location": "Latur",
      "state": "Maharashtra",
      "hazard_type": "Agricultural Drought",
      "risk_level": "Severe",
      "timestamp": "2026-11-03T06:00:00Z",
      "title": "Marathwada Kharif Crop Stress Notification",
      "description": "54 rainless days combined with 37\u00b0C temperatures causing rapid soybean leaf wilting. Reservoir storage at 14% live capacity.",
      "recommended_action": "Apply straw mulching to retain root moisture; operate drip irrigation only during dusk hours.",
      "status": "Active",
      "coordinates": [
        18.4,
        76.58
      ],
      "acknowledged_by": null,
      "acknowledged_at": null
    }
  ],
  "risk_distribution": {
    "Low": 0,
    "Moderate": 0,
    "High": 2,
    "Severe": 16,
    "Critical": 4
  }
};

export const BENCHMARK_ALERTS: AlertItem[] = [
  {
    "id": "alt_001",
    "location": "Darbhanga",
    "state": "Bihar",
    "hazard_type": "Flash Flood Risk",
    "risk_level": "Critical",
    "timestamp": "2026-11-03T07:15:00Z",
    "title": "Severe Flash Flood Warning \u2014 Kamla Balan Basin",
    "description": "Continuous cloudburst precipitation in upstream catchment (185mm / 24h) coupled with 94% soil saturation is causing rapid river surge nearing embankment crest.",
    "recommended_action": "Evacuate low-lying riverbed settlements in Ghanshyampur and Kiratpur blocks immediately. Stock emergency drinking water.",
    "status": "Active",
    "coordinates": [
      26.15,
      85.9
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  },
  {
    "id": "alt_002",
    "location": "Barmer",
    "state": "Rajasthan",
    "hazard_type": "Agricultural Drought",
    "risk_level": "Critical",
    "timestamp": "2026-11-03T06:30:00Z",
    "title": "Severe Agrarian Moisture Drought Warning",
    "description": "82 consecutive rainless days with 86% seasonal precipitation deficit. Topsoil moisture collapsed to 9.5%, triggering acute crop desiccation.",
    "recommended_action": "Deploy emergency GPS-tracked water tankers to pastoral habitations. Release subsidised fodder rations at panchayat points.",
    "status": "Active",
    "coordinates": [
      25.75,
      71.39
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  },
  {
    "id": "alt_003",
    "location": "Dhemaji",
    "state": "Assam",
    "hazard_type": "Flood Warning",
    "risk_level": "Severe",
    "timestamp": "2026-11-03T08:00:00Z",
    "title": "Subansiri River Embankment Inundation Alert",
    "description": "River level at 16.8m, exceeding danger mark by 1.2m. Jiadhal and Gainadi tributaries experiencing high discharge into farmland.",
    "recommended_action": "Move livestock and farm equipment to elevated community platforms (Chaprash). SDRF team on standby with rescue boats.",
    "status": "Active",
    "coordinates": [
      27.48,
      94.58
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  },
  {
    "id": "alt_004",
    "location": "Anantapur",
    "state": "Andhra Pradesh",
    "hazard_type": "Water Scarcity",
    "risk_level": "Critical",
    "timestamp": "2026-11-03T05:45:00Z",
    "title": "Groundwater Depletion & Rain-fed Pod Distress",
    "description": "68 consecutive rainless days with soil moisture at 12%. Groundwater tables declining below critical recharge thresholds.",
    "recommended_action": "Prioritize protective sprinkler irrigation for surviving horticulture; restrict industrial groundwater abstraction.",
    "status": "Active",
    "coordinates": [
      14.68,
      77.6
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  },
  {
    "id": "alt_005",
    "location": "Alappuzha (Kuttanad)",
    "state": "Kerala",
    "hazard_type": "Flood Warning",
    "risk_level": "Severe",
    "timestamp": "2026-11-03T07:45:00Z",
    "title": "Kuttanad Below-Sea-Level Polder Inundation",
    "description": "Pamba and Achankovil river discharge accumulating in Vembanad Lake. Thanneermukkom shutters operating at full capacity.",
    "recommended_action": "Maintain diesel dewatering pumps along polder bunds; relocate vulnerable houseboats to designated moorings.",
    "status": "Active",
    "coordinates": [
      9.5,
      76.33
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  },
  {
    "id": "alt_006",
    "location": "Latur",
    "state": "Maharashtra",
    "hazard_type": "Agricultural Drought",
    "risk_level": "Severe",
    "timestamp": "2026-11-03T06:00:00Z",
    "title": "Marathwada Kharif Crop Stress Notification",
    "description": "54 rainless days combined with 37\u00b0C temperatures causing rapid soybean leaf wilting. Reservoir storage at 14% live capacity.",
    "recommended_action": "Apply straw mulching to retain root moisture; operate drip irrigation only during dusk hours.",
    "status": "Active",
    "coordinates": [
      18.4,
      76.58
    ],
    "acknowledged_by": null,
    "acknowledged_at": null
  }
];

export const BENCHMARK_RIVERS: RiverStation[] = [
  {
    "id": "riv_001",
    "river_name": "Brahmaputra",
    "station_name": "Dhemaji / Subansiri Confluence",
    "state": "Assam",
    "water_level_m": 16.8,
    "warning_level_m": 16.0,
    "danger_level_m": 17.0,
    "discharge_cusecs": 142000,
    "status": "Critical",
    "trend": "Rising",
    "simple_status": "Water level is near danger mark. Water is rising fast.",
    "last_updated": "Today, 10:30 AM",
    "is_demo": true
  },
  {
    "id": "riv_002",
    "river_name": "Kamla Balan",
    "station_name": "Jhanjharpur / Darbhanga",
    "state": "Bihar",
    "water_level_m": 13.4,
    "warning_level_m": 12.5,
    "danger_level_m": 13.0,
    "discharge_cusecs": 85000,
    "status": "Critical",
    "trend": "Rising",
    "simple_status": "Water has crossed danger level. Embankment risk in low areas.",
    "last_updated": "Today, 10:15 AM",
    "is_demo": true
  },
  {
    "id": "riv_003",
    "river_name": "Barak",
    "station_name": "Annapurna Ghat, Silchar",
    "state": "Assam",
    "water_level_m": 21.2,
    "warning_level_m": 20.0,
    "danger_level_m": 21.5,
    "discharge_cusecs": 62000,
    "status": "High",
    "trend": "Rising",
    "simple_status": "Water level is high and rising slowly.",
    "last_updated": "Today, 09:45 AM",
    "is_demo": true
  },
  {
    "id": "riv_004",
    "river_name": "Ganga (Ganges)",
    "station_name": "Gandhi Ghat, Patna",
    "state": "Bihar",
    "water_level_m": 50.1,
    "warning_level_m": 49.5,
    "danger_level_m": 50.5,
    "discharge_cusecs": 320000,
    "status": "High",
    "trend": "Steady",
    "simple_status": "Water level is high but steady. Low-lying riverbanks are waterlogged.",
    "last_updated": "Today, 09:30 AM",
    "is_demo": true
  },
  {
    "id": "riv_005",
    "river_name": "Panchganga",
    "station_name": "Rajaram Weir, Kolhapur",
    "state": "Maharashtra",
    "water_level_m": 43.5,
    "warning_level_m": 42.0,
    "danger_level_m": 44.0,
    "discharge_cusecs": 48000,
    "status": "High",
    "trend": "Rising",
    "simple_status": "Water level is high. Almatti dam backwaters being monitored.",
    "last_updated": "Today, 08:30 AM",
    "is_demo": true
  },
  {
    "id": "riv_006",
    "river_name": "Pamba",
    "station_name": "Chengannur / Kuttanad",
    "state": "Kerala",
    "water_level_m": 3.8,
    "warning_level_m": 3.5,
    "danger_level_m": 4.2,
    "discharge_cusecs": 29000,
    "status": "High",
    "trend": "Rising",
    "simple_status": "Water level is elevated due to heavy hill rains.",
    "last_updated": "Today, 08:00 AM",
    "is_demo": true
  },
  {
    "id": "riv_007",
    "river_name": "Rapti",
    "station_name": "Birdghat, Gorakhpur",
    "state": "Uttar Pradesh",
    "water_level_m": 75.1,
    "warning_level_m": 74.0,
    "danger_level_m": 76.0,
    "discharge_cusecs": 54000,
    "status": "Rising",
    "trend": "Rising",
    "simple_status": "Water level is rising after upstream rain.",
    "last_updated": "Today, 07:15 AM",
    "is_demo": true
  },
  {
    "id": "riv_008",
    "river_name": "Mahanadi",
    "station_name": "Naraj Barrage, Cuttack",
    "state": "Odisha",
    "water_level_m": 9.2,
    "warning_level_m": 10.5,
    "danger_level_m": 12.0,
    "discharge_cusecs": 78000,
    "status": "Normal",
    "trend": "Steady",
    "simple_status": "Water level is normal and within safe riverbanks.",
    "last_updated": "Today, 06:00 AM",
    "is_demo": true
  },
  {
    "id": "riv_009",
    "river_name": "Yamuna",
    "station_name": "Old Railway Bridge, Delhi",
    "state": "Delhi",
    "water_level_m": 204.5,
    "warning_level_m": 204.5,
    "danger_level_m": 205.3,
    "discharge_cusecs": 25000,
    "status": "Normal",
    "trend": "Steady",
    "simple_status": "Water level is in safe zone. No immediate flood threat.",
    "last_updated": "Today, 06:30 AM",
    "is_demo": true
  },
  {
    "id": "riv_010",
    "river_name": "Godavari",
    "station_name": "Dowleswaram Barrage, Rajahmundry",
    "state": "Andhra Pradesh",
    "water_level_m": 14.2,
    "warning_level_m": 16.0,
    "danger_level_m": 17.5,
    "discharge_cusecs": 95000,
    "status": "Normal",
    "trend": "Steady",
    "simple_status": "Flow is normal. Gates operating regularly.",
    "last_updated": "Today, 06:15 AM",
    "is_demo": true
  },
  {
    "id": "riv_011",
    "river_name": "Kaveri (Cauvery)",
    "station_name": "Upper Anicut / Mettur, Tamil Nadu",
    "state": "Tamil Nadu",
    "water_level_m": 18.0,
    "warning_level_m": 22.0,
    "danger_level_m": 24.5,
    "discharge_cusecs": 18000,
    "status": "Normal",
    "trend": "Steady",
    "simple_status": "River water level is normal with steady downstream release.",
    "last_updated": "Today, 05:45 AM",
    "is_demo": true
  },
  {
    "id": "riv_012",
    "river_name": "Mithi",
    "station_name": "Kurla Gauge, Mumbai",
    "state": "Maharashtra",
    "water_level_m": 3.2,
    "warning_level_m": 3.8,
    "danger_level_m": 4.5,
    "discharge_cusecs": 4500,
    "status": "Normal",
    "trend": "Steady",
    "simple_status": "Water level is currently normal. Monitored for high tide synchronization.",
    "last_updated": "Today, 08:45 AM",
    "is_demo": true
  }
];
