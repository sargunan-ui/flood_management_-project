import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: string;
  trendType?: 'neutral' | 'danger' | 'warning' | 'safe';
  accentColor?: 'cyan' | 'emerald' | 'amber' | 'red';
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendType = 'neutral',
  accentColor = 'cyan'
}) => {
  const accentGlow = {
    cyan: 'hover:border-cyan-500/50 hover:shadow-glow-cyan',
    emerald: 'hover:border-emerald-500/50 hover:shadow-glow-emerald',
    amber: 'hover:border-amber-500/50 hover:shadow-glow-amber',
    red: 'hover:border-red-500/50 hover:shadow-glow-red'
  }[accentColor];

  const iconBg = {
    cyan: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    red: 'bg-red-500/10 text-red-400 border-red-500/30'
  }[accentColor];

  return (
    <div className={`glass-card p-5 rounded-xl border border-slate-700/40 transition-all duration-300 ${accentGlow}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs uppercase tracking-wider text-slate-400 font-semibold">{title}</span>
        <div className={`p-2 rounded-lg border ${iconBg}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>

      <div className="flex items-baseline gap-2 mb-1">
        <span className="text-2xl font-bold font-mono text-slate-100">{value}</span>
        {trend && (
          <span className={`text-xs font-semibold px-1.5 py-0.5 rounded ${
            trendType === 'danger' ? 'bg-red-500/10 text-red-400 border border-red-500/30' :
            trendType === 'warning' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
            trendType === 'safe' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
            'bg-slate-700/30 text-slate-400'
          }`}>
            {trend}
          </span>
        )}
      </div>

      {subtitle && (
        <p className="text-xs text-slate-400 leading-relaxed">{subtitle}</p>
      )}
    </div>
  );
};

