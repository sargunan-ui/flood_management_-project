import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  activeAlertCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  setActivePage,
  activeAlertCount = 0
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout, switchRole } = useAuth();

  const navTabs = [
    { id: 'home', label: 'Dashboard' },
    { id: 'hazard-map', label: 'Flood & Drought Map' },
    { id: 'rivers', label: 'River Monitoring' },
    { id: 'check-risk', label: 'Check Risk' },
    { id: 'alerts', label: 'Alerts', badge: activeAlertCount },
    { id: 'aqua-ai', label: 'AI Assistant' },
    { id: 'safety-guide', label: 'Safety Guide' },
    { id: 'history', label: 'History' },
    { id: 'about', label: 'About' },
    { id: 'login', label: 'ID Login' },
  ];

  const handleNav = (id: string) => {
    setActivePage(id);
    window.location.hash = id;
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 border-b border-slate-800 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo & Name */}
          <div
            onClick={() => handleNav('home')}
            className="flex items-center gap-2.5 cursor-pointer shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-cyan-600 text-white flex items-center justify-center font-extrabold text-sm shadow-md">
              AS
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-white">
                  AquaSentinel AI
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 hidden sm:inline">
                  GP-03
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">
                Early Warning & Resilience Platform
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden xl:flex items-center gap-1">
            {navTabs.map((tab) => {
              const isActive = activePage === tab.id || (tab.id === 'hazard-map' && (activePage === 'flood-map' || activePage === 'drought-map'));
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => handleNav(tab.id)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition relative ${
                    isActive
                      ? 'bg-slate-800 text-cyan-400 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 rounded-full bg-rose-600 text-white font-bold text-[10px]">
                      {tab.badge}
                    </span>
                  )}
                  {tab.id === 'aqua-ai' && (
                    <span className="ml-1 w-1.5 h-1.5 rounded-full bg-cyan-400 inline-block"></span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right: User Profile & Authentication */}
          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-2">
                <div className="text-right">
                  <span className="text-xs font-semibold text-slate-200 block leading-tight">
                    {user.name}
                  </span>
                  <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
                    {user.role}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleNav('login')}
                  title="Manage account or switch roles"
                  className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-medium transition"
                >
                  Roles
                </button>
                <button
                  type="button"
                  onClick={logout}
                  className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-rose-400 text-xs font-medium transition"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleNav('login')}
                className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition shadow-md"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center xl:hidden gap-2">
            {user && (
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold">
                {user.role}
              </span>
            )}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white border border-slate-800"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-4 space-y-1">
          {navTabs.map((tab) => {
            const isActive = activePage === tab.id || (tab.id === 'hazard-map' && (activePage === 'flood-map' || activePage === 'drought-map'));
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => handleNav(tab.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between ${
                  isActive
                    ? 'bg-cyan-950 text-cyan-400 font-bold border border-cyan-800/60'
                    : 'text-slate-300 hover:bg-slate-900'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white font-bold text-[10px]">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
            {user ? (
              <div className="flex items-center justify-between w-full pt-1">
                <div>
                  <span className="text-xs font-medium text-slate-200 block">{user.name}</span>
                  <span className="text-[10px] text-cyan-400 font-bold uppercase">{user.role}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleNav('login')}
                    className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-200 font-medium"
                  >
                    Switch Role
                  </button>
                  <button
                    type="button"
                    onClick={logout}
                    className="text-xs px-2.5 py-1 rounded bg-slate-800 text-rose-300 font-medium"
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => handleNav('login')}
                className="w-full text-center py-2 rounded-lg bg-cyan-600 text-white text-xs font-semibold"
              >
                Sign In to Portal
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
