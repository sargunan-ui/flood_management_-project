import React from 'react';
import { AlertItem } from '../types';

interface ThreatTickerProps {
  alerts: AlertItem[];
  onSelectAlert?: (alert: AlertItem) => void;
}

export const ThreatTicker: React.FC<ThreatTickerProps> = ({ alerts, onSelectAlert }) => {
  if (!alerts || alerts.length === 0) return null;

  return (
    <div className="bg-red-950/40 border-b border-red-500/30 overflow-hidden py-1.5 px-4 relative flex items-center text-xs">
      <div className="flex items-center gap-2 pr-3 bg-red-950/90 z-10 font-bold uppercase tracking-wider text-red-300 shrink-0 border-r border-red-500/40 text-[11px]">
        <span className="w-2 h-2 rounded-full bg-red-500 animate-ping inline-block" />
        <span>Active Alerts</span>
      </div>

      <div className="flex overflow-x-hidden whitespace-nowrap">
        <div className="flex animate-ticker gap-6 items-center text-xs">
          {alerts.concat(alerts).map((alert, idx) => (
            <div
              key={`${alert.id}-${idx}`}
              onClick={() => onSelectAlert && onSelectAlert(alert)}
              className="inline-flex items-center gap-2 cursor-pointer hover:text-white transition-colors py-0.5 px-2 rounded"
            >
              <span className={`font-bold px-1.5 py-0.2 rounded text-[10px] uppercase ${
                alert.risk_level === 'Critical' ? 'bg-red-700 text-white' :
                alert.risk_level === 'Severe' ? 'bg-orange-600 text-white' :
                'bg-amber-600 text-white'
              }`}>
                {alert.risk_level}
              </span>
              <span className="text-white font-medium">
                [{alert.location}, {alert.state}]:
              </span>
              <span className="text-slate-300 truncate max-w-sm">
                {alert.title}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
