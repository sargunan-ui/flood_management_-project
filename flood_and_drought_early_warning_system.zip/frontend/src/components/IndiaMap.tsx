import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, GeoJSON, Polyline, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { api } from '../services/api';
import { RiverStation } from '../types';

export type MapLayerMode = 'flood' | 'drought' | 'combined' | 'rivers' | 'stations';
export type MapTileProvider = 'google-roadmap' | 'google-hybrid' | 'google-terrain' | 'osm';

interface IndiaMapProps {
  initialMode?: MapLayerMode;
  initialProvider?: MapTileProvider;
  selectedDistrictId?: string;
  onSelectDistrict?: (districtId: string) => void;
  height?: string;
  showLayerControls?: boolean;
}

// Controller to fly to coordinates
function MapFlyController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, zoom, { duration: 1.0 });
  }, [center, zoom, map]);
  return null;
}

export const IndiaMap: React.FC<IndiaMapProps> = ({
  initialMode = 'flood',
  initialProvider = 'google-roadmap',
  selectedDistrictId,
  onSelectDistrict,
  height = '620px',
  showLayerControls = true
}) => {
  const [activeLayer, setActiveLayer] = useState<MapLayerMode>(initialMode);
  const [mapProvider, setMapProvider] = useState<MapTileProvider>(initialProvider);
  const [floodGeoJson, setFloodGeoJson] = useState<any>(null);
  const [droughtGeoJson, setDroughtGeoJson] = useState<any>(null);
  const [riversGeoJson, setRiversGeoJson] = useState<any>(null);
  const [combinedGeoJson, setCombinedGeoJson] = useState<any>(null);
  const [riverStations, setRiverStations] = useState<RiverStation[]>([]);
  const [selectedFeature, setSelectedFeature] = useState<any>(null);
  const [selectedRiver, setSelectedRiver] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [mapCenter, setMapCenter] = useState<[number, number]>([22.5, 82.0]);
  const [mapZoom, setMapZoom] = useState<number>(5);
  const [loading, setLoading] = useState(true);
  const [showGoogleEmbed, setShowGoogleEmbed] = useState(false);

  // Load GeoJSON datasets
  useEffect(() => {
    let isMounted = true;
    async function loadMapData() {
      try {
        setLoading(true);
        const [floodData, droughtData, riversData, combinedData, stationsData] = await Promise.allSettled([
          api.getMapFlood(),
          api.getMapDrought(),
          api.getMapRiversGeoJson(),
          api.getMapCombined(),
          api.getRivers()
        ]);

        if (isMounted) {
          if (floodData.status === 'fulfilled') setFloodGeoJson(floodData.value);
          if (droughtData.status === 'fulfilled') setDroughtGeoJson(droughtData.value);
          if (riversData.status === 'fulfilled') setRiversGeoJson(riversData.value);
          if (combinedData.status === 'fulfilled') setCombinedGeoJson(combinedData.value);
          if (stationsData.status === 'fulfilled') setRiverStations(stationsData.value);
        }
      } catch (err) {
        console.error('Failed to load India map GeoJSON layers:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadMapData();
    return () => { isMounted = false; };
  }, []);

  // Sync selected district from prop
  useEffect(() => {
    if (selectedDistrictId && floodGeoJson) {
      const feat = floodGeoJson.features.find((f: any) => f.id === selectedDistrictId);
      if (feat) {
        setSelectedFeature(feat.properties);
        if (feat.properties.center) {
          setMapCenter([feat.properties.center[0], feat.properties.center[1]]);
          setMapZoom(7);
        }
      }
    }
  }, [selectedDistrictId, floodGeoJson]);

  // Current active GeoJSON feature collection
  const currentDistrictGeoJson = useMemo(() => {
    if (activeLayer === 'drought') return droughtGeoJson;
    if (activeLayer === 'combined') return combinedGeoJson;
    return floodGeoJson;
  }, [activeLayer, floodGeoJson, droughtGeoJson, combinedGeoJson]);

  // Filter features by search query
  const filteredGeoJson = useMemo(() => {
    if (!currentDistrictGeoJson) return null;
    if (!searchQuery.trim()) return currentDistrictGeoJson;
    const q = searchQuery.toLowerCase();
    const filteredFeatures = currentDistrictGeoJson.features.filter((f: any) => {
      const name = f.properties.name?.toLowerCase() || '';
      const state = f.properties.state?.toLowerCase() || '';
      return name.includes(q) || state.includes(q);
    });
    return {
      ...currentDistrictGeoJson,
      features: filteredFeatures
    };
  }, [currentDistrictGeoJson, searchQuery]);

  // Polygon styling function
  const styleFeature = (feature: any) => {
    const isSelected = selectedFeature && selectedFeature.id === feature.properties.id;
    const fillColor = feature.properties.fill_color || '#16a34a';

    return {
      fillColor: fillColor,
      weight: isSelected ? 3.5 : 2.0,
      opacity: 1,
      color: isSelected ? '#ffffff' : '#1e293b',
      dashArray: isSelected ? '' : '2',
      fillOpacity: isSelected ? 0.8 : (mapProvider === 'google-hybrid' ? 0.6 : 0.55)
    };
  };

  // Polygon interaction handler
  const onEachFeature = (feature: any, layer: L.Layer) => {
    layer.on({
      click: () => {
        setSelectedFeature(feature.properties);
        setSelectedRiver(null);
        if (onSelectDistrict) {
          onSelectDistrict(feature.properties.id);
        }
        if (feature.properties.center) {
          setMapCenter([feature.properties.center[0], feature.properties.center[1]]);
          setMapZoom(7);
        }
      },
      mouseover: (e: any) => {
        const l = e.target;
        l.setStyle({
          weight: 3.5,
          color: '#38bdf8',
          fillOpacity: 0.85
        });
      },
      mouseout: (e: any) => {
        const l = e.target;
        const isSelected = selectedFeature && selectedFeature.id === feature.properties.id;
        l.setStyle({
          weight: isSelected ? 3.5 : 2.0,
          color: isSelected ? '#ffffff' : '#1e293b',
          fillOpacity: isSelected ? 0.8 : (mapProvider === 'google-hybrid' ? 0.6 : 0.55)
        });
      }
    });
  };

  const createStationIcon = (station: RiverStation) => {
    const statusColors = {
      'Critical': '#dc2626',
      'High': '#ea580c',
      'Rising': '#eab308',
      'Normal': '#10b981'
    };
    const color = statusColors[station.status] || '#10b981';

    return L.divIcon({
      className: 'river-station-icon',
      html: `
        <div style="
          width: 28px;
          height: 28px;
          border-radius: 50%;
          background: #0f172a;
          border: 3px solid ${color};
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 10px;
          font-weight: bold;
          box-shadow: 0 0 10px ${color}80;
          cursor: pointer;
        ">
          ${station.water_level_m.toFixed(1)}m
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14],
      popupAnchor: [0, -16]
    });
  };

  // Convert GeoJSON LineString [lon, lat] coordinates to Leaflet [lat, lon]
  const riverLines = useMemo(() => {
    if (!riversGeoJson || !riversGeoJson.features) return [];
    return riversGeoJson.features.map((f: any) => {
      const latLngs = f.geometry.coordinates.map((c: [number, number]) => [c[1], c[0]]);
      return {
        id: f.id,
        properties: f.properties,
        latLngs: latLngs
      };
    });
  }, [riversGeoJson]);

  // Tile provider definitions
  const tileConfig = useMemo(() => {
    switch (mapProvider) {
      case 'google-hybrid':
        return {
          url: 'https://{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
          subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
          attribution: '&copy; Google Maps (Satellite & Labels)',
          label: 'Google Satellite (Hybrid)'
        };
      case 'google-terrain':
        return {
          url: 'https://{s}.google.com/vt/lyrs=p&x={x}&y={y}&z={z}',
          subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
          attribution: '&copy; Google Maps (Terrain & Contours)',
          label: 'Google Terrain'
        };
      case 'osm':
        return {
          url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
          subdomains: ['a', 'b', 'c', 'd'],
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
          label: 'CartoDB / OpenStreetMap'
        };
      case 'google-roadmap':
      default:
        return {
          url: 'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
          subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
          attribution: '&copy; Google Maps',
          label: 'Google Maps (Roadmap)'
        };
    }
  }, [mapProvider]);

  return (
    <div className="relative w-full rounded-xl overflow-hidden border border-slate-700/80 bg-slate-950 shadow-2xl">
      
      {/* Top Controls Bar */}
      {showLayerControls && (
        <div className="bg-slate-900/95 border-b border-slate-800 p-3 sm:p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3 z-10 relative">
          
          {/* Hazard Layer Selector */}
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-1 hidden sm:inline">
              Hazard Layer:
            </span>
            <button
              type="button"
              onClick={() => setActiveLayer('flood')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeLayer === 'flood'
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Flood Risk
            </button>
            <button
              type="button"
              onClick={() => setActiveLayer('drought')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeLayer === 'drought'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Drought Risk
            </button>
            <button
              type="button"
              onClick={() => setActiveLayer('combined')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeLayer === 'combined'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              Combined Risk
            </button>
            <button
              type="button"
              onClick={() => setActiveLayer('rivers')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeLayer === 'rivers'
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              River Flow (9 Rivers)
            </button>
            <button
              type="button"
              onClick={() => setActiveLayer('stations')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeLayer === 'stations'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
            >
              River Gauges
            </button>
          </div>

          {/* Right Side: Google Maps Base Layer Toggle & Search */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Google Map Mode Selector */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
              <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider px-1.5 hidden md:inline">
                Google Map:
              </span>
              <button
                type="button"
                onClick={() => setMapProvider('google-roadmap')}
                className={`px-2 py-1 rounded text-xs font-semibold transition ${
                  mapProvider === 'google-roadmap' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Roadmap
              </button>
              <button
                type="button"
                onClick={() => setMapProvider('google-hybrid')}
                className={`px-2 py-1 rounded text-xs font-semibold transition ${
                  mapProvider === 'google-hybrid' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Satellite
              </button>
              <button
                type="button"
                onClick={() => setMapProvider('google-terrain')}
                className={`px-2 py-1 rounded text-xs font-semibold transition ${
                  mapProvider === 'google-terrain' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Terrain
              </button>
              <button
                type="button"
                onClick={() => setMapProvider('osm')}
                className={`px-2 py-1 rounded text-xs font-semibold transition ${
                  mapProvider === 'osm' ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                OSM
              </button>
            </div>

            {/* Search Box */}
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search district or state..."
              className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-36 sm:w-44"
            />
            <button
              type="button"
              onClick={() => {
                setMapCenter([22.5, 82.0]);
                setMapZoom(5);
                setSearchQuery('');
              }}
              title="Reset View to All India"
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
            >
              Reset
            </button>
          </div>
        </div>
      )}

      {/* Main Map Canvas */}
      <div style={{ height: height }} className="w-full relative z-0">
        {loading && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm z-20 flex items-center justify-center">
            <div className="text-center">
              <div className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin mb-2"></div>
              <p className="text-xs text-slate-300 font-medium">Loading Google Map & Hydrology Boundaries...</p>
            </div>
          </div>
        )}

        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: '100%', width: '100%', background: '#090d16' }}
          scrollWheelZoom={true}
          minZoom={4}
          maxZoom={18}
        >
          <MapFlyController center={mapCenter} zoom={mapZoom} />

          {/* Google Maps / Satellite / Terrain TileLayer */}
          <TileLayer
            key={mapProvider}
            url={tileConfig.url}
            subdomains={tileConfig.subdomains}
            attribution={tileConfig.attribution}
            maxZoom={20}
          />

          {/* District Polygons Layer */}
          {filteredGeoJson && (activeLayer === 'flood' || activeLayer === 'drought' || activeLayer === 'combined') && (
            <GeoJSON
              key={`${activeLayer}-${mapProvider}-${filteredGeoJson.features.length}-${searchQuery}`}
              data={filteredGeoJson}
              style={styleFeature}
              onEachFeature={onEachFeature}
            />
          )}

          {/* Major Rivers LineStrings Layer */}
          {(activeLayer === 'rivers' || activeLayer === 'flood' || activeLayer === 'combined') && (
            <>
              {riverLines.map((river: any) => {
                const isSelected = selectedRiver && selectedRiver.id === river.id;
                const isHighlighted = activeLayer === 'rivers';
                const strokeColor = river.properties.color || '#0284c7';

                return (
                  <Polyline
                    key={river.id}
                    positions={river.latLngs}
                    pathOptions={{
                      color: isSelected ? '#38bdf8' : strokeColor,
                      weight: isHighlighted ? (isSelected ? 6 : 4) : 2.5,
                      opacity: isHighlighted ? 0.95 : 0.7,
                      lineJoin: 'round'
                    }}
                    eventHandlers={{
                      click: () => {
                        setSelectedRiver(river.properties);
                        setSelectedFeature(null);
                      }
                    }}
                  >
                    <Popup>
                      <div className="text-slate-900 p-1 max-w-xs">
                        <h4 className="font-bold text-sm text-cyan-800">{river.properties.name}</h4>
                        <p className="text-xs text-slate-600 mt-0.5"><strong>Origin:</strong> {river.properties.origin}</p>
                        <p className="text-xs text-slate-600"><strong>Length:</strong> {river.properties.length_km} km</p>
                        <p className="text-xs text-slate-600"><strong>Discharge:</strong> {river.properties.discharge_cusecs?.toLocaleString()} cusecs</p>
                        <div className="mt-1.5 p-1.5 rounded bg-cyan-50 border border-cyan-200 text-[11px] font-medium text-cyan-900">
                          {river.properties.current_status}
                        </div>
                        <a
                          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(river.properties.name + ' river India')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-2 block text-center py-1 bg-cyan-700 text-white rounded text-xs font-semibold"
                        >
                          Trace in Google Maps ↗
                        </a>
                      </div>
                    </Popup>
                  </Polyline>
                );
              })}
            </>
          )}

          {/* River Gauge Stations Layer */}
          {(activeLayer === 'stations' || activeLayer === 'rivers') && (
            <>
              {riverStations.map((station) => (
                <Marker
                  key={station.id}
                  position={[
                    station.river_name.includes('Brahmaputra') ? 27.48 :
                    station.river_name.includes('Ganga') ? 25.61 :
                    station.river_name.includes('Barak') ? 24.83 :
                    station.river_name.includes('Kamla') ? 26.15 :
                    station.river_name.includes('Panchganga') ? 16.70 :
                    station.river_name.includes('Pamba') ? 9.50 :
                    station.river_name.includes('Rapti') ? 26.76 :
                    station.river_name.includes('Mahanadi') ? 20.46 :
                    station.river_name.includes('Yamuna') ? 28.61 :
                    station.river_name.includes('Godavari') ? 17.00 :
                    station.river_name.includes('Kaveri') ? 10.82 :
                    station.river_name.includes('Mithi') ? 19.07 : 22.0,
                    station.river_name.includes('Brahmaputra') ? 94.58 :
                    station.river_name.includes('Ganga') ? 85.14 :
                    station.river_name.includes('Barak') ? 92.80 :
                    station.river_name.includes('Kamla') ? 85.90 :
                    station.river_name.includes('Panchganga') ? 74.24 :
                    station.river_name.includes('Pamba') ? 76.33 :
                    station.river_name.includes('Rapti') ? 83.37 :
                    station.river_name.includes('Mahanadi') ? 85.88 :
                    station.river_name.includes('Yamuna') ? 77.21 :
                    station.river_name.includes('Godavari') ? 81.78 :
                    station.river_name.includes('Kaveri') ? 78.69 :
                    station.river_name.includes('Mithi') ? 72.87 : 80.0
                  ]}
                  icon={createStationIcon(station)}
                >
                  <Popup>
                    <div className="text-slate-900 p-1 max-w-xs">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-bold text-sm text-slate-800">{station.station_name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded font-bold uppercase bg-slate-200">
                          {station.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600"><strong>River:</strong> {station.river_name} ({station.state})</p>
                      <div className="grid grid-cols-2 gap-2 my-2 p-1.5 rounded bg-slate-100 text-xs">
                        <div>
                          <span className="text-[10px] text-slate-500 block">Water Level</span>
                          <span className="font-bold text-slate-800">{station.water_level_m} m</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 block">Danger Level</span>
                          <span className="font-bold text-rose-700">{station.danger_level_m} m</span>
                        </div>
                      </div>
                      <p className="text-[11px] text-slate-700 font-medium">{station.simple_status}</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </>
          )}
        </MapContainer>

        {/* Selected District Overlay Drawer */}
        {selectedFeature && (
          <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:w-96 bg-slate-900/95 border border-slate-700 backdrop-blur-md rounded-xl p-4 shadow-2xl z-20 space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  {selectedFeature.state}
                </span>
                <h3 className="text-lg font-bold text-white leading-tight">
                  {selectedFeature.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => { setSelectedFeature(null); setShowGoogleEmbed(false); }}
                className="text-slate-400 hover:text-white p-1 text-xs"
              >
                ✕
              </button>
            </div>

            {/* Severity Pill */}
            <div className="flex items-center gap-2">
              <span
                className="px-2.5 py-1 rounded text-xs font-bold text-white"
                style={{ backgroundColor: selectedFeature.fill_color || '#16a34a' }}
              >
                {selectedFeature.risk_category?.toUpperCase()} ({Math.round(selectedFeature.risk_score)}/100)
              </span>
              <span className="text-xs text-slate-400">
                {selectedFeature.hazard_type || 'Disaster'} Risk
              </span>
            </div>

            {/* Environmental Factors */}
            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
              {selectedFeature.rainfall_24h_mm !== undefined && (
                <div>
                  <span className="text-slate-400 text-[10px] block">24h Rainfall:</span>
                  <span className="font-semibold text-slate-200">{selectedFeature.rainfall_24h_mm.toFixed(1)} mm</span>
                </div>
              )}
              {selectedFeature.rainfall_deficit_pct !== undefined && (
                <div>
                  <span className="text-slate-400 text-[10px] block">Rainfall Deficit:</span>
                  <span className="font-semibold text-amber-300">-{selectedFeature.rainfall_deficit_pct}%</span>
                </div>
              )}
              {selectedFeature.river_level_m !== undefined && selectedFeature.river_level_m > 0 && (
                <div>
                  <span className="text-slate-400 text-[10px] block">River Level:</span>
                  <span className="font-semibold text-slate-200">{selectedFeature.river_level_m} m</span>
                </div>
              )}
              <div>
                <span className="text-slate-400 text-[10px] block">Soil Moisture:</span>
                <span className="font-semibold text-slate-200">{selectedFeature.soil_moisture_pct?.toFixed(1) || 50}%</span>
              </div>
            </div>

            {/* Main Risk Factor */}
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Main Reason for Risk:
              </span>
              <p className="text-xs text-slate-200 mt-0.5 leading-relaxed">
                {selectedFeature.main_factors || 'Monsoon runoff accumulation and terrain depression.'}
              </p>
            </div>

            {/* Recommended Action */}
            <div className="bg-cyan-950/40 border border-cyan-800/40 p-2.5 rounded-lg">
              <span className="text-[10px] font-semibold text-cyan-300 uppercase tracking-wider block">
                What People Should Do:
              </span>
              <p className="text-xs text-cyan-100 mt-0.5 leading-relaxed font-medium">
                {selectedFeature.recommended_action || selectedFeature.agricultural_recommendations || 'Conserve water and follow district safety bulletins.'}
              </p>
            </div>

            {/* Google Maps Actions */}
            <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${selectedFeature.center ? selectedFeature.center[0] : 22.5},${selectedFeature.center ? selectedFeature.center[1] : 80.0}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 text-center py-1.5 px-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition shadow"
              >
                Open in Google Maps ↗
              </a>
              <button
                type="button"
                onClick={() => setShowGoogleEmbed(!showGoogleEmbed)}
                className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
              >
                {showGoogleEmbed ? 'Hide View' : 'Google Satellite'}
              </button>
            </div>

            {/* Embedded Google Map Satellite / Street View */}
            {showGoogleEmbed && selectedFeature.center && (
              <div className="mt-2 rounded-lg overflow-hidden border border-slate-700 h-44">
                <iframe
                  title={`Google Map - ${selectedFeature.name}`}
                  width="100%"
                  height="100%"
                  loading="lazy"
                  src={`https://maps.google.com/maps?q=${selectedFeature.center[0]},${selectedFeature.center[1]}&t=k&z=10&ie=UTF8&iwloc=&output=embed`}
                  className="border-0"
                />
              </div>
            )}
          </div>
        )}

        {/* Selected River Overlay Drawer */}
        {selectedRiver && (
          <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:w-96 bg-slate-900/95 border border-cyan-700/80 backdrop-blur-md rounded-xl p-4 shadow-2xl z-20 space-y-2.5">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider block">
                  Major Indian River System
                </span>
                <h3 className="text-base font-bold text-white">
                  {selectedRiver.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRiver(null)}
                className="text-slate-400 hover:text-white p-1 text-xs"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <div>
                <span className="text-slate-400 text-[10px] block">Total Length:</span>
                <span className="font-semibold text-slate-200">{selectedRiver.length_km} km</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Average Discharge:</span>
                <span className="font-semibold text-cyan-300">{selectedRiver.discharge_cusecs?.toLocaleString()} cusecs</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Source & Basin:
              </span>
              <p className="text-xs text-slate-200 mt-0.5">{selectedRiver.origin}</p>
            </div>

            <div className="p-2 rounded bg-cyan-950/50 border border-cyan-800 text-xs text-cyan-200 font-medium">
              {selectedRiver.current_status}
            </div>

            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(selectedRiver.name + ' river India')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block text-center py-1.5 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition"
            >
              Trace in Google Maps ↗
            </a>
          </div>
        )}

        {/* Floating Map Legend & Base Map Indicator */}
        <div className="absolute top-4 right-4 bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 text-xs z-10 hidden sm:block backdrop-blur-md max-w-[210px]">
          <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-slate-800">
            <span className="font-bold text-[10px] text-cyan-400 uppercase tracking-wider">
              {tileConfig.label}
            </span>
          </div>

          <span className="font-bold text-[11px] text-slate-300 block mb-1.5 uppercase tracking-wider">
            {activeLayer === 'drought' ? 'Drought Severity' : activeLayer === 'rivers' ? 'River System' : 'Severity Scale'}
          </span>
          {activeLayer !== 'rivers' ? (
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-green-600 inline-block shrink-0"></span>
                <span className="text-slate-300 text-[11px]">Low Risk (0–24)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-yellow-500 inline-block shrink-0"></span>
                <span className="text-slate-300 text-[11px]">Moderate Risk (25–49)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-orange-600 inline-block shrink-0"></span>
                <span className="text-slate-300 text-[11px]">High Risk (50–74)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-red-600 inline-block shrink-0"></span>
                <span className="text-slate-300 text-[11px]">Severe Risk (75–89)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-red-900 inline-block shrink-0"></span>
                <span className="text-slate-300 text-[11px]">Critical Risk (90–100)</span>
              </div>
            </div>
          ) : (
            <div className="space-y-1 text-[11px] text-slate-300">
              <div className="flex items-center gap-2">
                <span className="w-4 h-1 bg-cyan-500 inline-block"></span>
                <span>Normal River Course</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-4 h-1 bg-rose-500 inline-block"></span>
                <span>Critical / High Crest</span>
              </div>
              <div className="flex items-center gap-2 mt-1 pt-1 border-t border-slate-800">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border-2 border-emerald-500 inline-block"></span>
                <span>Gauge Station (Normal)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border-2 border-rose-600 inline-block"></span>
                <span>Gauge (High / Critical)</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
