import React, { useState } from 'react';
import { Sprout, Home, Shield, CheckSquare, Square, ChevronRight, Download, Share2 } from 'lucide-react';
import { PersonaRecommendations, RiskCategory } from '../types';

interface RecommendationsCardProps {
  recommendations: PersonaRecommendations;
  riskCategory: RiskCategory;
  locationName: string;
  hazardType?: 'flood' | 'drought';
}

export const RecommendationsCard: React.FC<RecommendationsCardProps> = ({
  recommendations,
  riskCategory,
  locationName,
  hazardType = 'flood'
}) => {
  const [activeTab, setActiveTab] = useState<'farmers' | 'residents' | 'authorities'>('farmers');
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleCheck = (id: string) => {
    setCheckedItems(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const currentList = recommendations[activeTab] || [];

  const tabConfig = {
    farmers: {
      label: 'Farmers & Agri-Producers',
      icon: Sprout,
      color: 'emerald',
      desc: 'Agronomic protocols, irrigation schedules, livestock relocation, and crop protection.'
    },
    residents: {
      label: 'Local Residents & Families',
      icon: Home,
      color: 'cyan',
      desc: 'Life-safety preparedness, household water security, evacuation pathways, and go-bags.'
    },
    authorities: {
      label: 'Disaster Authorities & DDMA',
      icon: Shield,
      color: 'amber',
      desc: 'NDRF staging, embankment patrols, water tanker rosters, and wireless emergency alerts.'
    }
  };

  const CurrentIcon = tabConfig[activeTab].icon;

  return (
    <div className="glass-panel p-6 rounded-2xl border border-slate-700/60 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-700/50 mb-5 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-slate-100 tracking-tight">
              Actionable Resilience Protocols
            </h3>
            <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
              riskCategory === 'Critical' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
              riskCategory === 'Severe' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' :
              riskCategory === 'High' ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40' :
              'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}>
              {riskCategory} Advisory Level
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Targeted preventive action checklist for <strong className="text-slate-200">{locationName}</strong>
          </p>
        </div>

        {/* Persona Segment Tabs */}
        <div className="flex items-center bg-navy-900/90 p-1 rounded-xl border border-slate-700/50">
          {(['farmers', 'residents', 'authorities'] as const).map(tab => {
            const Icon = tabConfig[tab].icon;
            const isActive = activeTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-slate-700/70 text-cyan-300 shadow-sm border border-cyan-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="capitalize">{tab}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Context Banner */}
      <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800 mb-4 flex items-center gap-3">
        <div className="p-2 rounded-lg bg-slate-800/80 text-cyan-400">
          <CurrentIcon className="w-4 h-4" />
        </div>
        <div>
          <h4 className="text-xs font-bold text-slate-200">{tabConfig[activeTab].label}</h4>
          <p className="text-[11px] text-slate-400">{tabConfig[activeTab].desc}</p>
        </div>
      </div>

      {/* Actionable Checkpoints */}
      <div className="space-y-2.5 mb-5">
        {currentList.map((action, idx) => {
          const itemKey = `${activeTab}-${idx}`;
          const isDone = !!checkedItems[itemKey];
          return (
            <div
              key={itemKey}
              onClick={() => toggleCheck(itemKey)}
              className={`flex items-start gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                isDone
                  ? 'bg-emerald-950/20 border-emerald-500/40 opacity-75'
                  : 'bg-navy-900/60 border-slate-800 hover:border-slate-700 hover:bg-navy-900'
              }`}
            >
              <button className="mt-0.5 shrink-0 text-cyan-400 focus:outline-none">
                {isDone ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Square className="w-4 h-4 text-slate-500" />
                )}
              </button>
              <div className="flex-1">
                <p className={`text-xs leading-relaxed ${isDone ? 'line-through text-slate-400' : 'text-slate-200'}`}>
                  {action}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Checklist Completion Progress */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-800 text-xs text-slate-400">
        <span>
          Readiness Progress:{' '}
          <strong className="text-cyan-400 font-mono">
            {Object.keys(checkedItems).filter(k => k.startsWith(activeTab) && checkedItems[k]).length} / {currentList.length}
          </strong>{' '}
          verified
        </span>
        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs transition"
        >
          <Download className="w-3.5 h-3.5" />
          Export Field PDF
        </button>
      </div>
    </div>
  );
};

