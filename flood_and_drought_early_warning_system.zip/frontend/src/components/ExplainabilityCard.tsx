import React from 'react';
import { HelpCircle, CheckCircle2, AlertOctagon, TrendingUp, Sparkles, BrainCircuit } from 'lucide-react';
import { FactorContribution } from '../types';

interface ExplainabilityCardProps {
  factors: FactorContribution[];
  plainReasons: string[];
  hazardType?: 'flood' | 'drought';
}

export const ExplainabilityCard: React.FC<ExplainabilityCardProps> = ({
  factors,
  plainReasons,
  hazardType = 'flood'
}) => {
  return (
    <div className="glass-panel p-6 rounded-2xl border border-cyan-500/30 relative overflow-hidden shadow-xl">
      {/* Background glow decoration */}
      <div className="absolute -top-16 -right-16 w-44 h-44 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-700/50 mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <BrainCircuit className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100 tracking-tight">
                Explainable AI (XAI) Attribution
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                TreeSHAP Verified
              </span>
            </div>
            <p className="text-xs text-slate-400">
              WHY IS THIS LOCATION AT RISK? Plain-English physical attribution
            </p>
          </div>
        </div>
      </div>

      {/* Section 1: Plain-English Physical Triggers */}
      <div className="mb-6">
        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          Key Contributing Environmental Drivers
        </h4>
        <div className="space-y-2">
          {plainReasons.map((reason, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-700/50 text-slate-200 text-xs leading-relaxed"
            >
              <div className="mt-0.5 shrink-0">
                <AlertOctagon className="w-4 h-4 text-amber-400" />
              </div>
              <span>{reason}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Section 2: Quantitative Feature Importance Attribution */}
      <div>
        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          Factor Importance Weighting (% Attribution)
        </h4>

        <div className="space-y-3">
          {factors.map((factor, idx) => {
            const isIncreaser = factor.impact === 'increases_risk';
            return (
              <div key={idx} className="p-3 rounded-lg bg-navy-900/70 border border-slate-800/80">
                <div className="flex justify-between items-center text-xs mb-1.5">
                  <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${isIncreaser ? 'bg-red-400' : 'bg-emerald-400'}`} />
                    {factor.feature_label}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-400 font-medium">
                      Value: <strong className="text-slate-200">{String(factor.value)}</strong>
                    </span>
                    <span className="font-mono font-bold text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded text-[11px] border border-cyan-800/50">
                      {factor.importance}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${
                      isIncreaser
                        ? 'bg-gradient-to-r from-amber-500 to-red-500'
                        : 'bg-gradient-to-r from-teal-500 to-emerald-400'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(8, factor.importance))}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-400 mt-1.5 italic">
                  {factor.explanation}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Governance Note Footer */}
      <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1.5 text-slate-400">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          Hydrological physics consistency: No contradictory factors
        </span>
        <span className="font-mono text-slate-400">AquaSentinel XAI Engine v1.0</span>
      </div>
    </div>
  );
};

