import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-800 mt-16 text-xs text-slate-400 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          {/* Col 1 */}
          <div className="space-y-2 md:col-span-1">
            <span className="font-bold text-sm text-white block">AquaSentinel AI</span>
            <p className="text-slate-400 text-xs leading-relaxed">
              Flood and drought early warning decision-support platform designed for citizens, farmers, and disaster management teams.
            </p>
          </div>

          {/* Col 2 */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-300 text-xs">Features</h4>
            <ul className="space-y-1 text-slate-400 text-xs">
              <li>Flood Map of India</li>
              <li>Drought Map of India</li>
              <li>River Water Level Monitoring</li>
              <li>Direct Risk Check</li>
            </ul>
          </div>

          {/* Col 3 */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-300 text-xs">Safety Guides</h4>
            <ul className="space-y-1 text-slate-400 text-xs">
              <li>Before and During Floods</li>
              <li>Drought & Water Conservation</li>
              <li>Farmer Protective Actions</li>
              <li>Emergency Phone Numbers</li>
            </ul>
          </div>

          {/* Col 4 */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-slate-300 text-xs">Public Notice</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              This system provides early warning risk estimates. Official evacuation orders are issued by District Collectors and State Disaster Management Authorities.
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-xs">
          <span>AquaSentinel AI — Green Planet GP-03 Hackathon</span>
          <span>Designed for simplicity and public safety</span>
        </div>
      </div>
    </footer>
  );
};
