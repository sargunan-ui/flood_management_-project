import React from 'react';
import { RiskCategory } from '../types';

interface RiskGaugeProps {
  score: number;
  category: RiskCategory;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  hazardType?: 'flood' | 'drought';
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  score,
  category,
  label = 'Disaster Risk Index',
  size = 'md',
  hazardType = 'flood'
}) => {
  const clampedScore = Math.min(100, Math.max(0, score));
  
  // Dimensions
  const dim = size === 'sm' ? 120 : size === 'lg' ? 220 : 160;
  const strokeWidth = size === 'sm' ? 10 : size === 'lg' ? 16 : 12;
  const radius = (dim - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  // Arc angle: 260 degrees
  const arcLength = circumference * (260 / 360);
  const strokeDashoffset = arcLength - (clampedScore / 100) * arcLength;

  // Category Color mapping
  const getColor = () => {
    switch (category) {
      case 'Critical': return '#ef4444'; // Red
      case 'Severe': return '#f97316';   // Orange
      case 'High': return '#eab308';     // Yellow
      case 'Moderate': return '#06b6d4'; // Cyan
      case 'Low':
      default: return '#10b981';         // Emerald
    }
  };

  const color = getColor();

  return (
    <div className="flex flex-col items-center justify-center p-2 relative">
      <div className="relative flex items-center justify-center" style={{ width: dim, height: dim }}>
        <svg
          width={dim}
          height={dim}
          viewBox={`0 0 ${dim} ${dim}`}
          className="transform -rotate-130"
        >
          {/* Background Arc */}
          <circle
            cx={dim / 2}
            cy={dim / 2}
            r={radius}
            fill="transparent"
            stroke="#1c2541"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
          />
          {/* Animated Value Arc */}
          <circle
            cx={dim / 2}
            cy={dim / 2}
            r={radius}
            fill="transparent"
            stroke={color}
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
            style={{
              filter: `drop-shadow(0 0 6px ${color}80)`
            }}
          />
        </svg>

        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className={`font-mono font-extrabold ${size === 'lg' ? 'text-4xl' : size === 'sm' ? 'text-2xl' : 'text-3xl'} tracking-tight`} style={{ color }}>
            {score.toFixed(1)}
          </span>
          <span className="text-[10px] uppercase font-semibold text-slate-400 mt-0.5">
            / 100
          </span>
        </div>
      </div>

      <div className="mt-1 flex flex-col items-center">
        <span
          className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider border"
          style={{
            backgroundColor: `${color}18`,
            borderColor: `${color}60`,
            color: color
          }}
        >
          {category} Risk
        </span>
        {label && (
          <span className="text-xs text-slate-400 mt-1 font-medium">{label}</span>
        )}
      </div>
    </div>
  );
};

