import React from 'react';
import { Radio, Database, ShieldCheck, RefreshCw } from 'lucide-react';

interface LiveWeatherBannerProps {
  isLive: boolean;
  sourceText?: string;
  onRefresh?: () => void;
  isLoading?: boolean;
}

export const LiveWeatherBanner: React.FC<LiveWeatherBannerProps> = ({
  isLive,
  sourceText = isLive ? 'Open-Meteo Global Meteorological API' : 'Calibrated Hydrometeorological Benchmark Dataset',
  onRefresh,
  isLoading = false
}) => {
  return (
    <div className={`py-1.5 px-4 rounded-xl border flex flex-wrap items-center justify-between text-xs gap-2 ${
      isLive
        ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
        : 'bg-navy-900/80 border-cyan-500/30 text-cyan-300'
    }`}>
      <div className="flex items-center gap-2">
        {isLive ? (
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
        ) : (
          <Database className="w-3.5 h-3.5 text-cyan-400" />
        )}

        <span className="font-semibold uppercase tracking-wider text-[11px]">
          {isLive ? 'Live Weather Stream' : 'Calibrated Demonstration Mode'}
        </span>
        <span className="text-slate-400 text-[11px] hidden sm:inline">•</span>
        <span className="text-slate-300 text-[11px] truncate max-w-md">
          {sourceText}
        </span>
      </div>

      <div className="flex items-center gap-3">
        {!isLive && (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
            DEMO BENCHMARK DATA
          </span>
        )}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white transition disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
        )}
      </div>
    </div>
  );
};

