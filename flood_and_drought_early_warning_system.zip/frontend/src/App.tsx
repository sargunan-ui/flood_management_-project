import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ThreatTicker } from './components/ThreatTicker';

import { DashboardPage } from './pages/DashboardPage';
import { HazardMapPage } from './pages/HazardMapPage';
import { RiverMonitoringPage } from './pages/RiverMonitoringPage';
import { CheckRiskPage } from './pages/CheckRiskPage';
import { AlertsPage } from './pages/AlertsPage';
import { SafetyGuidePage } from './pages/SafetyGuidePage';
import { HistoryPage } from './pages/HistoryPage';
import { AboutPage } from './pages/AboutPage';
import { AquaAIPage } from './pages/AquaAIPage';
import { LoginPage } from './pages/LoginPage';

import { DashboardSummary, DistrictProfile, AlertItem } from './types';
import { api } from './services/api';
import { BENCHMARK_DISTRICTS, BENCHMARK_SUMMARY, BENCHMARK_ALERTS } from './data/benchmarkData';

function AppContent() {
  const { user, isAuthenticated, isLoading } = useAuth();
  
  const getInitialPage = () => {
    const hash = window.location.hash.replace('#', '').trim();
    return hash || 'home';
  };

  const [activePage, setActivePage] = useState<string>(getInitialPage);
  const [summary, setSummary] = useState<DashboardSummary | null>(BENCHMARK_SUMMARY);
  const [districts, setDistricts] = useState<DistrictProfile[]>(BENCHMARK_DISTRICTS);
  const [alerts, setAlerts] = useState<AlertItem[]>(BENCHMARK_ALERTS);
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>('assam_dhemaji');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').trim();
      if (hash) {
        setActivePage(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [sumData, distData, alertData] = await Promise.allSettled([
        api.getDashboard(),
        api.getDistricts(),
        api.getAlerts()
      ]);

      if (sumData.status === 'fulfilled') setSummary(sumData.value);
      if (distData.status === 'fulfilled') {
        setDistricts(distData.value);
        if (distData.value.length > 0 && !selectedDistrictId) {
          setSelectedDistrictId(distData.value[0].id);
        }
      }
      if (alertData.status === 'fulfilled') setAlerts(alertData.value);
    } catch (err) {
      console.error('Failed to load application telemetry:', err);
    }
  };

  const handleAcknowledgeAlert = async (id: string, operator: string = 'District Disaster Officer') => {
    try {
      await api.acknowledgeAlert(id, operator);
      setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Acknowledged', acknowledged_by: operator } : a));
      if (summary) {
        setSummary(prev => prev ? {
          ...prev,
          active_alerts_count: Math.max(0, prev.active_alerts_count - 1),
          recent_alerts: prev.recent_alerts.map(a => a.id === id ? { ...a, status: 'Acknowledged' } : a)
        } : null);
      }
    } catch (err) {
      console.error('Failed to acknowledge alert:', err);
    }
  };

  const handleNavigateWithContext = (page: string, context?: any) => {
    if (context?.districtId) {
      setSelectedDistrictId(context.districtId);
    }
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeAlerts = alerts.filter(a => a.status === 'Active');

  // Gateway check: User must log in first before using the dashboard
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300">
        <div className="w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="font-semibold text-sm">Verifying Sovereign Identity...</p>
      </div>
    );
  }

  if (!user || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
        <ThreatTicker alerts={alerts} />
        <LoginPage onSuccess={() => setActivePage('home')} />
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Active Disaster Threat Ticker */}
      <ThreatTicker
        alerts={alerts}
        onSelectAlert={() => {
          setActivePage('alerts');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Navigation Bar */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        activeAlertCount={activeAlerts.length}
      />

      {/* Main Page Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {activePage === 'home' && (
          <DashboardPage
            summary={summary}
            districts={districts}
            alerts={alerts}
            onNavigate={handleNavigateWithContext}
          />
        )}

        {(activePage === 'hazard-map' || activePage === 'flood-map' || activePage === 'drought-map') && (
          <HazardMapPage
            districts={districts}
            initialDistrictId={selectedDistrictId}
            initialHazardMode={activePage === 'drought-map' ? 'drought' : activePage === 'flood-map' ? 'flood' : 'combined'}
            onNavigateToCheckRisk={(id) => handleNavigateWithContext('check-risk', { districtId: id })}
          />
        )}

        {activePage === 'rivers' && (
          <RiverMonitoringPage />
        )}

        {activePage === 'check-risk' && (
          <CheckRiskPage
            districts={districts}
            initialDistrictId={selectedDistrictId}
            onNavigateToSafety={() => handleNavigateWithContext('safety-guide')}
          />
        )}

        {activePage === 'alerts' && (
          <AlertsPage
            alerts={alerts}
            onAcknowledgeAlert={handleAcknowledgeAlert}
          />
        )}

        {activePage === 'aqua-ai' && (
          <AquaAIPage
            districts={districts}
            selectedDistrictId={selectedDistrictId}
            onSelectDistrict={(id) => setSelectedDistrictId(id)}
          />
        )}

        {activePage === 'safety-guide' && (
          <SafetyGuidePage />
        )}

        {activePage === 'history' && (
          <HistoryPage
            districts={districts}
          />
        )}

        {activePage === 'about' && (
          <AboutPage />
        )}

        {activePage === 'login' && (
          <LoginPage
            onSuccess={() => setActivePage('home')}
          />
        )}
      </main>

      {/* Clean Global Footer */}
      <Footer />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
