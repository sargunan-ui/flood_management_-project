import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ThreatTicker } from './components/ThreatTicker';

import { DashboardPage } from './pages/DashboardPage';
import { FloodMapPage } from './pages/FloodMapPage';
import { DroughtMapPage } from './pages/DroughtMapPage';
import { RiverMonitoringPage } from './pages/RiverMonitoringPage';
import { CheckRiskPage } from './pages/CheckRiskPage';
import { AlertsPage } from './pages/AlertsPage';
import { SafetyGuidePage } from './pages/SafetyGuidePage';
import { HistoryPage } from './pages/HistoryPage';
import { AboutPage } from './pages/AboutPage';
import { AquaAIPage } from './pages/AquaAIPage';
import { LoginPage } from './pages/LoginPage';

import { DashboardSummary, DistrictProfile, AlertItem } from './types';
import { api } from './services/api';

function AppContent() {
  const [activePage, setActivePage] = useState<string>('home');
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [districts, setDistricts] = useState<DistrictProfile[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>('assam_dhemaji');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [sumData, distData, alertData] = await Promise.allSettled([
        api.getDashboard(),
        api.getDistricts(),
        api.getAlerts()
      ]);

      if (sumData.status === 'fulfilled') setSummary(sumData.value);
      if (distData.status === 'fulfilled') {
        setDistricts(distData.value);
        if (distData.value.length > 0 && !selectedDistrictId) {
          setSelectedDistrictId(distData.value[0].id);
        }
      }
      if (alertData.status === 'fulfilled') setAlerts(alertData.value);
    } catch (err) {
      console.error('Failed to load application telemetry:', err);
    }
  };

  const handleAcknowledgeAlert = async (id: string, operator: string = 'District Disaster Officer') => {
    try {
      await api.acknowledgeAlert(id, operator);
      setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'Acknowledged', acknowledged_by: operator } : a));
      if (summary) {
        setSummary(prev => prev ? {
          ...prev,
          active_alerts_count: Math.max(0, prev.active_alerts_count - 1),
          recent_alerts: prev.recent_alerts.map(a => a.id === id ? { ...a, status: 'Acknowledged' } : a)
        } : null);
      }
    } catch (err) {
      console.error('Failed to acknowledge alert:', err);
    }
  };

  const handleNavigateWithContext = (page: string, context?: any) => {
    if (context?.districtId) {
      setSelectedDistrictId(context.districtId);
    }
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeAlerts = alerts.filter(a => a.status === 'Active');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Active Disaster Threat Ticker */}
      <ThreatTicker
        alerts={alerts}
        onSelectAlert={() => {
          setActivePage('alerts');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Navigation Bar */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        activeAlertCount={activeAlerts.length}
      />

      {/* Main Page Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
        {activePage === 'home' && (
          <DashboardPage
            summary={summary}
            districts={districts}
            alerts={alerts}
            onNavigate={handleNavigateWithContext}
          />
        )}

        {activePage === 'flood-map' && (
          <FloodMapPage
            districts={districts}
            initialDistrictId={selectedDistrictId}
            onNavigateToCheckRisk={(id) => handleNavigateWithContext('check-risk', { districtId: id })}
          />
        )}

        {activePage === 'drought-map' && (
          <DroughtMapPage
            districts={districts}
            initialDistrictId={selectedDistrictId}
            onNavigateToCheckRisk={(id) => handleNavigateWithContext('check-risk', { districtId: id })}
          />
        )}

        {activePage === 'rivers' && (
          <RiverMonitoringPage />
        )}

        {activePage === 'check-risk' && (
          <CheckRiskPage
            districts={districts}
            initialDistrictId={selectedDistrictId}
            onNavigateToSafety={() => handleNavigateWithContext('safety-guide')}
          />
        )}

        {activePage === 'alerts' && (
          <AlertsPage
            alerts={alerts}
            onAcknowledgeAlert={handleAcknowledgeAlert}
          />
        )}

        {activePage === 'aqua-ai' && (
          <AquaAIPage
            districts={districts}
            selectedDistrictId={selectedDistrictId}
            onSelectDistrict={(id) => setSelectedDistrictId(id)}
          />
        )}

        {activePage === 'safety-guide' && (
          <SafetyGuidePage />
        )}

        {activePage === 'history' && (
          <HistoryPage
            districts={districts}
          />
        )}

        {activePage === 'about' && (
          <AboutPage />
        )}

        {activePage === 'login' && (
          <LoginPage
            onSuccess={() => setActivePage('home')}
          />
        )}
      </main>

      {/* Clean Global Footer */}
      <Footer />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
