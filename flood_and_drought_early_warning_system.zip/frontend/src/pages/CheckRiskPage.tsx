import React, { useState, useEffect } from 'react';
import {
  CloudRain,
  Sun,
  Waves,
  Calendar,
  Layers,
  Sprout,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Info,
  ShieldAlert,
  Droplets,
  RotateCcw
} from 'lucide-react';
import { DistrictProfile } from '../types';
import { api } from '../services/api';

interface CheckRiskPageProps {
  districts: DistrictProfile[];
  initialDistrictId?: string;
  onNavigateToSafety?: () => void;
}

export const CheckRiskPage: React.FC<CheckRiskPageProps> = ({
  districts,
  initialDistrictId,
  onNavigateToSafety
}) => {
  // Extract unique states
  const states = Array.from(new Set(districts.map(d => d.state))).sort();

  const [selectedState, setSelectedState] = useState<string>(() => {
    if (initialDistrictId) {
      const d = districts.find(dist => dist.id === initialDistrictId);
      if (d) return d.state;
    }
    return states[0] || 'Assam';
  });

  const availableDistricts = districts.filter(d => d.state === selectedState);

  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(() => {
    if (initialDistrictId) return initialDistrictId;
    return availableDistricts[0]?.id || districts[0]?.id || '';
  });

  // Hazard Mode: 'flood' or 'drought'
  const [hazardMode, setHazardMode] = useState<'flood' | 'drought'>('flood');

  // The 5 Core User-Requested Input Values
  const [rainAmount, setRainAmount] = useState<number>(120); // mm
  const [riverFlow, setRiverFlow] = useState<number>(11.5); // meters (gauge level)
  const [noOfDaysRain, setNoOfDaysRain] = useState<number>(4); // days
  const [drainageFacility, setDrainageFacility] = useState<'Poor' | 'Moderate' | 'Good'>('Moderate');
  const [irrigationFacility, setIrrigationFacility] = useState<'Rainfed' | 'Canal' | 'Drip' | 'Farm Pond'>('Canal');

  // UI state
  const [loading, setLoading] = useState(false);
  const [predictionResult, setPredictionResult] = useState<any | null>(() => ({
    hazard: 'flood',
    probability: 86,
    riskScore: 86.4,
    category: 'Severe',
    confidence: 'High (Calibrated Ensemble Prediction)',
    explanation: [
      'AI Flood Prediction: 86% chance of flood based on 120 mm rain over 4 day(s), river flow at 11.5 m, Moderate drainage, and Canal irrigation system.',
      'Accumulated precipitation of 120 mm over 4 consecutive days has pushed local watershed soil saturation above 85%.'
    ],
    factors: [
      { feature: 'rainfall_24h', feature_label: '24-Hour Rainfall (mm)', value: '120 mm', importance: 32, impact: 'increases_risk', explanation: 'Torrential 120 mm precipitation exceeds local drainage holding limits.' },
      { feature: 'river_water_level', feature_label: 'River Flow Gauge (m)', value: '11.5 m', importance: 25, impact: 'increases_risk', explanation: 'River gauge level is nearing regional warning threshold (10.0 m).' },
      { feature: 'no_of_days_rain', feature_label: 'Rainfall Duration', value: '4 days', importance: 18, impact: 'increases_risk', explanation: '4 continuous days of rain saturated upper catchment watersheds.' },
      { feature: 'drainage_facility', feature_label: 'Drainage Condition', value: 'Moderate', importance: 15, impact: 'decreases_risk', explanation: 'Standard municipal culverts functioning at typical throughput.' },
      { feature: 'irrigation_facility', feature_label: 'Irrigation System', value: 'Canal Network', importance: 10, impact: 'increases_risk', explanation: 'Canal embankment vulnerable to overflow with elevated river flow.' }
    ],
    recommendations: {
      residents: [
        'Move drinking water vessels and essential medicines to elevated shelving.',
        'Avoid walking, cycling, or driving across submerged low-level bridges or causeways.',
        'Keep emergency helpline numbers (112 / 1070 / 1077) on rapid speed dial.'
      ],
      farmers: [
        'Open and clear field drainage bunds to evacuate ponding stormwater from crop roots.',
        'Relocate diesel pump sets, tractors, and livestock to designated high-ground shelters.',
        'Document standing paddy or pulse crop growth stage for PMFBY insurance coverage.'
      ],
      authorities: [
        'Position SDRF motorized rescue boats near vulnerable riverside hamlets.',
        'Inspect barrage sluice gates and canal siphon regulators for debris blockage.',
        'Issue Level-3 CAP emergency broadcast bulletin to registered village panchayats.'
      ]
    }
  }));
  const [activePersona, setActivePersona] = useState<'residents' | 'farmers' | 'authorities'>('residents');

  // Sync selected district when state changes
  useEffect(() => {
    const inState = districts.filter(d => d.state === selectedState);
    if (inState.length > 0 && !inState.some(d => d.id === selectedDistrictId)) {
      setSelectedDistrictId(inState[0].id);
    }
  }, [selectedState, districts]);

  const currentDist = districts.find(d => d.id === selectedDistrictId) || districts[0];

  // Quick Scenarios
  const handleApplyPreset = (preset: 'flash-flood' | 'severe-drought' | 'normal-monsoon' | 'drip-resilience') => {
    if (preset === 'flash-flood') {
      setHazardMode('flood');
      setRainAmount(210);
      setRiverFlow(16.5);
      setNoOfDaysRain(6);
      setDrainageFacility('Poor');
      setIrrigationFacility('Canal');
    } else if (preset === 'severe-drought') {
      setHazardMode('drought');
      setRainAmount(5);
      setRiverFlow(1.5);
      setNoOfDaysRain(0);
      setDrainageFacility('Poor');
      setIrrigationFacility('Rainfed');
    } else if (preset === 'normal-monsoon') {
      setHazardMode('flood');
      setRainAmount(55);
      setRiverFlow(6.8);
      setNoOfDaysRain(2);
      setDrainageFacility('Moderate');
      setIrrigationFacility('Canal');
    } else if (preset === 'drip-resilience') {
      setHazardMode('drought');
      setRainAmount(15);
      setRiverFlow(3.2);
      setNoOfDaysRain(1);
      setDrainageFacility('Good');
      setIrrigationFacility('Drip');
    }
  };

  // Run AI Hazard Prediction
  const handlePredictHazard = async () => {
    if (!currentDist) return;
    setLoading(true);

    try {
      if (hazardMode === 'flood') {
        const drainageCode = drainageFacility === 'Poor' ? 0 : drainageFacility === 'Good' ? 2 : 1;
        const res = await api.predictFlood({
          location_name: `${currentDist.name}, ${currentDist.state}`,
          rainfall_24h: Number(rainAmount),
          rainfall_intensity: Number(rainAmount) > 100 ? 35 : 15,
          rainfall_7d: Number(rainAmount) * Math.max(1.2, noOfDaysRain * 0.7),
          river_water_level: Number(riverFlow),
          soil_moisture: Math.min(100, (currentDist.key_metrics.soil_moisture_pct || 65) + noOfDaysRain * 4.5),
          temperature: 28.0,
          elevation: currentDist.elevation || 45.0,
          drainage_condition: drainageCode,
          drainage_facility: drainageFacility,
          irrigation_facility: irrigationFacility,
          no_of_days_rain: Number(noOfDaysRain),
          historical_flood_occurrence: 3
        });

        setPredictionResult({
          hazard: 'flood',
          probability: Math.round(res.flood_probability * 100),
          riskScore: res.risk_score,
          category: res.risk_category,
          confidence: res.confidence_level,
          explanation: res.plain_english_explanation,
          factors: res.contributing_factors,
          recommendations: res.recommendations
        });
      } else {
        // Drought Prediction
        const calculatedDeficit = Math.max(0, Math.min(100, Math.round(100 - (rainAmount / 40) * 50)));
        const res = await api.predictDrought({
          location_name: `${currentDist.name}, ${currentDist.state}`,
          rainfall_24h: Number(rainAmount),
          rainfall_deficit: calculatedDeficit,
          river_water_level: Number(riverFlow),
          no_of_days_rain: Number(noOfDaysRain),
          consecutive_dry_days: Math.max(0, 35 - noOfDaysRain * 4),
          irrigation_facility: irrigationFacility,
          drainage_facility: drainageFacility,
          temperature: 36.5,
          soil_moisture: Math.max(5, (currentDist.key_metrics.soil_moisture_pct || 22) - (10 - noOfDaysRain)),
          relative_humidity: 32.0,
          vegetation_condition: 28.0,
          historical_rainfall: currentDist.key_metrics.avg_monsoon_rainfall_mm || 650.0
        });

        setPredictionResult({
          hazard: 'drought',
          probability: Math.round(res.drought_probability * 100),
          riskScore: res.severity_score,
          category: res.drought_category,
          confidence: res.confidence_level,
          explanation: res.plain_english_explanation,
          factors: res.contributing_factors,
          recommendations: res.agricultural_recommendations
        });
      }
    } catch (err) {
      console.error('Failed to run AI hazard prediction:', err);
    } finally {
      setLoading(false);
    }
  };

  const getRiskBadgeColor = (cat: string) => {
    switch (cat) {
      case 'Critical':
        return 'bg-red-500/20 text-red-400 border-red-500/40';
      case 'Severe':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/40';
      case 'High':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'Moderate':
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
      case 'Low':
      default:
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
    }
  };

  return (
    <div className="space-y-6 py-6 max-w-5xl mx-auto">
      {/* Title & Introduction */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-800 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </span>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              AI Hazard Simulator & Predictor
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Input rainfall, river flow gauge, duration of rain, drainage, and irrigation facility to calculate real-time flood and drought probabilities with Explainable AI.
          </p>
        </div>

        {/* Hazard Mode Switcher */}
        <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-xl self-start md:self-auto">
          <button
            type="button"
            onClick={() => {
              setHazardMode('flood');
              if (rainAmount < 30) setRainAmount(100);
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition ${
              hazardMode === 'flood'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CloudRain className="w-4 h-4" />
            <span>Flood Prediction</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setHazardMode('drought');
              if (rainAmount > 60) setRainAmount(15);
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition ${
              hazardMode === 'drought'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sun className="w-4 h-4" />
            <span>Drought Prediction</span>
          </button>
        </div>
      </div>

      {/* District & Location Context Bar */}
      <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              State:
            </label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-white font-semibold text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500"
            >
              {states.map((st) => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              District:
            </label>
            <select
              value={selectedDistrictId}
              onChange={(e) => setSelectedDistrictId(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-white font-semibold text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-500"
            >
              {availableDistricts.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Scenario Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-bold text-slate-400 uppercase mr-1">
            Scenarios:
          </span>
          <button
            type="button"
            onClick={() => handleApplyPreset('flash-flood')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-[11px] font-medium transition border border-slate-700"
          >
            Flash Flood
          </button>
          <button
            type="button"
            onClick={() => handleApplyPreset('severe-drought')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-medium transition border border-slate-700"
          >
            Severe Drought
          </button>
          <button
            type="button"
            onClick={() => handleApplyPreset('normal-monsoon')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-emerald-300 text-[11px] font-medium transition border border-slate-700"
          >
            Normal Monsoon
          </button>
          <button
            type="button"
            onClick={() => handleApplyPreset('drip-resilience')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-purple-300 text-[11px] font-medium transition border border-slate-700"
          >
            Drip Resilient
          </button>
        </div>
      </div>

      {/* The 5 Main AI Prediction Input Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>Predictor Parameters</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono">
                5 Active Inputs
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Tune any value or use the sliders to simulate environmental shifts.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setRainAmount(100);
              setRiverFlow(10.0);
              setNoOfDaysRain(3);
              setDrainageFacility('Moderate');
              setIrrigationFacility('Canal');
            }}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 1. Rain (mm) */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CloudRain className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  1. Rain (Rainfall Amount)
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="0"
                  max="400"
                  value={rainAmount}
                  onChange={(e) => setRainAmount(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 text-cyan-300 font-mono font-bold text-sm px-2 py-1 rounded text-right focus:outline-none focus:border-cyan-500"
                />
                <span className="text-xs font-bold text-slate-400">mm</span>
              </div>
            </div>

            <input
              type="range"
              min="0"
              max="350"
              step="5"
              value={rainAmount}
              onChange={(e) => setRainAmount(Number(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />

            <div className="flex justify-between text-[11px] text-slate-400">
              <button type="button" onClick={() => setRainAmount(0)} className="hover:text-cyan-400">
                0 mm (Dry)
              </button>
              <button type="button" onClick={() => setRainAmount(50)} className="hover:text-cyan-400">
                50 mm (Normal)
              </button>
              <button type="button" onClick={() => setRainAmount(140)} className="hover:text-cyan-400">
                140 mm (Heavy)
              </button>
              <button type="button" onClick={() => setRainAmount(250)} className="hover:text-cyan-400">
                250+ mm (Cloudburst)
              </button>
            </div>
          </div>

          {/* 2. River Flow (meters) */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Waves className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  2. River Flow (Water Level)
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="0"
                  max="25"
                  step="0.1"
                  value={riverFlow}
                  onChange={(e) => setRiverFlow(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 text-blue-300 font-mono font-bold text-sm px-2 py-1 rounded text-right focus:outline-none focus:border-blue-500"
                />
                <span className="text-xs font-bold text-slate-400">m</span>
              </div>
            </div>

            <input
              type="range"
              min="0"
              max="22"
              step="0.5"
              value={riverFlow}
              onChange={(e) => setRiverFlow(Number(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer"
            />

            <div className="flex justify-between text-[11px] text-slate-400">
              <span className="text-emerald-400">0 - 7m (Safe Baseflow)</span>
              <span className="text-amber-400">10m (Warning Mark)</span>
              <span className="text-rose-400">15m+ (Danger Mark)</span>
            </div>
          </div>

          {/* 3. Number of Days of Rain */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  3. Number of Days of Rain
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="0"
                  max="30"
                  value={noOfDaysRain}
                  onChange={(e) => setNoOfDaysRain(Number(e.target.value))}
                  className="w-20 bg-slate-900 border border-slate-700 text-emerald-300 font-mono font-bold text-sm px-2 py-1 rounded text-right focus:outline-none focus:border-emerald-500"
                />
                <span className="text-xs font-bold text-slate-400">days</span>
              </div>
            </div>

            <input
              type="range"
              min="0"
              max="20"
              step="1"
              value={noOfDaysRain}
              onChange={(e) => setNoOfDaysRain(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />

            <div className="flex justify-between text-[11px] text-slate-400">
              <span>0 days (Protracted dry spell)</span>
              <span>3-4 days (Monsoon spell)</span>
              <span>7+ days (Continuous saturation)</span>
            </div>
          </div>

          {/* 4. Drainage Facility */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                4. Drainage Facility
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDrainageFacility('Poor')}
                className={`p-2.5 rounded-lg border text-left transition ${
                  drainageFacility === 'Poor'
                    ? 'bg-rose-950/60 border-rose-500 text-rose-300 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-bold">Poor / Clogged</div>
                <div className="text-[10px] text-slate-400 mt-0.5">High waterlogging</div>
              </button>

              <button
                type="button"
                onClick={() => setDrainageFacility('Moderate')}
                className={`p-2.5 rounded-lg border text-left transition ${
                  drainageFacility === 'Moderate'
                    ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-bold">Moderate</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Standard culverts</div>
              </button>

              <button
                type="button"
                onClick={() => setDrainageFacility('Good')}
                className={`p-2.5 rounded-lg border text-left transition ${
                  drainageFacility === 'Good'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <div className="text-xs font-bold">Good / Engineered</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Fast discharge & pits</div>
              </button>
            </div>
          </div>
        </div>

        {/* 5. Irrigation Facility (Full Width) */}
        <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sprout className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                5. Irrigation Facility
              </span>
            </div>
            <span className="text-[11px] text-slate-400">
              Crucial for agricultural vulnerability & drought buffering
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              type="button"
              onClick={() => setIrrigationFacility('Rainfed')}
              className={`p-3 rounded-xl border text-left transition ${
                irrigationFacility === 'Rainfed'
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-xs font-bold">Rainfed (No Source)</div>
              <div className="text-[10px] text-slate-400 mt-1">100% weather dependent</div>
            </button>

            <button
              type="button"
              onClick={() => setIrrigationFacility('Canal')}
              className={`p-3 rounded-xl border text-left transition ${
                irrigationFacility === 'Canal'
                  ? 'bg-cyan-950/60 border-cyan-500 text-cyan-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-xs font-bold">Canal Network</div>
              <div className="text-[10px] text-slate-400 mt-1">Regulated surface water</div>
            </button>

            <button
              type="button"
              onClick={() => setIrrigationFacility('Drip')}
              className={`p-3 rounded-xl border text-left transition ${
                irrigationFacility === 'Drip'
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-xs font-bold">Drip / Micro-irrigation</div>
              <div className="text-[10px] text-slate-400 mt-1">Max efficiency & drought resilience</div>
            </button>

            <button
              type="button"
              onClick={() => setIrrigationFacility('Farm Pond')}
              className={`p-3 rounded-xl border text-left transition ${
                irrigationFacility === 'Farm Pond'
                  ? 'bg-blue-950/60 border-blue-500 text-blue-300 shadow-sm'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-xs font-bold">Farm Pond / Check Dam</div>
              <div className="text-[10px] text-slate-400 mt-1">Dual flood detention & recharge</div>
            </button>
          </div>
        </div>

        {/* Predict Action Button */}
        <div>
          <button
            type="button"
            onClick={handlePredictHazard}
            disabled={loading}
            className={`w-full py-4 rounded-xl font-bold text-sm shadow-lg transition flex items-center justify-center gap-2 text-white ${
              hazardMode === 'flood'
                ? 'bg-cyan-600 hover:bg-cyan-500'
                : 'bg-amber-600 hover:bg-amber-500'
            } disabled:opacity-50`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Running Machine Learning Inference & XAI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>
                  Predict Chance of {hazardMode === 'flood' ? 'Flood' : 'Drought'} with AI
                </span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* AI Prediction Results Section */}
      {predictionResult && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
          {/* Top Probability Gauge & Risk Category */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-extrabold text-slate-400 tracking-wider">
                  AI Hazard Prediction Result
                </span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  {currentDist.name}, {currentDist.state}
                </span>
              </div>
              <h2 className="text-2xl font-black text-white mt-1">
                Chance of {predictionResult.hazard === 'flood' ? 'Flood' : 'Drought'}:
              </h2>
            </div>

            <div className="flex items-center gap-4">
              {/* Probability Number Gauge */}
              <div className="text-right">
                <span className="text-4xl font-black tracking-tight text-white">
                  {predictionResult.probability}%
                </span>
                <span className="block text-[11px] font-medium text-slate-400">
                  Predicted Probability
                </span>
              </div>

              {/* Category Badge */}
              <div className={`px-4 py-2.5 rounded-xl border text-sm font-black uppercase tracking-wider ${getRiskBadgeColor(predictionResult.category)}`}>
                {predictionResult.category} RISK
              </div>
            </div>
          </div>

          {/* Plain-English AI Explanation */}
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs uppercase font-extrabold text-cyan-400 tracking-wider">
              <Info className="w-4 h-4" />
              <span>AI Consequence Analysis & Reasoning:</span>
            </div>
            <div className="space-y-1.5 text-xs sm:text-sm text-slate-200 leading-relaxed">
              {predictionResult.explanation.map((exp: string, idx: number) => (
                <p key={idx} className={idx === 0 ? 'font-semibold text-white' : 'text-slate-300'}>
                  {exp}
                </p>
              ))}
            </div>
          </div>

          {/* Contributing Environmental Factors (XAI) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-extrabold text-slate-400 tracking-wider">
                XAI Key Risk Drivers:
              </span>
              <span className="text-[11px] text-slate-500">
                TreeSHAP Feature Attributions
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {predictionResult.factors.slice(0, 6).map((factor: any, i: number) => {
                const isRiskInc = factor.impact === 'increases_risk';
                return (
                  <div
                    key={i}
                    className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white truncate pr-2">
                        {factor.feature_label}
                      </span>
                      <span
                        className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded ${
                          isRiskInc
                            ? 'bg-rose-950 text-rose-400 border border-rose-800'
                            : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        }`}
                      >
                        {isRiskInc ? '+ Increases' : '- Mitigates'}
                      </span>
                    </div>

                    <div className="flex items-baseline justify-between text-xs">
                      <span className="text-slate-400">Value:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {String(factor.value)}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 leading-normal line-clamp-2">
                      {factor.explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Guidelines per Persona */}
          <div className="space-y-3 pt-2 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-extrabold text-slate-400 tracking-wider">
                Tailored Action Guidelines:
              </span>

              {/* Persona Tabs */}
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setActivePersona('residents')}
                  className={`px-3 py-1 rounded text-xs font-bold transition ${
                    activePersona === 'residents'
                      ? 'bg-cyan-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Citizens
                </button>
                <button
                  type="button"
                  onClick={() => setActivePersona('farmers')}
                  className={`px-3 py-1 rounded text-xs font-bold transition ${
                    activePersona === 'farmers'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Farmers
                </button>
                <button
                  type="button"
                  onClick={() => setActivePersona('authorities')}
                  className={`px-3 py-1 rounded text-xs font-bold transition ${
                    activePersona === 'authorities'
                      ? 'bg-rose-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Officials
                </button>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              {predictionResult.recommendations &&
                (predictionResult.recommendations[activePersona] || []).map((action: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{action}</span>
                  </div>
                ))}
            </div>
          </div>

          {onNavigateToSafety && (
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={onNavigateToSafety}
                className="text-xs font-bold text-cyan-400 hover:text-cyan-300 inline-flex items-center gap-1.5 transition"
              >
                <span>Read Full Step-by-Step NDMA Disaster Protocol</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
