import React, { useState, useEffect } from 'react';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import { DistrictProfile } from '../types';
import { api } from '../services/api';

interface CheckRiskPageProps {
  districts: DistrictProfile[];
  initialDistrictId?: string;
  onNavigateToSafety?: () => void;
}

export const CheckRiskPage: React.FC<CheckRiskPageProps> = ({
  districts,
  initialDistrictId,
  onNavigateToSafety
}) => {
  // Extract unique states from districts
  const states = Array.from(new Set(districts.map(d => d.state))).sort();

  const [selectedState, setSelectedState] = useState<string>(() => {
    if (initialDistrictId) {
      const d = districts.find(dist => dist.id === initialDistrictId);
      if (d) return d.state;
    }
    return states[0] || 'Assam';
  });

  // Districts in selected state
  const availableDistricts = districts.filter(d => d.state === selectedState);

  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(() => {
    if (initialDistrictId) return initialDistrictId;
    return availableDistricts[0]?.id || districts[0]?.id || '';
  });

  const [hazardType, setHazardType] = useState<'flood' | 'drought'>('flood');
  const [customRainInput, setCustomRainInput] = useState<number>(100);
  const [customDeficitInput, setCustomDeficitInput] = useState<number>(50);
  const [showAdvancedInputs, setShowAdvancedInputs] = useState<boolean>(false);

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any | null>(null);

  // Sync selected district when state changes
  useEffect(() => {
    const inState = districts.filter(d => d.state === selectedState);
    if (inState.length > 0 && !inState.some(d => d.id === selectedDistrictId)) {
      setSelectedDistrictId(inState[0].id);
    }
  }, [selectedState, districts]);

  // Current district object
  const currentDist = districts.find(d => d.id === selectedDistrictId) || districts[0];

  const handleCheckRisk = async () => {
    if (!currentDist) return;
    setLoading(true);

    try {
      if (hazardType === 'flood') {
        const res = await api.predictFlood({
          location_name: `${currentDist.name}, ${currentDist.state}`,
          rainfall_intensity: customRainInput > 80 ? 35 : 15,
          rainfall_24h: Number(customRainInput),
          rainfall_7d: Number(customRainInput) * 2.8,
          river_water_level: currentDist.key_metrics.river_gauge_m || 8.5,
          soil_moisture: currentDist.key_metrics.soil_moisture_pct || 75.0,
          temperature: 28.0,
          elevation: currentDist.elevation,
          drainage_condition: currentDist.elevation < 40 ? 0 : 1,
          historical_flood_occurrence: 3
        });
        setResult({
          type: 'flood',
          risk_level: res.risk_category,
          score: res.risk_score,
          explanation: res.plain_english_explanation[0] || 'High 24h rainfall and low drainage capacity.',
          factors: res.contributing_factors.slice(0, 3).map(f => `${f.feature_label}: ${f.value} (${f.explanation})`),
          actions: res.recommendations.residents.slice(0, 4)
        });
      } else {
        const res = await api.predictDrought({
          location_name: `${currentDist.name}, ${currentDist.state}`,
          rainfall_deficit: Number(customDeficitInput),
          temperature: 38.0,
          soil_moisture: currentDist.key_metrics.soil_moisture_pct || 18.0,
          relative_humidity: 30.0,
          vegetation_condition: currentDist.key_metrics.vegetation_condition_index || 25.0,
          historical_rainfall: currentDist.key_metrics.avg_monsoon_rainfall_mm || 650.0,
          consecutive_dry_days: currentDist.key_metrics.consecutive_dry_days || 48
        });
        setResult({
          type: 'drought',
          risk_level: res.drought_category,
          score: res.severity_score,
          explanation: res.plain_english_explanation[0] || 'Rainfall has been significantly below normal.',
          factors: res.contributing_factors.slice(0, 3).map(f => `${f.feature_label}: ${f.value} (${f.explanation})`),
          actions: res.agricultural_recommendations.farmers.slice(0, 4)
        });
      }
    } catch (e) {
      console.error('Failed to check risk:', e);
    } finally {
      setLoading(false);
    }
  };

  const getBadgeStyle = (lvl: string) => {
    switch (lvl) {
      case 'Critical':
        return 'bg-red-700 text-white font-bold';
      case 'Severe':
        return 'bg-orange-600 text-white font-bold';
      case 'High':
        return 'bg-amber-500 text-black font-bold';
      case 'Moderate':
        return 'bg-cyan-600 text-white font-semibold';
      case 'Low':
      default:
        return 'bg-emerald-600 text-white font-semibold';
    }
  };

  return (
    <div className="space-y-6 py-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Check Disaster Risk in Your Area
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Select your state and district to immediately check current flood or drought vulnerability
        </p>
      </div>

      {/* 3-Step Simple Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* 1. State */}
          <div>
            <label htmlFor="state-select" className="block text-xs uppercase font-bold text-slate-400 mb-1.5">
              1. Select State:
            </label>
            <select
              id="state-select"
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white font-semibold text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-cyan-500"
            >
              {states.map((st) => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>

          {/* 2. District */}
          <div>
            <label htmlFor="district-risk-select" className="block text-xs uppercase font-bold text-slate-400 mb-1.5">
              2. Select District:
            </label>
            <select
              id="district-risk-select"
              value={selectedDistrictId}
              onChange={(e) => setSelectedDistrictId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white font-semibold text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-cyan-500"
            >
              {availableDistricts.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          {/* 3. Hazard Type */}
          <div>
            <label className="block text-xs uppercase font-bold text-slate-400 mb-1.5">
              3. Check Risk For:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setHazardType('flood')}
                className={`py-2.5 rounded-lg text-xs font-bold transition border ${
                  hazardType === 'flood'
                    ? 'bg-cyan-600 text-white border-cyan-500'
                    : 'bg-slate-950 text-slate-300 border-slate-700 hover:text-white'
                }`}
              >
                Flood Risk
              </button>
              <button
                type="button"
                onClick={() => setHazardType('drought')}
                className={`py-2.5 rounded-lg text-xs font-bold transition border ${
                  hazardType === 'drought'
                    ? 'bg-amber-600 text-white border-amber-500'
                    : 'bg-slate-950 text-slate-300 border-slate-700 hover:text-white'
                }`}
              >
                Drought Risk
              </button>
            </div>
          </div>
        </div>

        {/* Optional Simple Adjustment Toggle */}
        <div className="pt-2">
          <button
            type="button"
            onClick={() => setShowAdvancedInputs(!showAdvancedInputs)}
            className="text-xs text-cyan-400 hover:text-white font-semibold"
          >
            {showAdvancedInputs ? '— Hide custom weather numbers' : '+ Test custom rain or dry days'}
          </button>

          {showAdvancedInputs && (
            <div className="mt-3 p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
              {hazardType === 'flood' ? (
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Expected 24-hour rainfall:</span>
                    <strong className="text-cyan-400">{customRainInput} mm</strong>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="350"
                    step="5"
                    value={customRainInput}
                    onChange={(e) => setCustomRainInput(Number(e.target.value))}
                    className="w-full accent-cyan-500"
                  />
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>0 mm (Normal)</span>
                    <span>100 mm (Heavy rain)</span>
                    <span>250+ mm (Extreme cloudburst)</span>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Rainfall deficit percentage:</span>
                    <strong className="text-amber-400">{customDeficitInput}% below normal</strong>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="95"
                    step="5"
                    value={customDeficitInput}
                    onChange={(e) => setCustomDeficitInput(Number(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>0% (Adequate rain)</span>
                    <span>40% (Dry spell)</span>
                    <span>80%+ (Severe moisture crisis)</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Big Check Risk Button */}
        <div>
          <button
            type="button"
            onClick={handleCheckRisk}
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm shadow-md transition disabled:opacity-50"
          >
            {loading ? 'Analyzing conditions...' : `Check ${hazardType === 'flood' ? 'Flood' : 'Drought'} Risk for ${currentDist?.name}`}
          </button>
        </div>
      </div>

      {/* Results Display */}
      {result && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md space-y-5">
          {/* Result Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                Risk Assessment Result
              </span>
              <h2 className="text-xl font-bold text-white">
                {currentDist.name}, {currentDist.state}
              </h2>
            </div>

            <div>
              <span className={`px-4 py-1.5 rounded-lg text-sm uppercase tracking-wider ${getBadgeStyle(result.risk_level)}`}>
                {result.risk_level} {result.type.toUpperCase()} RISK
              </span>
            </div>
          </div>

          {/* Short Explanation */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <span className="text-xs uppercase font-bold text-slate-400 block mb-1">
              What is happening in this area:
            </span>
            <p className="text-sm text-slate-100 leading-relaxed font-medium">
              {result.explanation}
            </p>
          </div>

          {/* Important Factors */}
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold text-slate-400 block">
              Important Environmental Factors:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              {result.factors.map((f: string, i: number) => (
                <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-300">
                  {f}
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Actions */}
          <div className="space-y-2.5 pt-2">
            <span className="text-xs uppercase font-bold text-slate-400 block">
              What People Should Do Right Now:
            </span>
            <div className="space-y-2">
              {result.actions.map((act: string, i: number) => (
                <div key={i} className="flex items-start gap-2.5 text-xs text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{act}</span>
                </div>
              ))}
            </div>
          </div>

          {onNavigateToSafety && (
            <div className="pt-2">
              <button
                onClick={onNavigateToSafety}
                className="text-xs text-cyan-400 hover:text-white font-semibold inline-flex items-center gap-1"
              >
                <span>Read Full Safety & Emergency Instructions</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

