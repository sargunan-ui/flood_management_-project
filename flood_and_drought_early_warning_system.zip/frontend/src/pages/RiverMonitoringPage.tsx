import React, { useState, useEffect } from 'react';
import { Search, AlertTriangle, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';
import { RiverStation } from '../types';
import { api } from '../services/api';

export const RiverMonitoringPage: React.FC = () => {
  const [rivers, setRivers] = useState<RiverStation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRivers();
  }, []);

  const loadRivers = async () => {
    try {
      const data = await api.getRivers();
      setRivers(data);
    } catch (e) {
      console.error('Failed to load rivers:', e);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Critical':
        return 'bg-red-700 text-white font-bold';
      case 'High':
        return 'bg-orange-600 text-white font-bold';
      case 'Rising':
        return 'bg-amber-500 text-black font-bold';
      case 'Normal':
      default:
        return 'bg-emerald-600 text-white font-semibold';
    }
  };

  const filteredRivers = rivers.filter(r => {
    if (statusFilter !== 'All' && r.status !== statusFilter) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      return (
        r.river_name.toLowerCase().includes(q) ||
        r.station_name.toLowerCase().includes(q) ||
        r.state.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 py-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            River Water Level Monitoring
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Track real-time river gauge levels, danger marks, and rising water alerts across India
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold bg-slate-900 border border-slate-800 p-2 rounded-xl">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
          <span className="text-slate-300">Station Telemetry (Demo & Hydrological Benchmarks)</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-slate-400 font-semibold">Filter Status:</span>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            {['All', 'Critical', 'High', 'Rising', 'Normal'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded text-xs font-semibold transition ${
                  statusFilter === st
                    ? 'bg-cyan-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search river or station..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Rivers List */}
      <div className="space-y-3.5">
        {filteredRivers.map((r) => {
          const isCritical = r.status === 'Critical' || r.status === 'High';
          const isExpanded = expandedId === r.id;

          return (
            <div
              key={r.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition"
            >
              {/* Top Row: River Name, Station, Status Badge */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">River {r.river_name}</h3>
                    <span className="text-xs text-slate-400">({r.state})</span>
                  </div>
                  <span className="text-xs text-slate-400">
                    Station: <strong className="text-slate-200">{r.station_name}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded text-xs uppercase tracking-wider ${getStatusBadge(r.status)}`}>
                    Status: {r.status}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:inline">
                    {r.last_updated}
                  </span>
                </div>
              </div>

              {/* Water Level Readings Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-4 text-center text-xs">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Current Water Level</span>
                  <span className="text-base font-bold text-white">
                    {r.water_level_m} meters
                  </span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Danger Level Mark</span>
                  <span className="text-base font-bold text-red-400">
                    {r.danger_level_m} meters
                  </span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Water Trend</span>
                  <span className="text-base font-bold text-cyan-400">
                    {r.trend}
                  </span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">Water Discharge</span>
                  <span className="text-base font-bold text-slate-200">
                    {r.discharge_cusecs ? `${r.discharge_cusecs.toLocaleString()} cusecs` : 'Standard flow'}
                  </span>
                </div>
              </div>

              {/* Simple Language Explanation */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-start gap-2.5 text-xs text-slate-200">
                <AlertTriangle className={`w-4 h-4 shrink-0 mt-0.5 ${isCritical ? 'text-red-400' : 'text-cyan-400'}`} />
                <div className="leading-relaxed">
                  <strong className="text-white block mb-0.5">What this means:</strong>
                  {r.simple_status}
                </div>
              </div>

              {/* Collapsible Details */}
              <div className="pt-3 flex items-center justify-between text-xs text-slate-400">
                <span className="text-[11px] text-slate-500">
                  {r.is_demo ? 'Demonstration CWC station telemetry' : 'Station reading'}
                </span>
                <button
                  onClick={() => setExpandedId(isExpanded ? null : r.id)}
                  className="text-cyan-400 hover:text-white flex items-center gap-1 font-semibold"
                >
                  <span>{isExpanded ? 'Hide Details' : 'More Station Details'}</span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>

              {isExpanded && (
                <div className="mt-3 pt-3 border-t border-slate-800 text-xs text-slate-300 space-y-2 bg-slate-950 p-3 rounded-xl">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <div>
                      <span className="text-slate-400 block">Warning Buffer:</span>
                      <strong className="text-white">
                        {r.warning_level_m} m (Warning) / {r.danger_level_m} m (Danger)
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Station Status:</span>
                      <strong className="text-white">Active 24x7 Gauge</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Safety Advice:</span>
                      <strong className="text-emerald-400">
                        {isCritical ? 'Stay away from embankments' : 'Safe for normal activities'}
                      </strong>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

