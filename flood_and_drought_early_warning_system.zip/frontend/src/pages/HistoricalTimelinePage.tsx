import React, { useState, useEffect } from 'react';
import {
  History,
  TrendingUp,
  MapPin,
  Calendar,
  ShieldCheck,
  Droplets,
  Flame,
  AlertOctagon,
  Sparkles,
  Info
} from 'lucide-react';
import { DistrictProfile, HistoricalTimelineData } from '../types';
import { api } from '../services/api';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line
} from 'recharts';

interface HistoricalTimelinePageProps {
  districts: DistrictProfile[];
}

export const HistoricalTimelinePage: React.FC<HistoricalTimelinePageProps> = ({ districts }) => {
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(districts[0]?.id || 'assam_dhemaji');
  const [timelineData, setTimelineData] = useState<HistoricalTimelineData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchTimeline();
  }, [selectedDistrictId]);

  const fetchTimeline = async () => {
    setLoading(true);
    try {
      const data = await api.getHistory(selectedDistrictId);
      setTimelineData(data);
    } catch (err) {
      console.error('Failed to fetch timeline:', err);
    } finally {
      setLoading(false);
    }
  };

  const selectedDist = districts.find(d => d.id === selectedDistrictId);

  return (
    <div className="space-y-8 py-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
            <History className="w-4 h-4" />
            <span>Temporal Risk Escalation Dynamics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Historical Risk Timeline & Trends
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Analyze 12-month seasonal progression, rainfall correlations, and documented early warning mitigation case studies
          </p>
        </div>

        {/* District Selector */}
        <div className="flex items-center gap-2 bg-navy-900 p-1.5 rounded-xl border border-slate-700">
          <MapPin className="w-4 h-4 text-cyan-400 ml-1" />
          <select
            value={selectedDistrictId}
            onChange={(e) => setSelectedDistrictId(e.target.value)}
            className="bg-navy-900 text-xs text-white rounded-lg px-2 py-1 font-semibold focus:outline-none"
          >
            {districts.map(d => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.state})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Seasonal Trajectory Chart */}
      {timelineData && (
        <div className="space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-slate-700/50 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
              <div>
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  12-Month Hydrological Progression: {selectedDist?.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Rainfall accumulation (mm) vs Calibrated Flood & Drought Risk Scores
                </p>
              </div>

              <span className="text-[10px] font-mono bg-navy-900 px-2 py-0.5 rounded text-cyan-400 border border-cyan-800">
                12-Month Hindcast
              </span>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={timelineData.timeline} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="floodGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="droughtGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0b132b',
                      borderColor: '#2c3b59',
                      borderRadius: '8px',
                      fontSize: '12px'
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px' }} />
                  <Area
                    type="monotone"
                    dataKey="flood_risk_score"
                    name="Flood Risk Score"
                    stroke="#06b6d4"
                    fillOpacity={1}
                    fill="url(#floodGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="drought_risk_score"
                    name="Drought Severity Score"
                    stroke="#f59e0b"
                    fillOpacity={1}
                    fill="url(#droughtGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Sub-Chart: Rainfall & Soil Moisture Dynamics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass-panel p-6 rounded-2xl border border-slate-700/50 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-700/50">
                <Droplets className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Rainfall Volume & Catchment Saturation
                </h3>
              </div>

              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData.timeline} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b132b',
                        borderColor: '#2c3b59',
                        borderRadius: '8px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    <Line type="monotone" dataKey="rainfall_mm" name="Rainfall (mm)" stroke="#38bdf8" strokeWidth={2} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="soil_moisture_pct" name="Soil Moisture (%)" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="glass-panel p-6 rounded-2xl border border-slate-700/50 space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-700/50">
                <Flame className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                  Temperature vs Satellite VCI Vegetative Stress
                </h3>
              </div>

              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={timelineData.timeline} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0b132b',
                        borderColor: '#2c3b59',
                        borderRadius: '8px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    <Line type="monotone" dataKey="temperature_c" name="Temperature (°C)" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="vegetation_index" name="Vegetation Index (VCI %)" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Historical Case Studies & Mitigation Impact */}
          <div className="glass-panel p-6 rounded-2xl border border-slate-700/50 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-700/50">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
                Documented Extreme Disaster Incidents & Early Warning Impact
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {timelineData.historical_extreme_events.map((ev, i) => (
                <div key={i} className="p-4 rounded-xl bg-navy-900/80 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-300">
                      Year {ev.year} Incident
                    </span>
                    <span className="text-xs font-mono font-bold text-red-400">
                      Peak Risk: {ev.peak_risk_score}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white">{ev.event}</h4>
                  <p className="text-xs text-slate-300">
                    Population in Risk Zone: <strong className="text-slate-100">{ev.affected_population}</strong>
                  </p>
                  <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-500/30 text-[11px] text-emerald-300">
                    <strong>Mitigation Outcome:</strong> {ev.loss_mitigated}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

