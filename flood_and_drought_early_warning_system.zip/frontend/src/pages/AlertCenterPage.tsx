import React, { useState } from 'react';
import {
  Bell,
  AlertTriangle,
  CheckCircle2,
  Radio,
  PlusCircle,
  MessageSquare,
  Smartphone,
  Send,
  Volume2,
  Clock,
  ShieldCheck,
  Filter,
  CheckCheck
} from 'lucide-react';
import { AlertItem, DistrictProfile } from '../types';
import { api } from '../services/api';

interface AlertCenterPageProps {
  alerts: AlertItem[];
  districts: DistrictProfile[];
  onAcknowledgeAlert: (id: string, operator?: string) => void;
  onRefreshAlerts: () => void;
}

export const AlertCenterPage: React.FC<AlertCenterPageProps> = ({
  alerts,
  districts,
  onAcknowledgeAlert,
  onRefreshAlerts
}) => {
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Acknowledged'>('All');
  const [filterHazard, setFilterHazard] = useState<string>('All');
  const [selectedAlertForPreview, setSelectedAlertForPreview] = useState<AlertItem | null>(alerts[0] || null);

  // Modal / Form state for generating a new demo alert
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newLocation, setNewLocation] = useState(districts[0]?.name || 'Dhemaji');
  const [newState, setNewState] = useState(districts[0]?.state || 'Assam');
  const [newHazardType, setNewHazardType] = useState('Flood Warning');
  const [newRiskLevel, setNewRiskLevel] = useState('Critical');
  const [newTitle, setNewTitle] = useState('High River Surge Alert');
  const [newDescription, setNewDescription] = useState('Rainfall has reached 140mm in the last 24h. Embankment overtopping imminent.');
  const [newAction, setNewAction] = useState('Evacuate livestock to high ground. Maintain 24h watch.');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredAlerts = alerts.filter(a => {
    if (filterStatus !== 'All' && a.status !== filterStatus) return false;
    if (filterHazard !== 'All' && !a.hazard_type.toLowerCase().includes(filterHazard.toLowerCase())) return false;
    return true;
  });

  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const matchDist = districts.find(d => d.name.toLowerCase() === newLocation.toLowerCase());
      const coords = matchDist ? [matchDist.latitude, matchDist.longitude] : [26.15, 85.90];

      await api.generateAlert({
        location: newLocation,
        state: newState,
        hazard_type: newHazardType,
        risk_level: newRiskLevel as any,
        title: newTitle,
        description: newDescription,
        recommended_action: newAction,
        coordinates: coords as [number, number]
      });

      setShowCreateModal(false);
      onRefreshAlerts();
    } catch (err) {
      console.error('Failed to create alert:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 py-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-red-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Radio className="w-4 h-4 animate-pulse" />
            <span>Emergency Operations Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Early Warning Alert & Incident Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Issue, acknowledge, and simulate multi-channel public disaster broadcasts (CAP & Wireless Alerts)
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-400 hover:to-orange-400 text-white font-bold text-xs shadow-glow-red transition"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Simulate Emergency Alert</span>
        </button>
      </div>

      {/* Filter Ribbon */}
      <div className="glass-panel p-4 rounded-xl border border-slate-700/50 flex flex-wrap items-center justify-between gap-4">
        {/* Status Filter */}
        <div className="flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-400 uppercase tracking-wider">Status:</span>
          <div className="flex bg-navy-900 p-1 rounded-lg border border-slate-700">
            {(['All', 'Active', 'Acknowledged'] as const).map(s => (
              <button
                key={s}
                onClick={() => setFilterStatus(s)}
                className={`px-3 py-1 rounded-md font-semibold text-xs transition ${
                  filterStatus === s
                    ? 'bg-slate-700 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Hazard Filter */}
        <div className="flex items-center gap-2 text-xs">
          <span className="font-semibold text-slate-400 uppercase tracking-wider">Hazard:</span>
          <select
            value={filterHazard}
            onChange={(e) => setFilterHazard(e.target.value)}
            className="bg-navy-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="All">All Types</option>
            <option value="Flood">Flood Warnings</option>
            <option value="Drought">Agricultural Drought</option>
            <option value="Flash">Flash Flood</option>
            <option value="Scarcity">Water Scarcity</option>
          </select>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Showing <strong className="text-white">{filteredAlerts.length}</strong> alerts
        </div>
      </div>

      {/* Main Grid: Left Alert Feed (7 Cols), Right Multi-Channel Broadcast Preview (5 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Alerts Feed */}
        <div className="lg:col-span-7 space-y-4">
          {filteredAlerts.map((alert) => {
            const isCritical = alert.risk_level === 'Critical';
            const isAck = alert.status === 'Acknowledged';
            const isSelected = selectedAlertForPreview?.id === alert.id;

            return (
              <div
                key={alert.id}
                onClick={() => setSelectedAlertForPreview(alert)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'border-cyan-400 bg-navy-900/90 shadow-glow-cyan'
                    : isAck
                    ? 'border-slate-800 bg-navy-950/60 opacity-60'
                    : isCritical
                    ? 'border-red-500/40 bg-navy-900/80 hover:border-red-400'
                    : 'border-slate-700/60 bg-navy-900/70 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      alert.risk_level === 'Critical' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                      alert.risk_level === 'Severe' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' :
                      'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                    }`}>
                      {alert.risk_level} • {alert.hazard_type}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      [{alert.location}, {alert.state}]
                    </span>
                  </div>

                  <span className="text-[11px] text-slate-500 flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3" />
                    {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-100 mb-1.5">{alert.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">{alert.description}</p>

                <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs mb-4">
                  <span className="text-cyan-400 font-semibold block mb-0.5">Mandated Action:</span>
                  <span className="text-slate-200">{alert.recommended_action}</span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`inline-flex items-center gap-1 font-semibold text-[11px] ${
                      isAck ? 'text-emerald-400' : 'text-amber-400 animate-pulse'
                    }`}>
                      {isAck ? <CheckCheck className="w-3.5 h-3.5" /> : '●'} {alert.status}
                    </span>
                    {alert.acknowledged_by && (
                      <span className="text-[10px] text-slate-400">
                        by {alert.acknowledged_by}
                      </span>
                    )}
                  </div>

                  {!isAck && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAcknowledgeAlert(alert.id);
                      }}
                      className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-navy-950 font-bold text-xs transition inline-flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Acknowledge</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Multi-Channel Public Broadcast Simulator (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-slate-700/60 sticky top-24 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                Multi-Channel Broadcast Preview
              </h3>
              <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                CAP Protocol
              </span>
            </div>

            {selectedAlertForPreview ? (
              <div className="space-y-4">
                {/* Channel 1: Wireless Emergency Alert (Siren Screen) */}
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-red-400 block mb-1 flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5 text-red-400" />
                    Channel 1: Cellular Tower Siren Broadcast (WEA)
                  </span>
                  <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/50 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-red-300 uppercase tracking-wider font-mono text-[10px]">
                        *** DISASTER EMERGENCY ALERT ***
                      </span>
                      <span className="text-[10px] font-mono text-red-400">GOVT OF INDIA / DDMA</span>
                    </div>
                    <p className="font-bold text-white text-xs">
                      {selectedAlertForPreview.title.toUpperCase()}
                    </p>
                    <p className="text-red-200 leading-relaxed text-[11px]">
                      {selectedAlertForPreview.description}
                    </p>
                    <div className="pt-1 font-semibold text-white text-[11px]">
                      ACTION: {selectedAlertForPreview.recommended_action}
                    </div>
                  </div>
                </div>

                {/* Channel 2: WhatsApp / SMS Regional Bulletin */}
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-400 block mb-1 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                    Channel 2: Farmer & Rural Resident WhatsApp SMS
                  </span>
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-700 space-y-1.5 text-xs text-slate-200 font-mono">
                    <span className="text-emerald-400 font-bold block text-[11px]">
                      [AquaSentinel Early Advisory - {selectedAlertForPreview.location}]
                    </span>
                    <p className="text-[11px] leading-relaxed">
                      Alert Level: {selectedAlertForPreview.risk_level.toUpperCase()}
                      <br />
                      Threat: {selectedAlertForPreview.hazard_type}
                      <br />
                      Advice: {selectedAlertForPreview.recommended_action}
                      <br />
                      Helpline: 112 / 1077 (District Disaster Control)
                    </p>
                  </div>
                </div>

                {/* Channel 3: Community Radio Script */}
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-cyan-400 block mb-1 flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-cyan-400" />
                    Channel 3: All India Radio (AIR) / FM Flash Bulletin
                  </span>
                  <div className="p-3.5 rounded-xl bg-navy-950 border border-slate-800 text-[11px] text-slate-300 italic leading-relaxed">
                    "This is an urgent disaster bulletin for the residents of {selectedAlertForPreview.location} and adjacent blocks. {selectedAlertForPreview.description} Please execute safety protocols immediately: {selectedAlertForPreview.recommended_action}"
                  </div>
                </div>

                {/* Responsible AI Disclaimer */}
                <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-500 leading-relaxed">
                  Notice: Broadcast previews simulate real-world Common Alerting Protocol (CAP v1.2) payloads. Live cellular tower activation requires official District Disaster Authority credentials.
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400">Select an alert on the left to preview multi-channel dispatch format.</p>
            )}
          </div>
        </div>
      </div>

      {/* Modal: Generate Simulated Alert */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-sm">
          <div className="glass-panel max-w-lg w-full p-6 rounded-2xl border border-red-500/40 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-400" />
                <span>Simulate Emergency Alert Dispatch</span>
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateAlert} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Target District</label>
                  <select
                    value={newLocation}
                    onChange={(e) => {
                      setNewLocation(e.target.value);
                      const d = districts.find(dist => dist.name === e.target.value);
                      if (d) setNewState(d.state);
                    }}
                    className="w-full bg-navy-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-red-500"
                  >
                    {districts.map(d => (
                      <option key={d.id} value={d.name}>{d.name} ({d.state})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Hazard Category</label>
                  <select
                    value={newHazardType}
                    onChange={(e) => setNewHazardType(e.target.value)}
                    className="w-full bg-navy-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="Flood Warning">Flood Warning</option>
                    <option value="Flash Flood Risk">Flash Flood Risk</option>
                    <option value="Agricultural Drought">Agricultural Drought</option>
                    <option value="Water Scarcity">Water Scarcity</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Severity Level</label>
                <select
                  value={newRiskLevel}
                  onChange={(e) => setNewRiskLevel(e.target.value)}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-red-500 font-semibold"
                >
                  <option value="Critical">Critical (Immediate Evacuation / Severe Loss)</option>
                  <option value="Severe">Severe (Urgent High Alert)</option>
                  <option value="High">High (Precautionary Alert)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Alert Headline</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Telemetry Description</label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-red-500 resize-none leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mandated Action Directive</label>
                <input
                  type="text"
                  value={newAction}
                  onChange={(e) => setNewAction(e.target.value)}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold transition flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Broadcast Simulated Alert</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

