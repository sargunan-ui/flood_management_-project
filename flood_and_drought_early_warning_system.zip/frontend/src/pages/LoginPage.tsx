import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface LoginPageProps {
  onSuccess?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess }) => {
  const { login, register, switchRole, user } = useAuth();
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  
  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserRole>('Citizen');
  const [organization, setOrganization] = useState('');
  const [location, setLocation] = useState('');

  // UI status
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (isRegisterMode) {
        if (!name.trim()) throw new Error('Full Name is required');
        if (!email.trim() || !email.includes('@')) throw new Error('Valid email is required');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');
        if (password !== confirmPassword) throw new Error('Passwords do not match');

        await register({
          name,
          email,
          password,
          role,
          organization,
          location
        });
        setSuccessMsg('Account registered successfully! Redirecting...');
      } else {
        if (!email.trim()) throw new Error('Email or Username is required');
        if (!password) throw new Error('Password is required');

        await login(email, password);
        setSuccessMsg('Authentication successful! Loading dashboard...');
      }

      if (onSuccess) {
        setTimeout(onSuccess, 600);
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (targetRole: UserRole) => {
    setError(null);
    setLoading(true);
    try {
      await switchRole(targetRole);
      setSuccessMsg(`Logged in as demo ${targetRole}!`);
      if (onSuccess) {
        setTimeout(onSuccess, 500);
      }
    } catch (err: any) {
      setError('Quick login failed: ' + (err.message || 'Network error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-navy-900/90 border border-slate-700/80 rounded-xl p-8 shadow-2xl backdrop-blur-md">
        
        {/* Brand Header */}
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-cyan-950 border border-cyan-500/50 text-cyan-400 font-bold text-xl mb-3">
            AS
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white">
            AquaSentinel AI
          </h2>
          <p className="mt-1 text-xs text-slate-400 uppercase tracking-wider font-semibold">
            Disaster Preparedness & Climate Resilience Portal
          </p>
          <div className="mt-2 inline-block px-2.5 py-0.5 rounded-full text-xs font-medium bg-cyan-900/40 text-cyan-300 border border-cyan-800/50">
            Green Planet GP-03
          </div>
        </div>

        {/* Currently Logged In Banner */}
        {user && (
          <div className="bg-slate-800/60 border border-slate-700 rounded-lg p-3 text-sm flex items-center justify-between">
            <div>
              <span className="text-slate-400 text-xs block">Active Session:</span>
              <span className="text-slate-100 font-medium">{user.name}</span>
              <span className="ml-2 text-xs px-2 py-0.5 rounded bg-cyan-900/50 text-cyan-300 border border-cyan-800/40">
                {user.role}
              </span>
            </div>
            {onSuccess && (
              <button
                type="button"
                onClick={onSuccess}
                className="text-xs bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3 py-1.5 rounded transition"
              >
                Go to App
              </button>
            )}
          </div>
        )}

        {/* Quick Role Access for Judges & Evaluators */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-3.5">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Instant Demo Access (1-Click Login):
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickLogin('Citizen')}
              className="text-xs text-left px-2.5 py-1.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition font-medium flex items-center justify-between"
            >
              <span>Citizen</span>
              <span className="text-[10px] text-cyan-400">Ramesh</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('Farmer')}
              className="text-xs text-left px-2.5 py-1.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition font-medium flex items-center justify-between"
            >
              <span>Farmer</span>
              <span className="text-[10px] text-emerald-400">Kishan</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('Disaster Management Official')}
              className="text-xs text-left px-2.5 py-1.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition font-medium flex items-center justify-between"
            >
              <span>Disaster Officer</span>
              <span className="text-[10px] text-amber-400">Dr. Neha</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('Administrator')}
              className="text-xs text-left px-2.5 py-1.5 rounded bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-200 transition font-medium flex items-center justify-between"
            >
              <span>Administrator</span>
              <span className="text-[10px] text-rose-400">Admin</span>
            </button>
          </div>
        </div>

        {/* Status Messages */}
        {error && (
          <div className="bg-rose-950/60 border border-rose-800 text-rose-200 text-xs rounded-lg p-3">
            {error}
          </div>
        )}
        {successMsg && (
          <div className="bg-emerald-950/60 border border-emerald-800 text-emerald-200 text-xs rounded-lg p-3">
            {successMsg}
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex border-b border-slate-700 text-sm font-medium">
            <button
              type="button"
              onClick={() => { setIsRegisterMode(false); setError(null); }}
              className={`flex-1 pb-2 text-center border-b-2 transition ${!isRegisterMode ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400 hover:text-slate-300'}`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => { setIsRegisterMode(true); setError(null); }}
              className={`flex-1 pb-2 text-center border-b-2 transition ${isRegisterMode ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400 hover:text-slate-300'}`}
            >
              Create Account
            </button>
          </div>

          {/* Registration Extra Fields */}
          {isRegisterMode && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">User Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                >
                  <option value="Citizen">Citizen (Resident / Student / Villager)</option>
                  <option value="Farmer">Farmer (Agricultural Producer)</option>
                  <option value="Disaster Management Official">Disaster Management Official (DDMA / NDRF)</option>
                  <option value="Administrator">Administrator (System Supervisor)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Organization (Optional)</label>
                  <input
                    type="text"
                    value={organization}
                    onChange={(e) => setOrganization(e.target.value)}
                    placeholder="e.g. Village Council"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">District / Location</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Dhemaji, Assam"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
            </>
          )}

          {/* Email */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-slate-300">Password</label>
              {!isRegisterMode && (
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(true)}
                  className="text-xs text-cyan-400 hover:text-cyan-300"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 pr-16"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-200 px-2 py-1"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          {/* Confirm Password (Register only) */}
          {isRegisterMode && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Confirm Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm transition shadow-lg shadow-cyan-900/30 disabled:opacity-50 mt-2"
          >
            {loading ? 'Processing...' : isRegisterMode ? 'Complete Registration' : 'Sign In to Portal'}
          </button>
        </form>

        {/* Forgot Password Modal Helper */}
        {showForgotPassword && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-navy-900 border border-slate-700 rounded-xl p-6 max-w-sm w-full space-y-4">
              <h3 className="text-base font-bold text-white">Reset Password</h3>
              <p className="text-xs text-slate-300">
                For security in disaster management environments, administrative password resets are handled via the National Command Center.
              </p>
              <div className="bg-slate-950 p-3 rounded-lg text-xs space-y-1 text-slate-400">
                <p><strong className="text-slate-200">Demo Citizen:</strong> citizen@aquasentinel.org / citizen123</p>
                <p><strong className="text-slate-200">Demo Farmer:</strong> farmer@aquasentinel.org / farmer123</p>
                <p><strong className="text-slate-200">Demo Official:</strong> official@aquasentinel.org / official123</p>
                <p><strong className="text-slate-200">Demo Admin:</strong> admin@aquasentinel.org / admin123</p>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotPassword(false)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

