import React, { useState } from 'react';
import {
  CreditCard,
  Mail,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  UserCheck,
  FileText,
  Building,
  MapPin,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';

interface LoginPageProps {
  onSuccess?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess }) => {
  const { login, register, switchRole, user } = useAuth();
  
  // Auth Modes: 'id-proof' | 'email' | 'register'
  const [authMode, setAuthMode] = useState<'id-proof' | 'email' | 'register'>('id-proof');
  const [showPassword, setShowPassword] = useState(false);
  
  // Form fields
  const [idProofType, setIdProofType] = useState<string>('Aadhaar Card');
  const [idProofNumber, setIdProofNumber] = useState<string>('4812-9021-3456');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('citizen123');
  
  // Registration fields
  const [name, setName] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [role, setRole] = useState<UserRole>('Citizen');
  const [organization, setOrganization] = useState<string>('');
  const [location, setLocation] = useState<string>('');

  // UI status
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Pre-configured government ID accounts for quick 1-click evaluation
  const demoIdCards = [
    {
      role: 'Citizen' as UserRole,
      name: 'Ramesh Kumar',
      idType: 'Aadhaar Card',
      idNumber: '4812-9021-3456',
      pass: 'citizen123',
      color: 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300',
      tag: 'Public Citizen',
      desc: '5-second danger overview, safe drinking water, evacuation routes'
    },
    {
      role: 'Farmer' as UserRole,
      name: 'Kishan Patel',
      idType: 'Kisan Credit Card (KCC)',
      idNumber: 'KCC-RJ-4491',
      pass: 'farmer123',
      color: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300',
      tag: 'Kisan / Farmer',
      desc: 'Soil moisture deficit, drip irrigation timing, PMFBY crop insurance'
    },
    {
      role: 'Disaster Management Official' as UserRole,
      name: 'Dr. Neha Sharma',
      idType: 'NDMA Officer Badge ID',
      idNumber: 'DDMA-AS-102',
      pass: 'official123',
      color: 'border-rose-500/40 bg-rose-950/40 text-rose-300',
      tag: 'Disaster Officer',
      desc: 'Incident triage table, river gauge danger marks, CAP alert broadcasts'
    },
    {
      role: 'Administrator' as UserRole,
      name: 'Chief Admin Verma',
      idType: 'Gov Security Clearance ID',
      idNumber: 'AQ-ADM-001',
      pass: 'admin123',
      color: 'border-purple-500/40 bg-purple-950/40 text-purple-300',
      tag: 'System Admin',
      desc: 'ID proof verification console, system diagnostics, ML model status'
    }
  ];

  const handleSelectDemoCard = (card: typeof demoIdCards[0]) => {
    setIdProofType(card.idType);
    setIdProofNumber(card.idNumber);
    setPassword(card.pass);
    setEmail(card.role === 'Citizen' ? 'citizen@aquasentinel.org' : card.role === 'Farmer' ? 'farmer@aquasentinel.org' : card.role === 'Disaster Management Official' ? 'official@aquasentinel.org' : 'admin@aquasentinel.org');
  };

  const handleDirectDemoLogin = async (card: typeof demoIdCards[0]) => {
    setError(null);
    setLoading(true);
    try {
      await switchRole(card.role);
      setSuccessMsg(`Authenticated via ${card.idType}: ${card.idNumber} (${card.role})`);
      if (onSuccess) setTimeout(onSuccess, 500);
    } catch (err: any) {
      setError(err?.message || 'Quick login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (authMode === 'register') {
        if (!name.trim()) throw new Error('Full Name is required');
        if (!email.trim() || !email.includes('@')) throw new Error('Valid email is required');
        if (!idProofNumber.trim()) throw new Error('Government ID Proof Number is required');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');
        if (password !== confirmPassword) throw new Error('Passwords do not match');

        await register({
          name,
          email,
          password,
          role,
          organization: organization || 'General Public',
          location: location || 'India'
        });
        setSuccessMsg('Account registered with ID proof verification! Loading...');
      } else if (authMode === 'id-proof') {
        if (!idProofNumber.trim()) throw new Error('Please enter your Government ID Proof Number');
        if (!password) throw new Error('Password is required');

        // Login using ID Proof number directly
        await login(idProofNumber.trim(), password);
        setSuccessMsg(`Verified ${idProofType}! Loading portal...`);
      } else {
        // Email login
        if (!email.trim()) throw new Error('Email or ID Number is required');
        if (!password) throw new Error('Password is required');

        await login(email.trim(), password);
        setSuccessMsg('Authentication successful! Loading portal...');
      }

      if (onSuccess) {
        setTimeout(onSuccess, 600);
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex flex-col justify-center items-center py-10 px-4 sm:px-6 lg:px-8 animate-fade-in">
      <div className="max-w-2xl w-full space-y-6 bg-slate-900/90 border border-slate-700/60 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md">
        
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-cyan-950/80 border border-cyan-500/50 text-cyan-400 font-extrabold text-2xl mb-1 shadow-lg shadow-cyan-950/50">
            AS
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            AquaSentinel AI Portal Login
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto">
            Sovereign early warning platform supporting Citizen, Farmer, and Disaster Official verification.
          </p>
        </div>

        {/* 1-Click Demo ID Cards (For Instant Evaluation) */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              Pre-Configured ID Proof Cards (1-Click Login):
            </span>
            <span className="text-[10px] text-slate-400">Click any card to log in instantly</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {demoIdCards.map(c => (
              <div
                key={c.role}
                onClick={() => handleDirectDemoLogin(c)}
                className={`p-3 rounded-xl border text-left cursor-pointer transition duration-200 hover:scale-[1.01] hover:shadow-lg ${c.color} group`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-xs text-white group-hover:text-cyan-300 transition">
                    {c.name}
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-950/80 border border-slate-800">
                    {c.tag}
                  </span>
                </div>
                <div className="text-[11px] font-mono font-semibold text-slate-200 mt-1 flex items-center gap-1">
                  <span>{c.idType}:</span>
                  <span className="text-white font-bold">{c.idNumber}</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-1 leading-snug line-clamp-1">
                  {c.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Login Method Tabs */}
        <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800">
          <button
            type="button"
            onClick={() => { setAuthMode('id-proof'); setError(null); }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              authMode === 'id-proof'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Login with ID Proof</span>
          </button>

          <button
            type="button"
            onClick={() => { setAuthMode('email'); setError(null); }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              authMode === 'email'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Email &amp; Password</span>
          </button>

          <button
            type="button"
            onClick={() => { setAuthMode('register'); setError(null); }}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 ${
              authMode === 'register'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>New Registration</span>
          </button>
        </div>

        {/* Notifications */}
        {error && (
          <div className="p-3.5 bg-rose-950/80 border border-rose-800/80 rounded-xl text-xs text-rose-200">
            {error}
          </div>
        )}

        {successMsg && (
          <div className="p-3.5 bg-emerald-950/80 border border-emerald-800/80 rounded-xl text-xs text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Interactive Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* TAB 1: ID PROOF LOGIN */}
          {authMode === 'id-proof' && (
            <div className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Government ID Proof Type:
                </label>
                <select
                  value={idProofType}
                  onChange={(e) => setIdProofType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 text-white text-xs rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-cyan-500 font-medium"
                >
                  <option value="Aadhaar Card">Aadhaar Card (12-Digit UID)</option>
                  <option value="Kisan Credit Card (KCC)">Kisan Credit Card / Farmer ID (KCC)</option>
                  <option value="NDMA Officer Badge ID">Disaster Management Officer ID (NDMA/DDMA)</option>
                  <option value="Gov Security Clearance ID">Administrator Security Clearance ID</option>
                  <option value="Voter ID Card">Voter ID Card (EPIC)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  ID Proof Number / Document ID:
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={idProofNumber}
                    onChange={(e) => setIdProofNumber(e.target.value)}
                    placeholder={
                      idProofType.includes('Aadhaar') ? 'e.g. 4812-9021-3456' :
                      idProofType.includes('Kisan') ? 'e.g. KCC-RJ-4491' :
                      idProofType.includes('NDMA') ? 'e.g. DDMA-AS-102' : 'Enter your ID document number'
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Security Password:
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: EMAIL LOGIN */}
          {authMode === 'email' && (
            <div className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Registered Email Address:
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. citizen@aquasentinel.org"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Password:
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-10 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: NEW USER REGISTRATION WITH ID PROOF */}
          {authMode === 'register' && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Full Name:</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Email Address:</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Select Persona Role:</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full bg-slate-950 border border-slate-700 text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-500 font-medium"
                  >
                    <option value="Citizen">Citizen (Public Safety &amp; Evacuation)</option>
                    <option value="Farmer">Farmer (Agricultural Moisture &amp; Crop)</option>
                    <option value="Disaster Management Official">Disaster Official (Command &amp; Alerts)</option>
                    <option value="Administrator">Administrator (System Supervisor)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Government ID Type:</label>
                  <select
                    value={idProofType}
                    onChange={(e) => setIdProofType(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-500 font-medium"
                  >
                    <option value="Aadhaar Card">Aadhaar Card</option>
                    <option value="Kisan Credit Card (KCC)">Kisan Credit Card (KCC)</option>
                    <option value="NDMA Officer Badge ID">NDMA Officer Badge ID</option>
                    <option value="Voter ID Card">Voter ID Card</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  ID Document Number:
                </label>
                <input
                  type="text"
                  required
                  value={idProofNumber}
                  onChange={(e) => setIdProofNumber(e.target.value)}
                  placeholder="Enter your ID proof number"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Password:</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1">Confirm Password:</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:scale-[0.99] text-white font-bold text-xs sm:text-sm tracking-wide transition shadow-xl shadow-cyan-950/60 flex items-center justify-center gap-2"
          >
            {loading ? (
              <span>Verifying Identity...</span>
            ) : (
              <>
                <span>
                  {authMode === 'register'
                    ? 'Register Account & Verify ID Proof'
                    : authMode === 'id-proof'
                    ? 'Verify ID & Log In'
                    : 'Log In to AquaSentinel'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Security Disclosure */}
        <div className="pt-2 border-t border-slate-800 text-center">
          <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sovereign Identity Encryption • PBKDF2-HMAC-SHA256 • Role-Based RBAC</span>
          </p>
        </div>
      </div>
    </div>
  );
};
