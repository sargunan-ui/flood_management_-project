import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import {
  MapPin,
  Layers,
  Filter,
  Search,
  Droplets,
  Flame,
  AlertTriangle,
  ArrowRight,
  Info,
  Maximize2
} from 'lucide-react';
import { DistrictProfile } from '../types';

interface GeospatialMapPageProps {
  districts: DistrictProfile[];
  onSelectDistrictForAI: (hazard: 'flood' | 'drought', districtId: string) => void;
}

// Helper component to smoothly pan map when district is selected
function MapController({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, zoom, { duration: 1.5 });
  }, [center, zoom, map]);
  return null;
}

export const GeospatialMapPage: React.FC<GeospatialMapPageProps> = ({
  districts,
  onSelectDistrictForAI
}) => {
  const [filterHazard, setFilterHazard] = useState<'all' | 'flood' | 'drought'>('all');
  const [minSeverity, setMinSeverity] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<DistrictProfile | null>(null);
  const [mapCenter, setMapCenter] = useState<[number, number]>([21.5, 78.9]);
  const [mapZoom, setMapZoom] = useState<number>(5);

  // Filtered districts
  const filteredDistricts = districts.filter(d => {
    // Hazard filter
    if (filterHazard !== 'all' && d.primary_hazard.toLowerCase() !== filterHazard) {
      return false;
    }
    // Severity filter
    const maxScore = Math.max(d.flood_risk_score, d.drought_risk_score);
    if (maxScore < minSeverity) {
      return false;
    }
    // Search query
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const match = d.name.toLowerCase().includes(q) || d.state.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const getMarkerColor = (d: DistrictProfile) => {
    const score = d.primary_hazard === 'Flood' ? d.flood_risk_score : d.drought_risk_score;
    if (score >= 90) return '#ef4444'; // Red
    if (score >= 75) return '#f97316'; // Orange
    if (score >= 50) return '#eab308'; // Yellow
    if (score >= 25) return '#06b6d4'; // Cyan
    return '#10b981'; // Emerald
  };

  const createCustomIcon = (d: DistrictProfile) => {
    const color = getMarkerColor(d);
    const isFlood = d.primary_hazard === 'Flood';
    const svgIcon = isFlood
      ? `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>`
      : `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`;

    return L.divIcon({
      className: 'custom-leaflet-marker',
      html: `
        <div style="
          width: 34px;
          height: 34px;
          border-radius: 50%;
          background: #0b132b;
          border: 2px solid ${color};
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 0 12px ${color}80;
          cursor: pointer;
        ">
          ${svgIcon}
        </div>
      `,
      iconSize: [34, 34],
      iconAnchor: [17, 17],
      popupAnchor: [0, -20]
    });
  };

  const focusDistrict = (d: DistrictProfile) => {
    setSelectedDistrict(d);
    setMapCenter([d.latitude, d.longitude]);
    setMapZoom(8);
  };

  return (
    <div className="space-y-6 py-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Layers className="w-4 h-4" />
            <span>Multi-Layer GIS Telemetry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Interactive Geospatial Risk Map
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Visualizes color-coded risk zones, river gauge catchments, and agricultural drought basins across India
          </p>
        </div>

        {/* Legend Pills */}
        <div className="flex items-center gap-2 text-[10px] uppercase font-bold flex-wrap bg-navy-900/80 p-2 rounded-xl border border-slate-700/60">
          <span className="flex items-center gap-1 text-red-400">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-glow-red" /> Critical (&gt;90)
          </span>
          <span className="flex items-center gap-1 text-orange-400">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> Severe (75-89)
          </span>
          <span className="flex items-center gap-1 text-yellow-400">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" /> High (50-74)
          </span>
          <span className="flex items-center gap-1 text-cyan-400">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" /> Moderate (25-49)
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="glass-panel p-4 rounded-xl border border-slate-700/50 flex flex-wrap items-center justify-between gap-4">
        {/* Hazard filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Hazard:</span>
          <div className="flex items-center bg-navy-900 p-1 rounded-lg border border-slate-700 text-xs">
            {(['all', 'flood', 'drought'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setFilterHazard(tab)}
                className={`px-3 py-1 rounded-md font-semibold text-xs capitalize transition ${
                  filterHazard === tab
                    ? 'bg-slate-700 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab === 'all' ? 'All Hazards' : tab}
              </button>
            ))}
          </div>
        </div>

        {/* Severity filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Min Score:</span>
          <select
            value={minSeverity}
            onChange={(e) => setMinSeverity(Number(e.target.value))}
            className="bg-navy-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value={0}>All Levels (0+)</option>
            <option value={50}>High Severity (50+)</option>
            <option value={75}>Severe & Critical (75+)</option>
            <option value={88}>Critical Emergency (88+)</option>
          </select>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 flex-1 sm:max-w-xs">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search Indian district or state..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-navy-900 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-slate-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Map Viewport Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Leaflet Map (8 Cols) */}
        <div className="lg:col-span-8 rounded-2xl overflow-hidden border border-slate-700/60 shadow-2xl h-[580px] relative z-0">
          <MapContainer
            center={mapCenter}
            zoom={mapZoom}
            scrollWheelZoom={true}
            style={{ height: '100%', width: '100%', backgroundColor: '#0b132b' }}
          >
            <MapController center={mapCenter} zoom={mapZoom} />

            {/* Google Maps Tiles */}
            <TileLayer
              attribution='&copy; Google Maps' subdomains={['mt0', 'mt1', 'mt2', 'mt3']}
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            />

            {/* Render Circles & Custom Markers for each district */}
            {filteredDistricts.map((d) => {
              const color = getMarkerColor(d);
              const isFlood = d.primary_hazard === 'Flood';
              const radius = isFlood ? 45000 : 60000;

              return (
                <React.Fragment key={d.id}>
                  {/* Outer Risk Buffer Circle */}
                  <Circle
                    center={[d.latitude, d.longitude]}
                    radius={radius}
                    pathOptions={{
                      color: color,
                      fillColor: color,
                      fillOpacity: 0.15,
                      weight: 1.5,
                      dashArray: '4, 4'
                    }}
                  />

                  {/* Icon Marker with Popup */}
                  <Marker
                    position={[d.latitude, d.longitude]}
                    icon={createCustomIcon(d)}
                    eventHandlers={{
                      click: () => setSelectedDistrict(d)
                    }}
                  >
                    <Popup className="custom-leaflet-popup">
                      <div className="p-3 bg-navy-950 text-slate-100 rounded-xl border border-slate-700 min-w-[220px]">
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <h4 className="font-bold text-sm text-white">{d.name}</h4>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isFlood ? 'bg-cyan-500/20 text-cyan-300' : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {d.primary_hazard}
                          </span>
                        </div>

                        <p className="text-[11px] text-slate-400 mb-2">{d.state} • Elevation: {d.elevation}m</p>

                        <div className="grid grid-cols-2 gap-2 text-xs mb-3 font-mono">
                          <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-center">
                            <span className="text-[10px] text-slate-400 block">Flood</span>
                            <strong className="text-cyan-400">{d.flood_risk_score}</strong>
                          </div>
                          <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-center">
                            <span className="text-[10px] text-slate-400 block">Drought</span>
                            <strong className="text-amber-400">{d.drought_risk_score}</strong>
                          </div>
                        </div>

                        <button
                          onClick={() => onSelectDistrictForAI(isFlood ? 'flood' : 'drought', d.id)}
                          className="w-full py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-navy-950 font-bold text-xs transition flex items-center justify-center gap-1"
                        >
                          <span>Analyze in AI Simulator</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </Popup>
                  </Marker>
                </React.Fragment>
              );
            })}
          </MapContainer>
        </div>

        {/* Right Sidebar: District List & Focused Detail Panel (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4 h-[580px]">
          {/* Selected District Telemetry Flyout */}
          {selectedDistrict ? (
            <div className="glass-panel p-5 rounded-2xl border border-cyan-500/40 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">{selectedDistrict.name}</h3>
                    <span className="text-xs text-slate-400">({selectedDistrict.state})</span>
                  </div>
                  <span className="text-[11px] font-mono text-cyan-400">
                    {selectedDistrict.latitude.toFixed(2)}° N, {selectedDistrict.longitude.toFixed(2)}° E
                  </span>
                </div>

                <button
                  onClick={() => setSelectedDistrict(null)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Close
                </button>
              </div>

              {/* Vulnerability metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Flood Risk</span>
                  <span className="text-sm font-bold font-mono text-cyan-400">
                    {selectedDistrict.flood_risk_score} ({selectedDistrict.flood_category})
                  </span>
                </div>

                <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Drought Severity</span>
                  <span className="text-sm font-bold font-mono text-amber-400">
                    {selectedDistrict.drought_risk_score} ({selectedDistrict.drought_category})
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div>
                  <span className="text-slate-400">River Basin / Ephemeral:</span>{' '}
                  <strong className="text-slate-200">{selectedDistrict.river_basin || 'Local Catchment'}</strong>
                </div>
                <div>
                  <span className="text-slate-400">Soil Horizon:</span>{' '}
                  <strong className="text-slate-200">{selectedDistrict.soil_type || 'Standard Silt'}</strong>
                </div>
                <div>
                  <span className="text-slate-400">Elevation:</span>{' '}
                  <strong className="text-slate-200">{selectedDistrict.elevation} m a.s.l.</strong>
                </div>
              </div>

              {selectedDistrict.key_metrics.critical_warning && (
                <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/30 text-xs text-red-200 leading-relaxed flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{selectedDistrict.key_metrics.critical_warning}</span>
                </div>
              )}

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => onSelectDistrictForAI(selectedDistrict.primary_hazard === 'Flood' ? 'flood' : 'drought', selectedDistrict.id)}
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-navy-950 font-bold text-xs transition flex items-center justify-center gap-1 shadow-glow-cyan"
                >
                  <span>Launch AI Simulation</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="glass-panel p-4 rounded-xl border border-slate-700/50 text-xs text-slate-400 flex items-center gap-2">
              <Info className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Click on any district marker or select from the list below to inspect localized telemetry.</span>
            </div>
          )}

          {/* Quick Select District Roster */}
          <div className="glass-panel p-4 rounded-2xl border border-slate-700/50 flex-1 overflow-y-auto space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Monitored Indian Zones ({filteredDistricts.length})
            </span>

            {filteredDistricts.map((d) => {
              const color = getMarkerColor(d);
              const isFlood = d.primary_hazard === 'Flood';
              const isSelected = selectedDistrict?.id === d.id;

              return (
                <div
                  key={d.id}
                  onClick={() => focusDistrict(d)}
                  className={`p-3 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-800 border-cyan-500/50 shadow-sm'
                      : 'bg-navy-900/60 border-slate-800 hover:border-slate-700 hover:bg-navy-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                    <div>
                      <h4 className="font-bold text-xs text-slate-100">{d.name}</h4>
                      <span className="text-[10px] text-slate-400">{d.state} • {d.elevation}m</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-bold text-xs" style={{ color }}>
                      {isFlood ? d.flood_risk_score : d.drought_risk_score}
                    </span>
                    <span className="block text-[10px] uppercase text-slate-400">
                      {isFlood ? 'Flood' : 'Drought'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

