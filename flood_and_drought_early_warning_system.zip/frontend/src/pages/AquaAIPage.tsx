import React, { useState, useEffect, useRef } from 'react';
import { api } from '../services/api';
import { DistrictProfile, ChatMessage } from '../types';

interface AquaAIPageProps {
  districts: DistrictProfile[];
  selectedDistrictId?: string;
  onSelectDistrict?: (id: string) => void;
}

export const AquaAIPage: React.FC<AquaAIPageProps> = ({
  districts,
  selectedDistrictId = 'assam_dhemaji',
  onSelectDistrict
}) => {
  const currentDistrict = districts.find(d => d.id === selectedDistrictId) || districts[0] || null;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('aquasentinel_chat_history');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'msg_welcome',
        sender: 'assistant',
        text: `Hello! I am **Aqua AI**, your disaster preparedness and environmental safety assistant.\n\nI am currently analyzing **${currentDistrict?.name || 'your area'}, ${currentDistrict?.state || 'India'}**.\n\nYou can ask me about localized flood risks, drought mitigation for farmers, emergency go-bag preparation, or step-by-step safety actions.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        engine: 'Aqua AI Early Warning Assistant'
      }
    ];
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    localStorage.setItem('aquasentinel_chat_history', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (messageToSend?: string) => {
    const text = (messageToSend || input).trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const historyPayload = messages.slice(-6).map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const contextPayload = currentDistrict ? {
        district_id: currentDistrict.id,
        district_name: currentDistrict.name,
        state: currentDistrict.state,
        flood_risk_score: currentDistrict.flood_risk_score,
        flood_category: currentDistrict.flood_category,
        drought_risk_score: currentDistrict.drought_risk_score,
        drought_category: currentDistrict.drought_category,
        rainfall_24h: currentDistrict.key_metrics?.avg_monsoon_rainfall_mm ? (currentDistrict.key_metrics.avg_monsoon_rainfall_mm / 25).toFixed(1) : 45.0,
        river_level: currentDistrict.key_metrics?.river_gauge_m || 14.2,
        timestamp: new Date().toISOString()
      } : null;

      const response = await api.chatWithAquaAI({
        message: text,
        history: historyPayload,
        context: contextPayload
      });

      const assistantMsg: ChatMessage = {
        id: `asst_${Date.now()}`,
        sender: 'assistant',
        text: response.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        is_live_llm: response.is_live_llm,
        engine: response.engine,
        notice: response.notice
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        sender: 'assistant',
        text: "I encountered a communication issue connecting to the disaster safety engine. Please verify that your local server is running or consult the Safety Guide tab for immediate guidance.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        engine: 'Aqua AI System Notice'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
      textareaRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewChat = () => {
    const welcome: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'assistant',
      text: `Started a fresh session for **${currentDistrict?.name || 'your area'}, ${currentDistrict?.state || 'India'}**. How can I help you stay prepared today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      engine: 'Aqua AI Early Warning Assistant'
    };
    setMessages([welcome]);
    localStorage.removeItem('aquasentinel_chat_history');
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const suggestedQuestions = [
    `Is ${currentDistrict?.name || 'my area'} at risk of flooding?`,
    "What should I do during a flood?",
    "What should farmers do when rainfall is low?",
    "How can I prepare an emergency go-bag?",
    "Why is flood risk high in my district?",
    "How can I conserve drinking water?",
    "Explain this risk map to me."
  ];

  return (
    <div className="py-6 max-w-5xl mx-auto space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Aqua AI — Disaster Safety Assistant
            </h1>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-cyan-900/50 text-cyan-300 border border-cyan-700/60 font-semibold">
              Context-Aware AI
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Real-time conversational disaster preparedness, farmer advisories, and emergency response.
          </p>
        </div>

        {/* Location Selector in Chat */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-medium">Focus Area:</label>
          <select
            value={currentDistrict?.id}
            onChange={(e) => onSelectDistrict && onSelectDistrict(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-100 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-500 font-medium"
          >
            {districts.map(d => (
              <option key={d.id} value={d.id}>
                {d.name}, {d.state} ({d.primary_hazard})
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={handleNewChat}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
          >
            New Chat
          </button>
        </div>
      </div>

      {/* Active District Telemetry Status Pill */}
      {currentDistrict && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3 text-xs flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-slate-200">
              Active Context: {currentDistrict.name}, {currentDistrict.state}
            </span>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
              Flood: {currentDistrict.flood_category} ({Math.round(currentDistrict.flood_risk_score)})
            </span>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
              Drought: {currentDistrict.drought_category} ({Math.round(currentDistrict.drought_risk_score)})
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Emergency Helpline: <strong className="text-rose-400">112</strong>
          </span>
        </div>
      )}

      {/* Chat Messages Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl flex flex-col h-[520px] shadow-2xl overflow-hidden">
        
        {/* Scrollable Message History */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((m) => {
            const isUser = m.sender === 'user';
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-600/50 text-cyan-300 flex items-center justify-center text-xs font-bold shrink-0">
                    AI
                  </div>
                )}
                
                <div
                  className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-cyan-600 text-white rounded-tr-none'
                      : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'
                  }`}
                >
                  {/* Header in assistant message */}
                  {!isUser && (
                    <div className="flex items-center justify-between gap-4 mb-2 pb-1.5 border-b border-slate-800/80 text-[10px] text-slate-400">
                      <span className="font-semibold text-cyan-400">Aqua AI</span>
                      <div className="flex items-center gap-2">
                        <span>{m.timestamp}</span>
                        <button
                          type="button"
                          onClick={() => copyToClipboard(m.text, m.id)}
                          className="hover:text-slate-200 transition"
                        >
                          {copiedId === m.id ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Message body with Markdown format support */}
                  <div className="whitespace-pre-wrap space-y-1">
                    {m.text.split('\n\n').map((paragraph, idx) => (
                      <p key={idx} className="leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>

                  {/* Engine badge */}
                  {!isUser && m.engine && (
                    <div className="mt-2.5 pt-1.5 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-500">
                      <span>Engine: {m.engine}</span>
                      {m.is_live_llm && (
                        <span className="text-emerald-400 font-medium">Live Generative API</span>
                      )}
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center text-xs font-bold shrink-0">
                    You
                  </div>
                )}
              </div>
            );
          })}

          {/* Typing Indicator */}
          {loading && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-600/50 text-cyan-300 flex items-center justify-center text-xs font-bold shrink-0">
                AI
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse delay-150"></span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse delay-300"></span>
                <span className="text-xs text-slate-400 ml-2">Aqua AI is formulating verified safety advice...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Question Chips */}
        <div className="bg-slate-900/60 border-t border-slate-800/80 px-4 py-2.5 overflow-x-auto">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
            Suggested Safety Inquiries:
          </span>
          <div className="flex gap-2 whitespace-nowrap">
            {suggestedQuestions.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSend(q)}
                disabled={loading}
                className="text-xs px-3 py-1.5 rounded-full bg-slate-800/90 hover:bg-slate-700 border border-slate-700 text-slate-300 transition shrink-0 disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-900 border-t border-slate-800 flex items-end gap-2">
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Ask Aqua AI about flood, drought, or disaster safety in ${currentDistrict?.name || 'India'} (Enter to send)...`}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none max-h-28"
          />
          <button
            type="button"
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs sm:text-sm transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
          >
            {loading ? 'Thinking...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
};

