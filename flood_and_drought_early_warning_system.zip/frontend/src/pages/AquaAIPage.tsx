import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  Send,
  User,
  Copy,
  Check,
  RefreshCw,
  MapPin,
  ShieldAlert,
  Volume2,
  VolumeX,
  Droplets,
  Sun,
  Waves,
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { api } from '../services/api';
import { DistrictProfile, ChatMessage } from '../types';
import { useAuth } from '../context/AuthContext';

interface AquaAIPageProps {
  districts: DistrictProfile[];
  selectedDistrictId?: string;
  onSelectDistrict?: (id: string) => void;
}

export const AquaAIPage: React.FC<AquaAIPageProps> = ({
  districts,
  selectedDistrictId = 'assam_dhemaji',
  onSelectDistrict
}) => {
  const { user } = useAuth();
  const currentDistrict = districts.find(d => d.id === selectedDistrictId) || districts[0] || null;

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('aquasentinel_chat_history');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'msg_welcome',
        sender: 'assistant',
        text: `Hello ${user?.name ? user.name.split(' ')[0] : 'there'}! I am **Aqua AI**, your sovereign disaster preparedness and emergency safety assistant.\n\nI am currently synchronized with real-time telemetry for **${currentDistrict?.name || 'your area'}, ${currentDistrict?.state || 'India'}**.\n\nYou can ask me any question about:\n- 🚨 **Immediate Evacuation & Life Safety**\n- 🌾 **Farmer Drought & Crop Protection**\n- 💧 **Drinking Water Purification & Health**\n- 📞 **Disaster Helplines (112 / 1077 / 1070)**`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        engine: 'Aqua AI Verified Disaster Safety Engine'
      }
    ];
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<'all' | 'citizen' | 'farmer' | 'official'>('all');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    localStorage.setItem('aquasentinel_chat_history', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Clean up speech synthesis on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSend = async (messageToSend?: string) => {
    const text = (messageToSend || input).trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const historyPayload = messages.slice(-6).map(m => ({
        sender: m.sender,
        text: m.text
      }));

      const contextPayload = currentDistrict ? {
        district_id: currentDistrict.id,
        district_name: currentDistrict.name,
        state: currentDistrict.state,
        flood_risk_score: currentDistrict.flood_risk_score,
        flood_category: currentDistrict.flood_category,
        drought_risk_score: currentDistrict.drought_risk_score,
        drought_category: currentDistrict.drought_category,
        rainfall_24h: currentDistrict.key_metrics?.avg_monsoon_rainfall_mm
          ? (currentDistrict.key_metrics.avg_monsoon_rainfall_mm / 25).toFixed(1)
          : 45.0,
        river_level: currentDistrict.key_metrics?.river_gauge_m || 14.8,
        user_role: user?.role || 'Citizen',
        user_name: user?.name || 'Resident',
        timestamp: new Date().toISOString()
      } : null;

      const response = await api.chatWithAquaAI({
        message: text,
        history: historyPayload,
        context: contextPayload
      });

      const assistantMsg: ChatMessage = {
        id: `asst_${Date.now()}`,
        sender: 'assistant',
        text: response.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        is_live_llm: response.is_live_llm,
        engine: response.engine,
        notice: response.notice
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        sender: 'assistant',
        text: "I am having temporary trouble connecting to the network gateway. However, for immediate disaster relief in " + (currentDistrict?.name || "your district") + ", dial **112** or **1077** (District Disaster Control Room).",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        engine: 'Aqua AI Offline Safety Fallback'
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
      textareaRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewChat = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    const welcome: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'assistant',
      text: `Started fresh session for **${currentDistrict?.name || 'your area'}, ${currentDistrict?.state || 'India'}** (${user?.role || 'Citizen'} view). How can I help protect you today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      engine: 'Aqua AI Verified Disaster Safety Engine'
    };
    setMessages([welcome]);
    localStorage.removeItem('aquasentinel_chat_history');
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleSpeech = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown characters for pleasant speech
    const cleanText = text.replace(/[*#_`>]/g, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Categorized suggested questions based on what people ask
  const categorizedPrompts = {
    citizen: [
      `Is my family at risk of flooding in ${currentDistrict?.name || 'this district'}?`,
      "What should be in an emergency go-bag?",
      "What emergency helpline numbers can I call?",
      "Is it safe to drive through flooded roads?",
      "How do I purify drinking water after a flood?"
    ],
    farmer: [
      `How can farmers in ${currentDistrict?.name || 'this area'} protect crops during drought?`,
      "What is the best drip irrigation schedule?",
      "How do I claim PMFBY crop insurance?",
      "What drought-resistant crops can I plant?"
    ],
    official: [
      `What is the command protocol for river level at 16.8m?`,
      "What are the flood shelter inspection steps?",
      "How does AquaSentinel predict disasters with Machine Learning?"
    ]
  };

  const allPrompts = [
    ...categorizedPrompts.citizen,
    ...categorizedPrompts.farmer,
    ...categorizedPrompts.official
  ];

  const displayedPrompts = activeCategory === 'citizen'
    ? categorizedPrompts.citizen
    : activeCategory === 'farmer'
    ? categorizedPrompts.farmer
    : activeCategory === 'official'
    ? categorizedPrompts.official
    : allPrompts.slice(0, 7);

  return (
    <div className="py-6 max-w-5xl mx-auto space-y-4 animate-fade-in">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
                Aqua AI Disaster Safety Assistant
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  REAL-TIME AI
                </span>
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Answers citizen evacuation queries, farmer irrigation advisories, and official disaster protocols.
              </p>
            </div>
          </div>
        </div>

        {/* Location Selector & Actions */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5">
            <MapPin className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={currentDistrict?.id}
              onChange={(e) => onSelectDistrict && onSelectDistrict(e.target.value)}
              className="bg-transparent text-white font-bold text-xs focus:outline-none cursor-pointer"
            >
              {districts.map(d => (
                <option key={d.id} value={d.id} className="bg-slate-900 text-white">
                  {d.name}, {d.state} ({d.primary_hazard})
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            onClick={handleNewChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold transition"
          >
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
            <span>New Chat</span>
          </button>
        </div>
      </div>

      {/* Active District Telemetry Status Strip */}
      {currentDistrict && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 px-4 text-xs flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-extrabold text-white flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Live Context: {currentDistrict.name}, {currentDistrict.state}
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center gap-1">
              <Waves className="w-3 h-3" />
              Flood: {currentDistrict.flood_category} ({Math.round(currentDistrict.flood_risk_score)})
            </span>
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
              <Sun className="w-3 h-3" />
              Drought: {currentDistrict.drought_category} ({Math.round(currentDistrict.drought_risk_score)})
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <PhoneCall className="w-3 h-3 text-rose-400" />
              National Helpline: <strong className="text-rose-400">112</strong>
            </span>
          </div>
        </div>
      )}

      {/* Chat Messages Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl flex flex-col h-[520px] shadow-2xl overflow-hidden">
        
        {/* Scrollable Message History */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((m) => {
            const isUser = m.sender === 'user';
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 flex items-center justify-center text-xs font-extrabold shrink-0 shadow-md">
                    AI
                  </div>
                )}
                
                <div
                  className={`max-w-[88%] sm:max-w-[78%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-cyan-600 text-white rounded-tr-none shadow-lg shadow-cyan-950/40 font-medium'
                      : 'bg-slate-900 border border-slate-800 text-slate-100 rounded-tl-none shadow-xl'
                  }`}
                >
                  {/* Header in assistant message */}
                  {!isUser && (
                    <div className="flex items-center justify-between gap-4 mb-2.5 pb-1.5 border-b border-slate-800 text-[10px] text-slate-400">
                      <span className="font-extrabold text-cyan-400 flex items-center gap-1">
                        <Sparkles className="w-3 h-3" />
                        Aqua AI Response
                      </span>
                      <div className="flex items-center gap-3">
                        <span>{m.timestamp}</span>
                        
                        {/* Audio Speech Button */}
                        <button
                          type="button"
                          onClick={() => toggleSpeech(m.text, m.id)}
                          title="Listen to this answer"
                          className="hover:text-cyan-400 transition"
                        >
                          {speakingId === m.id ? (
                            <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5 text-slate-400 hover:text-white" />
                          )}
                        </button>

                        {/* Copy Button */}
                        <button
                          type="button"
                          onClick={() => copyToClipboard(m.text, m.id)}
                          className="hover:text-cyan-400 transition flex items-center gap-1"
                        >
                          {copiedId === m.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Message body */}
                  <div className="whitespace-pre-wrap space-y-1.5">
                    {m.text.split('\n\n').map((paragraph, idx) => (
                      <p key={idx} className="leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>

                  {/* Engine verification stamp */}
                  {!isUser && m.engine && (
                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                      <span>Verified: {m.engine}</span>
                      {m.is_live_llm ? (
                        <span className="text-emerald-400 font-bold">● Live Generative API</span>
                      ) : (
                        <span className="text-cyan-400 font-bold">● High-Confidence Disaster Engine</span>
                      )}
                    </div>
                  )}
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center text-xs font-bold shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {/* Typing Indicator */}
          {loading && (
            <div className="flex gap-3 justify-start items-center">
              <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-300 flex items-center justify-center text-xs font-extrabold shrink-0">
                AI
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse delay-150"></span>
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse delay-300"></span>
                <span className="text-xs text-slate-300 ml-2 font-medium">
                  Aqua AI is evaluating disaster parameters &amp; safety instructions...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Question Chips by Category */}
        <div className="bg-slate-900/90 border-t border-slate-800 px-4 py-2.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">
              Common Questions People Ask:
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setActiveCategory('all')}
                className={`text-[10px] font-bold px-2 py-0.5 rounded transition ${
                  activeCategory === 'all' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('citizen')}
                className={`text-[10px] font-bold px-2 py-0.5 rounded transition ${
                  activeCategory === 'citizen' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Citizen
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('farmer')}
                className={`text-[10px] font-bold px-2 py-0.5 rounded transition ${
                  activeCategory === 'farmer' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Farmer
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('official')}
                className={`text-[10px] font-bold px-2 py-0.5 rounded transition ${
                  activeCategory === 'official' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Official
              </button>
            </div>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
            {displayedPrompts.map((q, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSend(q)}
                disabled={loading}
                className="text-xs px-3 py-1.5 rounded-full bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 text-slate-200 transition shrink-0 disabled:opacity-50 font-medium"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* User Input Bar */}
        <div className="p-3 sm:p-4 bg-slate-900 border-t border-slate-800 flex items-end gap-2">
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Ask Aqua AI about flood, drought, go-bag, or water safety in ${currentDistrict?.name || 'your area'} (Enter to send)...`}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none max-h-28 font-medium"
          />
          <button
            type="button"
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:scale-95 text-white font-bold text-xs sm:text-sm transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-cyan-950/50 flex items-center gap-1.5"
          >
            <span>{loading ? 'Thinking...' : 'Send'}</span>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
