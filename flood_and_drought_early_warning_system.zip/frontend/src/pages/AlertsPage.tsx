import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Search } from 'lucide-react';
import { AlertItem } from '../types';

interface AlertsPageProps {
  alerts: AlertItem[];
  onAcknowledgeAlert: (id: string, operator?: string) => void;
}

export const AlertsPage: React.FC<AlertsPageProps> = ({
  alerts,
  onAcknowledgeAlert
}) => {
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Acknowledged'>('All');
  const [filterHazard, setFilterHazard] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const getSeverityBadge = (lvl: string) => {
    switch (lvl) {
      case 'Critical':
        return 'bg-red-700 text-white font-bold';
      case 'Severe':
        return 'bg-orange-600 text-white font-bold';
      case 'High':
        return 'bg-amber-500 text-black font-bold';
      case 'Moderate':
        return 'bg-cyan-600 text-white font-semibold';
      case 'Low':
      default:
        return 'bg-emerald-600 text-white font-semibold';
    }
  };

  const filteredAlerts = alerts.filter(a => {
    if (filterStatus !== 'All' && a.status !== filterStatus) return false;
    if (filterHazard !== 'All' && !a.hazard_type.toLowerCase().includes(filterHazard.toLowerCase())) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      return a.location.toLowerCase().includes(q) || a.state.toLowerCase().includes(q) || a.title.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-6 py-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Disaster Alerts & Early Warnings
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Verified risk notifications and practical emergency actions for affected communities
          </p>
        </div>

        <div className="text-xs text-slate-400 bg-slate-900 border border-slate-800 p-2 rounded-xl">
          <span>AI-generated & demo risk alerts (Not official government gazette)</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Status Filter */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-semibold">Status:</span>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            {['All', 'Active', 'Acknowledged'].map(st => (
              <button
                key={st}
                onClick={() => setFilterStatus(st as any)}
                className={`px-3 py-1 rounded text-xs font-semibold transition ${
                  filterStatus === st
                    ? 'bg-cyan-600 text-white'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Hazard Filter */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-semibold">Hazard:</span>
          <select
            value={filterHazard}
            onChange={(e) => setFilterHazard(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-cyan-500"
          >
            <option value="All">All Hazards</option>
            <option value="Flood">Flood Alerts</option>
            <option value="Drought">Drought Alerts</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-56">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search district..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Alerts Cards List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 text-sm">
            No matching disaster alerts found for the selected filters.
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const isAck = alert.status === 'Acknowledged';

            return (
              <div
                key={alert.id}
                className={`bg-slate-900 border rounded-2xl p-5 transition ${
                  isAck ? 'border-slate-800 opacity-60' : 'border-slate-700 shadow-sm'
                }`}
              >
                {/* Top Row: Location, Hazard, Severity, Time */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white">
                      {alert.location}, {alert.state}
                    </span>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-300 font-medium">
                      {alert.hazard_type}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded text-xs uppercase tracking-wider ${getSeverityBadge(alert.risk_level)}`}>
                      {alert.risk_level}
                    </span>
                    <span className="text-xs text-slate-400">
                      {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>

                {/* Short Warning */}
                <div className="py-3 text-xs leading-relaxed">
                  <strong className="text-white block mb-1">{alert.title}</strong>
                  <p className="text-slate-300">{alert.description}</p>
                </div>

                {/* Recommended Action */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs">
                  <span className="text-cyan-400 font-bold block mb-0.5">
                    Recommended Action:
                  </span>
                  <p className="text-slate-200">{alert.recommended_action}</p>
                </div>

                {/* Footer / Acknowledge Button */}
                <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <div>
                    <span className={isAck ? 'text-emerald-400 font-semibold' : 'text-amber-400 font-semibold'}>
                      ● {alert.status}
                    </span>
                    {alert.acknowledged_by && (
                      <span className="text-slate-500 ml-1">
                        (Verified by {alert.acknowledged_by})
                      </span>
                    )}
                  </div>

                  {!isAck && (
                    <button
                      onClick={() => onAcknowledgeAlert(alert.id)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-xs font-semibold transition inline-flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Acknowledge Alert</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

