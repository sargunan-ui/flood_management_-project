import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  MapPin,
  ArrowRight,
  TrendingUp,
  Scale,
  Droplets,
  Flame,
  Mountain,
  Layers,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { DistrictProfile, ComparisonData } from '../types';
import { api } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface LocationAnalyticsPageProps {
  districts: DistrictProfile[];
  onSelectDistrictForAI: (hazard: 'flood' | 'drought', districtId: string) => void;
}

export const LocationAnalyticsPage: React.FC<LocationAnalyticsPageProps> = ({
  districts,
  onSelectDistrictForAI
}) => {
  const [district1Id, setDistrict1Id] = useState<string>(districts[0]?.id || 'assam_dhemaji');
  const [district2Id, setDistrict2Id] = useState<string>(districts[11]?.id || 'rajasthan_barmer');
  const [comparison, setComparison] = useState<ComparisonData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchComparison();
  }, [district1Id, district2Id]);

  const fetchComparison = async () => {
    setLoading(true);
    try {
      const data = await api.compareDistricts(district1Id, district2Id);
      setComparison(data);
    } catch (err) {
      console.error('Failed to compare districts:', err);
    } finally {
      setLoading(false);
    }
  };

  const d1 = comparison?.district_1 || districts.find(d => d.id === district1Id);
  const d2 = comparison?.district_2 || districts.find(d => d.id === district2Id);

  // Chart comparison data
  const chartData = [
    {
      metric: 'Flood Risk',
      [d1?.name || 'District 1']: d1?.flood_risk_score || 0,
      [d2?.name || 'District 2']: d2?.flood_risk_score || 0
    },
    {
      metric: 'Drought Severity',
      [d1?.name || 'District 1']: d1?.drought_risk_score || 0,
      [d2?.name || 'District 2']: d2?.drought_risk_score || 0
    },
    {
      metric: 'Vulnerability Index (x100)',
      [d1?.name || 'District 1']: (d1?.vulnerability_index || 0) * 100,
      [d2?.name || 'District 2']: (d2?.vulnerability_index || 0) * 100
    }
  ];

  return (
    <div className="space-y-8 py-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Scale className="w-4 h-4" />
            <span>Comparative District Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Location Vulnerability Analytics & Comparison
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Analyze localized basin vulnerability profiles and compare two districts side-by-side
          </p>
        </div>
      </div>

      {/* Selectors Bar */}
      <div className="glass-panel p-6 rounded-2xl border border-slate-700/50">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          Select Districts to Compare Side-by-Side:
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Selector 1 */}
          <div className="p-4 rounded-xl bg-navy-900 border border-cyan-500/30 space-y-2">
            <span className="text-[11px] uppercase font-bold text-cyan-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400" />
              District Focus A (Primary Zone)
            </span>
            <select
              value={district1Id}
              onChange={(e) => setDistrict1Id(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-semibold"
            >
              {districts.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.state}) — {d.primary_hazard} Risk
                </option>
              ))}
            </select>
          </div>

          {/* Selector 2 */}
          <div className="p-4 rounded-xl bg-navy-900 border border-amber-500/30 space-y-2">
            <span className="text-[11px] uppercase font-bold text-amber-400 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              District Focus B (Comparative Zone)
            </span>
            <select
              value={district2Id}
              onChange={(e) => setDistrict2Id(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-semibold"
            >
              {districts.map(d => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.state}) — {d.primary_hazard} Risk
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Comparison Cards Grid */}
      {d1 && d2 && (
        <div className="space-y-6">
          {/* Top Profiles Strip */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* District 1 Profile */}
            <div className="glass-panel p-6 rounded-2xl border border-cyan-500/40 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
                <div>
                  <h3 className="text-xl font-extrabold text-white">{d1.name}</h3>
                  <span className="text-xs text-slate-400">{d1.state}</span>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                  d1.primary_hazard === 'Flood' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {d1.primary_hazard} Vulnerability
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Flood Risk Score</span>
                  <span className="text-xl font-bold font-mono text-cyan-400">{d1.flood_risk_score}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">({d1.flood_category})</span>
                </div>

                <div className="p-3 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Drought Severity</span>
                  <span className="text-xl font-bold font-mono text-amber-400">{d1.drought_risk_score}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">({d1.drought_category})</span>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Elevation:</span>
                  <span className="font-mono font-semibold text-slate-200">{d1.elevation} m</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">River Basin:</span>
                  <span className="font-semibold text-slate-200">{d1.river_basin || 'Local'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Soil Type:</span>
                  <span className="font-semibold text-slate-200">{d1.soil_type || 'Alluvial'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Vulnerability Index:</span>
                  <span className="font-mono font-bold text-cyan-400">{(d1.vulnerability_index * 100).toFixed(0)} / 100</span>
                </div>
              </div>

              <button
                onClick={() => onSelectDistrictForAI(d1.primary_hazard === 'Flood' ? 'flood' : 'drought', d1.id)}
                className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-navy-950 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-glow-cyan"
              >
                <span>Launch {d1.name} in AI Simulator</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* District 2 Profile */}
            <div className="glass-panel p-6 rounded-2xl border border-amber-500/40 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
                <div>
                  <h3 className="text-xl font-extrabold text-white">{d2.name}</h3>
                  <span className="text-xs text-slate-400">{d2.state}</span>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                  d2.primary_hazard === 'Flood' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {d2.primary_hazard} Vulnerability
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Flood Risk Score</span>
                  <span className="text-xl font-bold font-mono text-cyan-400">{d2.flood_risk_score}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">({d2.flood_category})</span>
                </div>

                <div className="p-3 rounded-xl bg-navy-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Drought Severity</span>
                  <span className="text-xl font-bold font-mono text-amber-400">{d2.drought_risk_score}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">({d2.drought_category})</span>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Elevation:</span>
                  <span className="font-mono font-semibold text-slate-200">{d2.elevation} m</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">River Basin:</span>
                  <span className="font-semibold text-slate-200">{d2.river_basin || 'Local'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-400">Soil Type:</span>
                  <span className="font-semibold text-slate-200">{d2.soil_type || 'Desert Sand'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Vulnerability Index:</span>
                  <span className="font-mono font-bold text-amber-400">{(d2.vulnerability_index * 100).toFixed(0)} / 100</span>
                </div>
              </div>

              <button
                onClick={() => onSelectDistrictForAI(d2.primary_hazard === 'Flood' ? 'flood' : 'drought', d2.id)}
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-navy-950 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-glow-amber"
              >
                <span>Launch {d2.name} in AI Simulator</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Comparative Bar Chart Visualization */}
          <div className="glass-panel p-6 rounded-2xl border border-slate-700/50">
            <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              Risk Vector Differential Chart
            </h3>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <XAxis dataKey="metric" stroke="#64748b" fontSize={12} tickLine={false} />
                  <YAxis stroke="#64748b" fontSize={12} domain={[0, 100]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0b132b',
                      borderColor: '#2c3b59',
                      borderRadius: '8px',
                      fontSize: '12px'
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px' }} />
                  <Bar dataKey={d1.name} fill="#06b6d4" radius={[4, 4, 0, 0]} />
                  <Bar dataKey={d2.name} fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

