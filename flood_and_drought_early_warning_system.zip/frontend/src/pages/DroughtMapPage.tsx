import React, { useState } from 'react';
import { IndiaMap } from '../components/IndiaMap';
import { DistrictProfile } from '../types';

interface DroughtMapPageProps {
  districts: DistrictProfile[];
  initialDistrictId?: string;
  onNavigateToCheckRisk?: (districtId: string) => void;
}

export const DroughtMapPage: React.FC<DroughtMapPageProps> = ({
  districts,
  initialDistrictId,
  onNavigateToCheckRisk
}) => {
  const [selectedId, setSelectedId] = useState<string>(initialDistrictId || 'rajasthan_barmer');
  const droughtDistricts = districts.filter(d => d.primary_hazard === 'Drought' || d.drought_risk_score >= 40);

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              India Drought Severity Map
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800 font-semibold">
              Google Maps
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Google Maps terrain & satellite imagery indicating precipitation deficits, soil moisture depletion, and crop stress.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2.5 py-1 rounded bg-amber-950/60 border border-amber-800 text-amber-300 font-semibold">
            Google Terrain & Satellite
          </span>
          <span className="text-xs px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-medium">
            Agricultural Guidance
          </span>
        </div>
      </div>

      {/* Real Interactive Map Component with Google Maps Tiles */}
      <IndiaMap
        initialMode="drought"
        initialProvider="google-terrain"
        selectedDistrictId={selectedId}
        onSelectDistrict={(id) => setSelectedId(id)}
        height="640px"
        showLayerControls={true}
      />

      {/* Quick Select Drought Row */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            High Priority Drought Belts — Rain Shadow & Arid Zones
          </h2>
          {onNavigateToCheckRisk && (
            <button
              type="button"
              onClick={() => onNavigateToCheckRisk(selectedId)}
              className="text-xs text-amber-400 hover:text-amber-300 font-medium"
            >
              Analyze {districts.find(d => d.id === selectedId)?.name || 'Selected'} in Check Risk &rarr;
            </button>
          )}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {droughtDistricts.map(d => {
            const isSelected = d.id === selectedId;
            const categoryColors: Record<string, string> = {
              'Critical': 'border-red-900 bg-red-950/30 text-red-200',
              'Severe': 'border-red-600 bg-red-950/20 text-red-300',
              'High': 'border-orange-600 bg-orange-950/20 text-orange-300',
              'Moderate': 'border-yellow-600 bg-yellow-950/20 text-yellow-300',
              'Low': 'border-emerald-600 bg-emerald-950/20 text-emerald-300',
            };
            const style = categoryColors[d.drought_category] || 'border-slate-700 bg-slate-900 text-slate-300';

            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setSelectedId(d.id)}
                className={`p-2.5 rounded-lg border text-left transition ${
                  isSelected ? 'ring-2 ring-amber-400 bg-slate-800' : 'hover:bg-slate-800/60'
                } ${style}`}
              >
                <span className="text-[10px] text-slate-400 block truncate">{d.state}</span>
                <span className="font-bold text-xs text-slate-100 block truncate">{d.name}</span>
                <div className="flex items-center justify-between mt-1 text-[10px]">
                  <span className="font-semibold">{d.drought_category}</span>
                  <span>{Math.round(d.drought_risk_score)} pts</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
