import React, { useState, useEffect } from 'react';
import { DistrictProfile, HistoricalTimelineData } from '../types';
import { api } from '../services/api';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';

interface HistoryPageProps {
  districts: DistrictProfile[];
}

export const HistoryPage: React.FC<HistoryPageProps> = ({ districts }) => {
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>(
    districts[0]?.id || 'assam_dhemaji'
  );
  const [timelineData, setTimelineData] = useState<HistoricalTimelineData | null>(null);

  useEffect(() => {
    fetchTimeline();
  }, [selectedDistrictId]);

  const fetchTimeline = async () => {
    try {
      const data = await api.getHistory(selectedDistrictId);
      setTimelineData(data);
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  };

  const selectedDist = districts.find(d => d.id === selectedDistrictId);

  return (
    <div className="space-y-6 py-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Disaster Risk History & Trends
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            See how flood and drought risk changed over the past 12 months in Indian districts
          </p>
        </div>

        {/* Location Dropdown */}
        <div className="flex items-center gap-2">
          <label htmlFor="history-district-select" className="text-xs font-semibold text-slate-400">
            District:
          </label>
          <select
            id="history-district-select"
            value={selectedDistrictId}
            onChange={(e) => setSelectedDistrictId(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white font-semibold text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500"
          >
            {districts.map(d => (
              <option key={d.id} value={d.id}>
                {d.name}, {d.state}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 12-Month Area Chart */}
      {timelineData && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              12-Month Risk Level for {selectedDist?.name}
            </h2>
            <span className="text-xs text-slate-400">
              Score: 0 (Safe) to 100 (Severe Danger)
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timelineData.timeline} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="floodColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="droughtColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0b132b',
                    borderColor: '#2c3b59',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Area
                  type="monotone"
                  dataKey="flood_risk_score"
                  name="Flood Risk Score"
                  stroke="#06b6d4"
                  fillOpacity={1}
                  fill="url(#floodColor)"
                />
                <Area
                  type="monotone"
                  dataKey="drought_risk_score"
                  name="Drought Risk Score"
                  stroke="#f59e0b"
                  fillOpacity={1}
                  fill="url(#droughtColor)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed pt-2 border-t border-slate-800">
            <strong>How to read this chart:</strong> Higher curves mean higher danger. In monsoon months (June–September), flood risk typically rises in river basins. In hot pre-monsoon or dry post-monsoon months, drought risk rises in arid regions.
          </p>
        </div>
      )}

      {/* Past Extreme Events & Lives Saved */}
      {timelineData && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-white">
            Past Extreme Disaster Incidents in {selectedDist?.name}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {timelineData.historical_extreme_events.map((ev, i) => (
              <div key={i} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">
                    {ev.event} ({ev.year})
                  </span>
                  <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 font-mono font-bold border border-red-800">
                    Peak Score: {ev.peak_risk_score}
                  </span>
                </div>

                <p className="text-slate-300">
                  People in affected area: <strong className="text-white">{ev.affected_population}</strong>
                </p>

                <div className="p-2.5 bg-emerald-950/30 border border-emerald-800 rounded-lg text-emerald-300 text-[11px] leading-relaxed">
                  <strong>How Early Warning Helped:</strong> {ev.loss_mitigated}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

