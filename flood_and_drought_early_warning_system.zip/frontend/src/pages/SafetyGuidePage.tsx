import React, { useState } from 'react';

type HazardMode = 'flood' | 'drought';
type PhaseMode = 'before' | 'during' | 'after';

export const SafetyGuidePage: React.FC = () => {
  const [selectedHazard, setSelectedHazard] = useState<HazardMode>('flood');
  const [selectedPhase, setSelectedPhase] = useState<PhaseMode>('before');

  // Emergency procedures data matching exact specifications
  const floodProcedures = {
    before: {
      title: "Before a Flood — Practical Preparation Steps",
      steps: [
        "Monitor official weather and flood warnings from local administration, IMD, and AquaSentinel.",
        "Prepare an emergency kit with 3 days of clean drinking water, non-perishable food, flashlights, and a whistle.",
        "Keep important documents (Aadhaar cards, land records, voter IDs, ration cards) in waterproof storage bags.",
        "Identify safer higher ground, designated government relief shelters, and safe evacuation routes.",
        "Fully charge mobile phones, power banks, and emergency flashlights.",
        "Protect essential prescription medicines and store them in waterproof containers.",
        "Strictly follow local administration and disaster management authority instructions."
      ]
    },
    during: {
      title: "During a Flood — Immediate Life Safety Steps",
      steps: [
        "Move to safer high ground or designated village shelters immediately when advised.",
        "Stay completely away from flooded roads, culverts, river banks, and storm drains.",
        "Do not walk or drive through floodwater — just 15 cm of moving water can knock you down.",
        "Avoid electrical equipment, meter boxes, and fallen power lines in flooded areas.",
        "Follow verified evacuation instructions issued by NDRF, SDRF, and civil defense personnel.",
        "Keep children, elderly family members, and vulnerable people safe and accompanied.",
        "Contact emergency services immediately (Call 112 or 1077) if anyone is trapped."
      ]
    },
    after: {
      title: "After a Flood — Safe Recovery & Disease Prevention",
      steps: [
        "Return to your home only after disaster authorities officially say it is safe.",
        "Avoid damaged electrical equipment, submerged wiring, and gas connections until inspected.",
        "Avoid contaminated floodwater to prevent dangerous waterborne diseases (cholera, leptospirosis).",
        "Check drinking water safety — boil water vigorously for 3 minutes or use chlorine tablets.",
        "Report dangerous infrastructure (cracked bridges, breached dykes, fallen poles) to local officials.",
        "Seek medical help at your nearest primary health center if anyone has wounds or fever."
      ]
    }
  };

  const droughtProcedures = {
    before: {
      title: "Before Drought Becomes Severe — Conservation & Readiness",
      steps: [
        "Monitor rainfall departure bulletins, groundwater tables, and drought alerts regularly.",
        "Store domestic and drinking water safely in clean, covered, and sanitized tanks.",
        "Reduce unnecessary water usage — repair leaking taps, pipes, and village overhead cisterns.",
        "Prepare agricultural water plans and consult local Krishi Vigyan Kendra (KVK) advisories.",
        "Maintain and desilt rooftop rainwater harvesting systems, check dams, and farm ponds."
      ]
    },
    during: {
      title: "During Drought — Citizen & Farmer Protocols",
      citizens: [
        "Conserve drinking water strictly — suspend lawn watering, vehicle washing, and wasteful usage.",
        "Follow local water advisories and scheduled municipal water distribution rotas.",
        "Avoid wasting water — reuse vegetable washing greywater for home sanitation.",
        "Keep drinking water clean, covered, and free from insect infestation."
      ],
      farmers: [
        "Plan irrigation efficiently — deploy drip lines or micro-sprinklers during dawn or dusk.",
        "Monitor soil moisture depth before scheduling each irrigation cycle.",
        "Use suitable water conservation methods like organic straw or biomass mulching (5 to 8 cm).",
        "Follow local agricultural extension recommendations for moisture-deficit management.",
        "Consider locally suitable drought-resistant crops (millets like Bajra, Jowar, Ragi, or pulses)."
      ]
    },
    after: {
      title: "After Drought — Water Restoration & Soil Recovery",
      steps: [
        "Continue water conservation habits even after the initial monsoon showers begin.",
        "Check water quality and salinity in borewells before drinking or irrigating.",
        "Assess agricultural damage and document standing crops for PMFBY insurance relief.",
        "Follow recovery guidance from agricultural officers to restore depleted soil organic matter.",
        "Restore water resources carefully — deepen farm trenches, recharge wells, and bund ponds."
      ]
    }
  };

  const currentFlood = floodProcedures[selectedPhase];
  const currentDrought = droughtProcedures[selectedPhase];

  return (
    <div className="space-y-6 py-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Safety & Emergency Guide
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Simple, practical step-by-step procedures for ordinary citizens, farmers, and students.
          </p>
        </div>

        <button
          type="button"
          onClick={() => window.print()}
          className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold self-start sm:self-auto transition"
        >
          Print Guide
        </button>
      </div>

      {/* Emergency Helplines Card */}
      <div className="bg-rose-950/40 border border-rose-800/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div>
          <span className="text-xs uppercase font-bold text-rose-300 block tracking-wider">
            National Emergency Numbers (India)
          </span>
          <span className="text-xs text-rose-200/80">
            For immediate life safety or search and rescue:
          </span>
        </div>
        <div className="flex flex-wrap gap-2 text-xs font-bold font-mono">
          <a href="tel:112" className="px-3 py-1.5 bg-rose-900 border border-rose-700 rounded-lg text-white hover:bg-rose-800 transition">
            Emergency: 112
          </a>
          <a href="tel:1070" className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-amber-300 hover:bg-slate-800 transition">
            Disaster: 1070 / 1077
          </a>
          <a href="tel:108" className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-cyan-300 hover:bg-slate-800 transition">
            Ambulance: 108
          </a>
        </div>
      </div>

      {/* Interactive Selectors */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
        
        {/* Step 1: Select Hazard */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            1. Select Disaster Hazard:
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setSelectedHazard('flood')}
              className={`py-3 px-4 rounded-xl border text-sm font-bold transition flex items-center justify-center gap-2 ${
                selectedHazard === 'flood'
                  ? 'bg-rose-600 border-rose-500 text-white shadow-lg shadow-rose-900/30'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>Flood Safety</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedHazard('drought')}
              className={`py-3 px-4 rounded-xl border text-sm font-bold transition flex items-center justify-center gap-2 ${
                selectedHazard === 'drought'
                  ? 'bg-amber-600 border-amber-500 text-white shadow-lg shadow-amber-900/30'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>Drought Safety</span>
            </button>
          </div>
        </div>

        {/* Step 2: Select Phase */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">
            2. Select Disaster Phase:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['before', 'during', 'after'] as PhaseMode[]).map((phase) => (
              <button
                key={phase}
                type="button"
                onClick={() => setSelectedPhase(phase)}
                className={`py-2 px-3 rounded-lg border text-xs font-semibold capitalize transition ${
                  selectedPhase === phase
                    ? 'bg-cyan-600 border-cyan-500 text-white shadow-md'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
                }`}
              >
                {phase === 'before' ? 'Before (Preparation)' : phase === 'during' ? 'During (Safety Steps)' : 'After (Recovery)'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Procedures Content Area */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 space-y-4">
        
        {/* Title */}
        <div className="border-b border-slate-800 pb-3">
          <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider block">
            Official Safety Protocol
          </span>
          <h2 className="text-xl font-bold text-white mt-1">
            {selectedHazard === 'flood' ? currentFlood.title : currentDrought.title}
          </h2>
        </div>

        {/* Flood Procedures Content */}
        {selectedHazard === 'flood' && (
          <div className="space-y-3">
            {currentFlood.steps.map((step, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3.5 rounded-lg bg-slate-950/70 border border-slate-800/80"
              >
                <span className="w-6 h-6 rounded-full bg-rose-950 border border-rose-800 text-rose-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  {idx + 1}
                </span>
                <p className="text-sm text-slate-200 leading-relaxed font-medium">
                  {step}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* Drought Procedures Content */}
        {selectedHazard === 'drought' && (
          <>
            {selectedPhase === 'during' ? (
              <div className="space-y-5">
                {/* Citizens Section */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 border-b border-slate-800 pb-1.5">
                    For Citizens & Villagers:
                  </h3>
                  {droughtProcedures.during.citizens.map((step, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-3 p-3 rounded-lg bg-slate-950/70 border border-slate-800/80"
                    >
                      <span className="w-5 h-5 rounded-full bg-amber-950 border border-amber-800 text-amber-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-sm text-slate-200 leading-relaxed font-medium">
                        {step}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Farmers Section */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 border-b border-slate-800 pb-1.5">
                    For Farmers & Agricultural Producers:
                  </h3>
                  {droughtProcedures.during.farmers.map((step, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-3 p-3 rounded-lg bg-slate-950/70 border border-slate-800/80"
                    >
                      <span className="w-5 h-5 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-sm text-slate-200 leading-relaxed font-medium">
                        {step}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {('steps' in currentDrought ? currentDrought.steps : []).map((step: string, idx: number) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3 p-3.5 rounded-lg bg-slate-950/70 border border-slate-800/80"
                  >
                    <span className="w-6 h-6 rounded-full bg-amber-950 border border-amber-800 text-amber-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <p className="text-sm text-slate-200 leading-relaxed font-medium">
                      {step}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Emergency Life Safety Callout */}
        <div className="mt-4 p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span>
            Strictly follow instructions from local authorities and District Magistrates during declared disasters.
          </span>
          <span className="text-slate-300 font-semibold shrink-0">
            NDMA Guidelines Aligned
          </span>
        </div>
      </div>
    </div>
  );
};
