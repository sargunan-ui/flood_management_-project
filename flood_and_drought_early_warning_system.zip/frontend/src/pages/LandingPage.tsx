import React from 'react';
import {
  ShieldAlert,
  Droplets,
  Flame,
  ArrowRight,
  BrainCircuit,
  MapPin,
  Sparkles,
  Users,
  Compass,
  CheckCircle2,
  LineChart,
  Radio,
  FileCheck2,
  AlertTriangle,
  Layers
} from 'lucide-react';
import { AlertItem } from '../types';

interface LandingPageProps {
  onNavigate: (page: string) => void;
  recentAlerts: AlertItem[];
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, recentAlerts }) => {
  return (
    <div className="space-y-16 py-6">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl p-8 sm:p-12 lg:p-16 border border-cyan-500/20 bg-gradient-to-b from-navy-900 via-navy-950 to-navy-950 shadow-2xl">
        {/* Glow ambient spots */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Green Planet — GP-03 Hackathon Submission</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            AI-Powered Early Warning &{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">
              Climate Resilience Platform
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            AquaSentinel AI transforms complex meteorological & hydrological telemetry into localized, explainable, and life-saving flood and drought early warnings before catastrophe strikes.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-navy-950 font-bold text-sm shadow-glow-cyan transition-all transform hover:-translate-y-0.5"
            >
              <Compass className="w-4 h-4" />
              <span>Open Disaster Command Center</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('map')}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl glass-card hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 font-semibold text-sm transition-all"
            >
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span>Interactive Geospatial Risk Map</span>
            </button>
          </div>

          {/* Hero Dual Hazard Quick Launchers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8 max-w-2xl mx-auto text-left">
            <div
              onClick={() => onNavigate('flood')}
              className="glass-card p-4 rounded-xl border border-cyan-500/30 hover:border-cyan-400 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition">
                    Flood Prediction Simulator
                  </h4>
                  <span className="text-[11px] text-slate-400">9-Factor Runoff & River Surge Engine</span>
                </div>
              </div>
              <p className="text-xs text-slate-400">
                Test cloudbursts, soil saturation, and river overtopping with TreeSHAP explanations.
              </p>
            </div>

            <div
              onClick={() => onNavigate('drought')}
              className="glass-card p-4 rounded-xl border border-amber-500/30 hover:border-amber-400 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100 group-hover:text-amber-300 transition">
                    Drought Prediction Simulator
                  </h4>
                  <span className="text-[11px] text-slate-400">VCI & Soil Moisture Deficit Engine</span>
                </div>
              </div>
              <p className="text-xs text-slate-400">
                Model rain-fed crop failure, consecutive dry spells, and protective irrigation triggers.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Metric Highlights Strip */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Monitored Indian Hotspots', val: '22 Districts', sub: 'High flood & drought vulnerability zones' },
          { label: 'Flood Model ROC-AUC', val: '0.9926', sub: 'Trained to strictly penalize false negatives' },
          { label: 'Drought Model Accuracy', val: '97.56%', sub: 'Gradient Boosting with VCI integration' },
          { label: 'XAI Explainability', val: '100% Attributed', sub: 'Answers "Why is this location at risk?"' },
        ].map((stat, i) => (
          <div key={i} className="glass-card p-5 rounded-xl border border-slate-700/40 text-center">
            <span className="text-2xl sm:text-3xl font-extrabold font-mono text-cyan-400 block mb-1">
              {stat.val}
            </span>
            <span className="text-xs font-bold text-slate-200 block uppercase tracking-wider mb-1">
              {stat.label}
            </span>
            <span className="text-[11px] text-slate-400 leading-tight block">
              {stat.sub}
            </span>
          </div>
        ))}
      </section>

      {/* Core Innovation: Unified Flood & Drought Intelligence */}
      <section className="glass-panel p-8 sm:p-10 rounded-2xl border border-slate-700/60">
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Layers className="w-4 h-4" />
            <span>The Innovation Imperative</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Why Unified Early Warning Matters
          </h2>
          <p className="text-sm text-slate-300 mt-2 leading-relaxed">
            Disaster agencies historically operate in silos: flood forecasting sits in river authorities, while drought monitoring sits in agriculture ministries. Yet regions like Maharashtra, Bihar, and Karnataka oscillate between deluge and acute water distress within the same calendar year. AquaSentinel bridges this divide.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-xl bg-navy-900/70 border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 w-fit">
              <Droplets className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-100">Physics-Grounded Hydrology</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Models soil infiltration thresholds, antecedent 7-day storm volume, river gauge clearance, and terrain pooling depressions to anticipate surface flash inundations.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-navy-900/70 border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30 w-fit">
              <Flame className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-100">Agronomic Drought Resilience</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Fuses rainfall deficit % with satellite Vegetation Condition Index (VCI) and consecutive rainless spells to trigger life-saving micro-irrigation and fodder reserves.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-navy-900/70 border border-slate-800 space-y-3">
            <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 w-fit">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-100">Explainable AI Attribution</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              No black boxes. Every warning presents transparent feature contribution percentages and plain-English reasons understandable to farmers, panchayats, and officials.
            </p>
          </div>
        </div>
      </section>

      {/* Target Personas Section */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">Multi-Stakeholder Impact</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Who Benefits from AquaSentinel?</h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Tailored actionable guidance customized for every decision-maker along the disaster chain.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-card p-6 rounded-2xl border border-emerald-500/30 space-y-4">
            <span className="px-2.5 py-1 rounded text-xs font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              Farmers & Agronomists
            </span>
            <h3 className="text-base font-bold text-slate-100">Protective Crop Planning</h3>
            <ul className="text-xs text-slate-300 space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Micro-irrigation & alternate furrow water rationing</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Field drainage clearance prior to heavy rainfall surges</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Livestock relocation to elevated community bunds</span>
              </li>
            </ul>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-cyan-500/30 space-y-4">
            <span className="px-2.5 py-1 rounded text-xs font-bold uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              Rural Residents & Families
            </span>
            <h3 className="text-base font-bold text-slate-100">Household Life-Safety</h3>
            <ul className="text-xs text-slate-300 space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>18-24 hour advance warning to pack potable water & Go-Bags</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>Avoid flooded culverts and waterlogged electrical lines</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>Domestic greywater conservation during acute dry spells</span>
              </li>
            </ul>
          </div>

          <div className="glass-card p-6 rounded-2xl border border-amber-500/30 space-y-4">
            <span className="px-2.5 py-1 rounded text-xs font-bold uppercase bg-amber-500/10 text-amber-400 border border-amber-500/30">
              Disaster Response Authorities (DDMA)
            </span>
            <h3 className="text-base font-bold text-slate-100">Tactical Resource Staging</h3>
            <ul className="text-xs text-slate-300 space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Pre-positioning NDRF motorized boats near critical breach zones</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Barrage gate discharge coordination across downstream districts</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>GPS tanker routing to acute groundwater-depleted villages</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Bottom Launch Banner */}
      <section className="glass-panel p-8 rounded-2xl border border-cyan-500/40 text-center space-y-4 bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900">
        <h2 className="text-2xl font-bold text-white">Experience AquaSentinel AI in Action</h2>
        <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
          Explore the command center dashboard, simulate extreme cloudburst or drought scenarios, and inspect Leaflet geospatial telemetry.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => onNavigate('dashboard')}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-navy-950 font-bold text-xs transition"
          >
            Launch Command Dashboard
          </button>
          <button
            onClick={() => onNavigate('map')}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 font-semibold text-xs transition"
          >
            Explore Geospatial Map
          </button>
          <button
            onClick={() => onNavigate('about')}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 font-semibold text-xs transition"
          >
            Review ML Methodology
          </button>
        </div>
      </section>
    </div>
  );
};

