import React, { useState } from 'react';
import { Waves, Sun, Layers, ShieldAlert, ArrowRight, MapPin, Gauge } from 'lucide-react';
import { IndiaMap, MapLayerMode } from '../components/IndiaMap';
import { DistrictProfile } from '../types';

interface HazardMapPageProps {
  districts: DistrictProfile[];
  initialDistrictId?: string;
  initialHazardMode?: 'flood' | 'drought' | 'combined';
  onNavigateToCheckRisk?: (districtId: string) => void;
}

export const HazardMapPage: React.FC<HazardMapPageProps> = ({
  districts,
  initialDistrictId,
  initialHazardMode = 'combined',
  onNavigateToCheckRisk
}) => {
  const [selectedId, setSelectedId] = useState<string>(
    initialDistrictId || 'assam_dhemaji'
  );
  const [hazardMode, setHazardMode] = useState<MapLayerMode>(initialHazardMode);
  const [activeFilterTab, setActiveFilterTab] = useState<'all' | 'flood' | 'drought'>('all');

  const selectedDistrict = districts.find(d => d.id === selectedId) || districts[0];

  const floodDistricts = districts.filter(d => d.primary_hazard === 'Flood' || d.flood_risk_score >= 50);
  const droughtDistricts = districts.filter(d => d.primary_hazard === 'Drought' || d.drought_risk_score >= 40);

  const displayedDistricts = activeFilterTab === 'flood'
    ? floodDistricts
    : activeFilterTab === 'drought'
    ? droughtDistricts
    : districts;

  return (
    <div className="space-y-6 py-6 animate-fade-in">
      
      {/* Page Header with Dual Hazard Mode Selector */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
              <Layers className="w-7 h-7 text-cyan-400" />
              Flood &amp; Drought Geospatial Map
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
              Google Maps
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Unified multi-hazard geospatial map showing river inundation basins, CWC water gauge sensors, and agricultural drought soil moisture stress.
          </p>
        </div>

        {/* Hazard View Switcher Pills */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
          <span className="text-[10px] uppercase font-bold text-slate-400 px-2 hidden sm:inline">
            Active Layer:
          </span>
          <button
            type="button"
            onClick={() => setHazardMode('combined')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              hazardMode === 'combined'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Combined Dual-Hazard</span>
          </button>

          <button
            type="button"
            onClick={() => setHazardMode('flood')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              hazardMode === 'flood'
                ? 'bg-cyan-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Waves className="w-3.5 h-3.5" />
            <span>Flood Basins</span>
          </button>

          <button
            type="button"
            onClick={() => setHazardMode('drought')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              hazardMode === 'drought'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Drought Belts</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Map Component */}
      <IndiaMap
        key={hazardMode}
        initialMode={hazardMode}
        initialProvider="google-roadmap"
        selectedDistrictId={selectedId}
        onSelectDistrict={(id) => setSelectedId(id)}
        height="640px"
        showLayerControls={true}
      />

      {/* Selected District Real-Time Status & Action Card */}
      {selectedDistrict && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" />
              <h3 className="text-lg font-bold text-white">
                {selectedDistrict.name}, {selectedDistrict.state}
              </h3>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md uppercase ${
                selectedDistrict.primary_hazard === 'Flood'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  : 'bg-amber-950 text-amber-300 border border-amber-800'
              }`}>
                {selectedDistrict.primary_hazard} Prone
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Terrain Elevation: <strong>{selectedDistrict.elevation}m</strong> a.s.l. • 
              River Basin: <strong>{selectedDistrict.river_basin || 'Catchment Basin'}</strong> • 
              Soil Type: <strong>{selectedDistrict.soil_type || 'Agricultural Soil'}</strong>
            </p>
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block uppercase">Flood Risk</span>
              <span className="text-base font-extrabold text-cyan-400 font-mono">
                {Math.round(selectedDistrict.flood_risk_score)}/100
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 block uppercase">Drought Deficit</span>
              <span className="text-base font-extrabold text-amber-400 font-mono">
                {Math.round(selectedDistrict.drought_risk_score)}/100
              </span>
            </div>

            {onNavigateToCheckRisk && (
              <button
                type="button"
                onClick={() => onNavigateToCheckRisk(selectedDistrict.id)}
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shadow-lg shadow-cyan-900/30 flex items-center gap-1.5 whitespace-nowrap ml-2"
              >
                <span>Citizen Risk Check</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Quick Select Hotspot Tabs (Flood Basins vs Drought Belts) */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Focus Location by Threat:
            </span>
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveFilterTab('all')}
                className={`px-2.5 py-0.5 rounded text-xs font-semibold transition ${
                  activeFilterTab === 'all'
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All 22 ({districts.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilterTab('flood')}
                className={`px-2.5 py-0.5 rounded text-xs font-semibold transition ${
                  activeFilterTab === 'flood'
                    ? 'bg-cyan-600 text-white'
                    : 'text-slate-400 hover:text-cyan-300'
                }`}
              >
                Flood Basins ({floodDistricts.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilterTab('drought')}
                className={`px-2.5 py-0.5 rounded text-xs font-semibold transition ${
                  activeFilterTab === 'drought'
                    ? 'bg-amber-600 text-white'
                    : 'text-slate-400 hover:text-amber-300'
                }`}
              >
                Drought Belts ({droughtDistricts.length})
              </button>
            </div>
          </div>

          <span className="text-xs text-slate-400">
            Click any district to pan and inspect live telemetry
          </span>
        </div>

        {/* Hotspots Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {displayedDistricts.map(d => {
            const isSelected = d.id === selectedId;
            const isFlood = d.primary_hazard === 'Flood';
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setSelectedId(d.id)}
                className={`p-3 rounded-xl border text-left transition ${
                  isSelected
                    ? isFlood
                      ? 'bg-cyan-950/70 border-cyan-500 text-white shadow-lg shadow-cyan-900/30'
                      : 'bg-amber-950/70 border-amber-500 text-white shadow-lg shadow-amber-900/30'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs truncate">{d.name}</span>
                  <span className={`w-2 h-2 rounded-full ${isFlood ? 'bg-cyan-400' : 'bg-amber-400'}`} />
                </div>
                <span className="text-[10px] text-slate-400 block truncate">{d.state}</span>
                <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800/80 text-[10px]">
                  <span className="text-slate-400">{d.primary_hazard}</span>
                  <span className="font-mono font-bold text-white">
                    {Math.round(isFlood ? d.flood_risk_score : d.drought_risk_score)}/100
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

