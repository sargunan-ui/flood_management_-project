import React, { useState, useEffect } from 'react';
import {
  Flame,
  Play,
  RotateCcw,
  Sparkles,
  Sun,
  MapPin,
  Sprout,
  Thermometer,
  DropletOff,
  CheckCircle2,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { DistrictProfile, DroughtPredictionResponse } from '../types';
import { RiskGauge } from '../components/RiskGauge';
import { ExplainabilityCard } from '../components/ExplainabilityCard';
import { RecommendationsCard } from '../components/RecommendationsCard';
import { LiveWeatherBanner } from '../components/LiveWeatherBanner';
import { api } from '../services/api';

interface DroughtPredictionPageProps {
  districts: DistrictProfile[];
  initialDistrictId?: string;
}

export const DroughtPredictionPage: React.FC<DroughtPredictionPageProps> = ({
  districts,
  initialDistrictId
}) => {
  // Input parameters state
  const [locationName, setLocationName] = useState('Barmer, Rajasthan');
  const [rainfallDeficit, setRainfallDeficit] = useState(78.0); // % below normal
  const [temperature, setTemperature] = useState(41.5);
  const [soilMoisture, setSoilMoisture] = useState(11.0);
  const [relativeHumidity, setRelativeHumidity] = useState(24.0);
  const [vegetationCondition, setVegetationCondition] = useState(18.0); // VCI %
  const [historicalRainfall, setHistoricalRainfall] = useState(310.0);
  const [consecutiveDryDays, setConsecutiveDryDays] = useState(64);

  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<DroughtPredictionResponse | null>(null);
  const [isLiveSynced, setIsLiveSynced] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string>('');

  // Preset scenarios
  const presets = [
    {
      name: 'Thar Desert Hyper-Arid',
      location: 'Barmer, Rajasthan',
      deficit: 86,
      temp: 43.5,
      soil: 8.5,
      humidity: 16,
      vci: 12,
      histRain: 270,
      dryDays: 82
    },
    {
      name: 'Marathwada Kharif Crop Stress',
      location: 'Latur, Maharashtra',
      deficit: 62,
      temp: 38.0,
      soil: 16.5,
      humidity: 32,
      vci: 24,
      histRain: 740,
      dryDays: 52
    },
    {
      name: 'Rayalaseema Groundnut Deficit',
      location: 'Anantapur, Andhra Pradesh',
      deficit: 70,
      temp: 37.0,
      soil: 12.0,
      humidity: 28,
      vci: 20,
      histRain: 550,
      dryDays: 68
    },
    {
      name: 'Normal Humid Coastal Delta',
      location: 'Cauvery / Godavari Basin',
      deficit: 4,
      temp: 29.0,
      soil: 72.0,
      humidity: 78,
      vci: 82,
      histRain: 1200,
      dryDays: 3
    }
  ];

  const applyPreset = (p: typeof presets[0]) => {
    setLocationName(p.location);
    setRainfallDeficit(p.deficit);
    setTemperature(p.temp);
    setSoilMoisture(p.soil);
    setRelativeHumidity(p.humidity);
    setVegetationCondition(p.vci);
    setHistoricalRainfall(p.histRain);
    setConsecutiveDryDays(p.dryDays);
    setIsLiveSynced(false);
    setSyncStatus('');
  };

  useEffect(() => {
    runPrediction();
  }, []);

  const runPrediction = async () => {
    setLoading(true);
    try {
      const res = await api.predictDrought({
        location_name: locationName,
        rainfall_deficit: Number(rainfallDeficit),
        temperature: Number(temperature),
        soil_moisture: Number(soilMoisture),
        relative_humidity: Number(relativeHumidity),
        vegetation_condition: Number(vegetationCondition),
        historical_rainfall: Number(historicalRainfall),
        consecutive_dry_days: Number(consecutiveDryDays)
      });
      setPrediction(res);
    } catch (err) {
      console.error('Failed to run drought prediction:', err);
    } finally {
      setLoading(false);
    }
  };

  // Live Open-Meteo sync
  const handleSyncLiveDistrict = async (distId: string) => {
    const dist = districts.find(d => d.id === distId);
    if (!dist) return;

    setLocationName(`${dist.name}, ${dist.state}`);
    if (dist.key_metrics.avg_monsoon_rainfall_mm) {
      setHistoricalRainfall(dist.key_metrics.avg_monsoon_rainfall_mm);
    }

    try {
      setSyncStatus(`Fetching Open-Meteo live stream for ${dist.name}...`);
      const weather = await api.getLiveWeather(dist.latitude, dist.longitude);
      setTemperature(weather.temperature);
      setRelativeHumidity(weather.relative_humidity);
      setSoilMoisture(weather.soil_moisture > 0 ? weather.soil_moisture : dist.key_metrics.soil_moisture_pct || 15);
      
      // Calculate deficit proxy
      const deficitEst = dist.drought_risk_score > 70 ? 75 : 20;
      setRainfallDeficit(deficitEst);
      setConsecutiveDryDays(dist.key_metrics.consecutive_dry_days || 45);
      setVegetationCondition(dist.key_metrics.vegetation_condition_index || 25);
      
      setIsLiveSynced(weather.is_live);
      setSyncStatus(`Synced with ${weather.source}`);
    } catch (err) {
      setSyncStatus('Using baseline telemetry profile');
    }
  };

  return (
    <div className="space-y-8 py-4">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Flame className="w-4 h-4" />
            <span>AI Agricultural & Meteorological Drought Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Drought Severity & Crop Stress Predictor
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Quantifies rainfall deficits, soil moisture desiccation, and satellite vegetation condition indices
          </p>
        </div>

        <LiveWeatherBanner isLive={isLiveSynced} sourceText={syncStatus || 'Calibrated Drought Parameters'} />
      </div>

      {/* Preset Scenarios Ribbon */}
      <div className="glass-panel p-4 rounded-xl border border-slate-700/50 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Rapid Presets:
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {presets.map((p, i) => (
            <button
              key={i}
              onClick={() => applyPreset(p)}
              className="px-3 py-1 rounded-lg bg-navy-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 text-xs border border-slate-700 font-medium transition"
            >
              {p.name}
            </button>
          ))}
        </div>

        {/* District Selector for Live Sync */}
        <div className="flex items-center gap-2">
          <MapPin className="w-3.5 h-3.5 text-amber-400" />
          <select
            onChange={(e) => handleSyncLiveDistrict(e.target.value)}
            className="bg-navy-900 border border-slate-700 text-xs text-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:border-amber-500"
            defaultValue=""
          >
            <option value="" disabled>Load District Telemetry...</option>
            {districts.map(d => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.state}) — {d.primary_hazard}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Left Controls (Sliders), Right Predictions & Explainability */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Parameter Form (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-slate-700/50 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/50">
              <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
                <Sun className="w-4 h-4 text-amber-400" />
                Agronomic & Climatic Inputs
              </h3>
              <span className="text-[10px] font-mono text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                7 Parameters
              </span>
            </div>

            {/* Assessment Location Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Target Location / District Name
              </label>
              <input
                type="text"
                value={locationName}
                onChange={(e) => setLocationName(e.target.value)}
                className="w-full bg-navy-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
              />
            </div>

            {/* Slider 1: Seasonal Rainfall Deficit */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-300">Seasonal Rainfall Deficit</span>
                <span className="font-mono font-bold text-amber-400">{rainfallDeficit}% below normal</span>
              </div>
              <input
                type="range"
                min="0"
                max="98"
                step="1"
                value={rainfallDeficit}
                onChange={(e) => setRainfallDeficit(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0% (Normal)</span>
                <span>25% (Moderate)</span>
                <span>60%+ (Severe Deficit)</span>
              </div>
            </div>

            {/* Slider 2: Consecutive Dry Days */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-300">Consecutive Rainless Days</span>
                <span className="font-mono font-bold text-amber-400">{consecutiveDryDays} days</span>
              </div>
              <input
                type="range"
                min="0"
                max="120"
                step="1"
                value={consecutiveDryDays}
                onChange={(e) => setConsecutiveDryDays(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0 days</span>
                <span>30 days (Dry Spell)</span>
                <span>75+ days (Prolonged)</span>
              </div>
            </div>

            {/* Slider 3: Soil Moisture Saturation */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-300">Topsoil Moisture Level</span>
                <span className="font-mono font-bold text-amber-400">{soilMoisture}%</span>
              </div>
              <input
                type="range"
                min="4"
                max="85"
                step="0.5"
                value={soilMoisture}
                onChange={(e) => setSoilMoisture(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>&lt;10% (Wilting Point)</span>
                <span>25% (Deficit)</span>
                <span>&gt;60% (Hydrated)</span>
              </div>
            </div>

            {/* Slider 4: Vegetation Condition Index (VCI) */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-300">Vegetation Condition Index (VCI / NDVI)</span>
                <span className="font-mono font-bold text-amber-400">{vegetationCondition}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="95"
                step="1"
                value={vegetationCondition}
                onChange={(e) => setVegetationCondition(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>&lt;20% (Canopy Browning)</span>
                <span>40% (Stress)</span>
                <span>&gt;70% (Vigorous Crop)</span>
              </div>
            </div>

            {/* Slider 5: Temperature */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-300">Ambient Temperature</span>
                <span className="font-mono font-bold text-amber-400">{temperature}°C</span>
              </div>
              <input
                type="range"
                min="18"
                max="49"
                step="0.5"
                value={temperature}
                onChange={(e) => setTemperature(Number(e.target.value))}
                className="w-full accent-amber-400 bg-slate-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Relative Humidity & Normal Rainfall */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Relative Humidity (%)
                </label>
                <input
                  type="number"
                  min="10"
                  max="95"
                  value={relativeHumidity}
                  onChange={(e) => setRelativeHumidity(Number(e.target.value))}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Normal Rainfall (mm)
                </label>
                <input
                  type="number"
                  min="100"
                  max="2500"
                  value={historicalRainfall}
                  onChange={(e) => setHistoricalRainfall(Number(e.target.value))}
                  className="w-full bg-navy-900 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>

            {/* Run Prediction CTA Button */}
            <div className="pt-2">
              <button
                onClick={runPrediction}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-navy-950 font-bold text-sm shadow-glow-amber transition disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-navy-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-navy-950" />
                    <span>Run Drought Risk Inference</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Prediction Outcome, Explainability & Recommendations (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {prediction && (
            <>
              {/* Primary Prediction Score Card */}
              <div className="glass-panel p-6 rounded-2xl border border-slate-700/60 shadow-xl">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pb-4 border-b border-slate-700/50">
                  <div className="flex flex-col items-center sm:items-start text-center sm:text-left">
                    <span className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                      Assessment Zone
                    </span>
                    <h2 className="text-2xl font-extrabold text-white">
                      {prediction.location_name}
                    </h2>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-slate-400">Confidence:</span>
                      <span className="text-xs font-semibold text-amber-300">
                        {prediction.confidence_level}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-slate-400">Model:</span>
                      <span className="text-xs font-mono text-slate-300">
                        Gradient Boosting + VCI Regressor (ROC-AUC: 0.996)
                      </span>
                    </div>
                  </div>

                  {/* Gauge */}
                  <RiskGauge
                    score={prediction.severity_score}
                    category={prediction.drought_category}
                    label="Drought Severity Score"
                    size="md"
                    hazardType="drought"
                  />
                </div>

                {/* Sub-metrics strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 text-center">
                  <div className="p-2.5 rounded-xl bg-navy-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Drought Probability</span>
                    <span className="text-base font-mono font-bold text-amber-400">
                      {(prediction.drought_probability * 100).toFixed(1)}%
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-navy-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Severity Level</span>
                    <span className="text-base font-bold text-slate-100">
                      {prediction.drought_category}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-navy-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Crop Stress Stage</span>
                    <span className="text-base font-mono font-bold text-orange-400">
                      {vegetationCondition < 25 ? 'Wilting Failure' : 'Moisture Deficit'}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-navy-900/80 border border-slate-800">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Relief Fund Trigger</span>
                    <span className="text-base font-mono font-bold text-slate-100">
                      {prediction.severity_score >= 75 ? 'SDRF Eligible' : 'Monitor Only'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Explainable AI Card */}
              <ExplainabilityCard
                factors={prediction.contributing_factors}
                plainReasons={prediction.plain_english_explanation}
                hazardType="drought"
              />

              {/* Persona-Specific Action Recommendations */}
              <RecommendationsCard
                recommendations={prediction.agricultural_recommendations}
                riskCategory={prediction.drought_category}
                locationName={prediction.location_name}
                hazardType="drought"
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
};

