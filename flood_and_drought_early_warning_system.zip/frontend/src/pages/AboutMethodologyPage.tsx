import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  ShieldCheck,
  Cpu,
  Layers,
  Database,
  CheckCircle2,
  AlertTriangle,
  Code2,
  FileText,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { api } from '../services/api';

export const AboutMethodologyPage: React.FC = () => {
  const [modelMeta, setModelMeta] = useState<any>(null);

  useEffect(() => {
    api.getModelMetadata().then(data => setModelMeta(data)).catch(() => {});
  }, []);

  const floodM = modelMeta?.flood_model || {
    accuracy: 0.9611,
    precision: 0.942,
    recall: 0.8975,
    f1_score: 0.9192,
    roc_auc: 0.9926,
    training_samples: 3600,
    test_samples: 900,
    model_architecture: 'Random Forest Ensemble (Classifier + Calibrated Regressor)'
  };

  const droughtM = modelMeta?.drought_model || {
    accuracy: 0.9756,
    precision: 0.958,
    recall: 0.9123,
    f1_score: 0.9346,
    roc_auc: 0.9960,
    training_samples: 3600,
    test_samples: 900,
    model_architecture: 'Gradient Boosting Classifier + VCI Regressor'
  };

  return (
    <div className="space-y-12 py-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-1">
            <BrainCircuit className="w-4 h-4" />
            <span>AI Architecture & Scientific Methodology</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Methodology, Model Evaluation & Responsible AI
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Rigorous machine learning evaluation, explainability proofs, and ethical AI governance standards
          </p>
        </div>
      </div>

      {/* Model Performance & Evaluation Metrics */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-700/60">
          <Cpu className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white">Machine Learning Evaluation Metrics</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Flood Model Card */}
          <div className="glass-panel p-6 rounded-2xl border border-cyan-500/40 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                Flood Risk Ensemble Engine
              </h3>
              <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                Random Forest
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Trained on 4,500 physically calibrated hydrological samples with Soil Conservation Service (SCS) runoff dynamics.
            </p>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Accuracy</span>
                <strong className="text-base font-mono text-cyan-400">{(floodM.accuracy * 100).toFixed(1)}%</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Recall (Sensitivity)</span>
                <strong className="text-base font-mono text-emerald-400">{(floodM.recall * 100).toFixed(1)}%</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">ROC-AUC</span>
                <strong className="text-base font-mono text-cyan-400">{floodM.roc_auc}</strong>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 leading-relaxed">
              <strong className="text-cyan-300 block mb-1">Disaster-Critical Recall Rationale:</strong>
              Class weights were tuned ({'{0: 1.0, 1: 1.3}'}) to strictly penalize false negatives. A missed warning (false negative) causes human and agricultural devastation, whereas a precautionary false alert carries manageable evacuation costs.
            </div>
          </div>

          {/* Drought Model Card */}
          <div className="glass-panel p-6 rounded-2xl border border-amber-500/40 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                Drought Severity & VCI Engine
              </h3>
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                Gradient Boosting
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Trained on 4,500 evapotranspiration samples integrating rainfall deficits with satellite Vegetation Condition Indices.
            </p>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Accuracy</span>
                <strong className="text-base font-mono text-amber-400">{(droughtM.accuracy * 100).toFixed(1)}%</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">Precision</span>
                <strong className="text-base font-mono text-emerald-400">{(droughtM.precision * 100).toFixed(1)}%</strong>
              </div>
              <div className="p-2.5 rounded-xl bg-navy-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-semibold">ROC-AUC</span>
                <strong className="text-base font-mono text-amber-400">{droughtM.roc_auc}</strong>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] text-slate-300 leading-relaxed">
              <strong className="text-amber-300 block mb-1">Precision & Agronomic Rationale:</strong>
              High precision ensures agricultural drought notifications and SDRF relief disbursements trigger accurately without prematurely exhausting contingent regional relief funds.
            </div>
          </div>
        </div>
      </section>

      {/* System Architecture Section */}
      <section className="glass-panel p-8 rounded-2xl border border-slate-700/50 space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-700/60">
          <Layers className="w-5 h-5 text-cyan-400" />
          <h2 className="text-lg font-bold text-white">Full-Stack Architecture & Data Pipeline</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-400">
              Layer 1: Ingestion
            </span>
            <h4 className="font-bold text-slate-200">Meteorological Telemetry</h4>
            <p className="text-slate-400 leading-relaxed">
              Open-Meteo Weather API stream + CWC basin historical averages across 22 Indian high-vulnerability hotspots.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-400">
              Layer 2: Inference
            </span>
            <h4 className="font-bold text-slate-200">Python ML Backend</h4>
            <p className="text-slate-400 leading-relaxed">
              FastAPI asynchronous gateway hosting Scikit-learn Random Forest and Gradient Boosting ensembles.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-400">
              Layer 3: Explainability
            </span>
            <h4 className="font-bold text-slate-200">XAI Attribution Engine</h4>
            <p className="text-slate-400 leading-relaxed">
              TreeSHAP / Gini feature weights + plain-English attribution engine generating zero contradictory explanations.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-navy-900/70 border border-slate-800 space-y-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-cyan-400">
              Layer 4: Delivery
            </span>
            <h4 className="font-bold text-slate-200">Resilience Interface</h4>
            <p className="text-slate-400 leading-relaxed">
              React 18 + Vite + Leaflet geospatial layers delivering actionable protocols for Farmers, Residents, and DDMA.
            </p>
          </div>
        </div>
      </section>

      {/* Responsible AI & Scientific Honesty Statement */}
      <section className="glass-panel p-8 rounded-2xl border border-cyan-500/30 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
          <h2 className="text-lg font-bold text-white">Responsible AI & Dataset Governance Statement</h2>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <p>
            <strong>Transparent Data Provenance:</strong> The training benchmark dataset utilized by AquaSentinel AI is synthesized using peer-reviewed hydrological and meteorological formulas (Soil Conservation Service Curve Number runoff kinetics and Thornthwaite potential evapotranspiration).
          </p>
          <p>
            <strong>Scientific Honesty & Non-Fabrication:</strong> Evaluation metrics on this synthetic benchmark establish algorithmic stability and multi-parameter coherence. In production disaster management deployments, models must be re-calibrated on localized ground telemetry from the India Meteorological Department (IMD) and Central Water Commission (CWC).
          </p>
          <p>
            <strong>Advisory Scope:</strong> AquaSentinel AI early warnings serve strictly as decision-support intelligence. Mandatory evacuation commands, siren activations, and emergency declarations are exclusively administered by State and District Disaster Management Authorities.
          </p>
        </div>
      </section>

      {/* Technology Stack & AI Mentorship */}
      <section className="glass-panel p-6 rounded-2xl border border-slate-700/50 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
        <div>
          <span className="font-bold text-slate-200 block mb-1">Core Technology Stack:</span>
          <span className="text-cyan-400 font-mono">Python 3.10 • FastAPI • Scikit-learn • Pandas • NumPy • React 18 • TypeScript • Vite • Leaflet • Tailwind CSS • Recharts</span>
        </div>

        <div>
          <span className="font-bold text-slate-200 block mb-1">AI Tools Used:</span>
          <span className="text-emerald-400 font-mono">Google Antigravity Agentic Platform & DeepMind Advanced Agentic Coding</span>
        </div>
      </section>
    </div>
  );
};

