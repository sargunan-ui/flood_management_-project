import { BENCHMARK_DISTRICTS, BENCHMARK_SUMMARY, BENCHMARK_ALERTS, BENCHMARK_RIVERS } from '../data/benchmarkData';
import axios from 'axios';
import {
  DashboardSummary,
  DistrictProfile,
  AlertItem,
  FloodPredictionResponse,
  DroughtPredictionResponse,
  HistoricalTimelineData,
  ComparisonData,
  LiveWeatherData,
  RiverStation,
  AuthResponse,
  User,
  SystemStatusData
} from '../types';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api';

const client = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

// Attach authorization header automatically if token exists in localStorage
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('aquasentinel_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const api = {
  // Authentication & Users
  async login(credentials: { email: string; password: string }): Promise<AuthResponse> {
    const res = await client.post('/auth/login', credentials);
    if (res.data?.token) {
      localStorage.setItem('aquasentinel_token', res.data.token);
      localStorage.setItem('aquasentinel_user', JSON.stringify(res.data.user));
    }
    return res.data;
  },

  async register(userData: {
    name: string;
    email: string;
    password: string;
    role: string;
    organization?: string;
    location?: string;
    id_proof_type?: string;
    id_proof_number?: string;
  }): Promise<AuthResponse> {
    const res = await client.post('/auth/register', userData);
    if (res.data?.token) {
      localStorage.setItem('aquasentinel_token', res.data.token);
      localStorage.setItem('aquasentinel_user', JSON.stringify(res.data.user));
    }
    return res.data;
  },

  async getCurrentUser(): Promise<User> {
    const res = await client.get('/auth/me');
    return res.data;
  },

  async getAdminUsers(): Promise<User[]> {
    const res = await client.get('/admin/users');
    return res.data;
  },

  async getAdminSystemStatus(): Promise<SystemStatusData> {
    const res = await client.get('/admin/system-status');
    return res.data;
  },

  logout() {
    localStorage.removeItem('aquasentinel_token');
    localStorage.removeItem('aquasentinel_user');
  },

  // Geospatial Map GeoJSON Endpoints
  async getMapFlood() {
    const res = await client.get('/map/flood');
    return res.data;
  },

  async getMapDrought() {
    const res = await client.get('/map/drought');
    return res.data;
  },

  async getMapRiversGeoJson() {
    const res = await client.get('/map/rivers-geojson');
    return res.data;
  },

  async getMapCombined() {
    const res = await client.get('/map/combined');
    return res.data;
  },

  // Conversational AI (Aqua AI)
  async chatWithAquaAI(payload: {
    message: string;
    history?: Array<{ sender: string; text: string }>;
    context?: any;
  }) {
    const res = await client.post('/chat', payload);
    return res.data;
  },

  // Safety Guides & Location Risk
  async getSafetyGuide() {
    const res = await client.get('/safety-guide');
    return res.data;
  },

  async getLocationRisk(districtId: string) {
    const res = await client.get('/location-risk', { params: { district_id: districtId } });
    return res.data;
  },

  // Core System Telemetry
  async getHealth() {
    const res = await client.get('/health');
    return res.data;
  },

  async getDashboard(): Promise<DashboardSummary> {
    try {
      const res = await client.get('/dashboard');
      return res.data;
    } catch {
      return BENCHMARK_SUMMARY;
    }
  },

  async getDistricts(): Promise<DistrictProfile[]> {
    try {
      const res = await client.get('/locations');
      return res.data;
    } catch {
      return BENCHMARK_DISTRICTS;
    }
  },

  async getDistrictById(id: string): Promise<DistrictProfile> {
    const res = await client.get(`/locations/${id}`);
    return res.data;
  },

  async getRiskMap(hazard?: string) {
    const res = await client.get('/risk-map', { params: { hazard_type: hazard } });
    return res.data;
  },

  async getAlerts(status?: string, hazard?: string): Promise<AlertItem[]> {
    try {
      const res = await client.get('/alerts', { params: { status, hazard_type: hazard } });
      return res.data;
    } catch {
      return BENCHMARK_ALERTS;
    }
  },

  async acknowledgeAlert(alertId: string, operatorName: string = 'District Disaster Officer'): Promise<AlertItem> {
    const res = await client.post(`/alerts/${alertId}/acknowledge`, { operator_name: operatorName });
    return res.data;
  },

  async generateAlert(payload: Partial<AlertItem>): Promise<AlertItem> {
    const res = await client.post('/alerts/generate', payload);
    return res.data;
  },

  async predictFlood(payload: any): Promise<FloodPredictionResponse> {
    const res = await client.post('/predict/flood', payload);
    return res.data;
  },

  async predictDrought(payload: any): Promise<DroughtPredictionResponse> {
    const res = await client.post('/predict/drought', payload);
    return res.data;
  },

  async getHistory(districtId: string): Promise<HistoricalTimelineData> {
    const res = await client.get('/history', { params: { district_id: districtId } });
    return res.data;
  },

  async compareDistricts(loc1: string, loc2: string): Promise<ComparisonData> {
    const res = await client.get('/compare', { params: { loc1, loc2 } });
    return res.data;
  },

  async getLiveWeather(lat: number, lon: number): Promise<LiveWeatherData> {
    const res = await client.get('/live-weather', { params: { lat, lon } });
    return res.data;
  },

  async getRivers(): Promise<RiverStation[]> {
    try {
      const res = await client.get('/rivers');
      return res.data;
    } catch {
      return BENCHMARK_RIVERS;
    }
  },

  async getModelMetadata() {
    const res = await client.get('/model-metadata');
    return res.data;
  }
};
