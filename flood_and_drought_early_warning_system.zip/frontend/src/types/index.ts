export type RiskCategory = 'Low' | 'Moderate' | 'High' | 'Severe' | 'Critical';
export type PrimaryHazard = 'Flood' | 'Drought' | 'Dual';

export interface FactorContribution {
  feature: string;
  feature_label: string;
  value: any;
  importance: number;
  impact: 'increases_risk' | 'decreases_risk';
  explanation: string;
}

export interface PersonaRecommendations {
  farmers: string[];
  residents: string[];
  authorities: string[];
}

export interface FloodPredictionResponse {
  prediction_id: string;
  location_name: string;
  flood_probability: number;
  risk_score: number;
  risk_category: RiskCategory;
  confidence_level: string;
  contributing_factors: FactorContribution[];
  plain_english_explanation: string[];
  recommendations: PersonaRecommendations;
  timestamp: string;
  is_demo: boolean;
}

export interface DroughtPredictionResponse {
  prediction_id: string;
  location_name: string;
  drought_probability: number;
  severity_score: number;
  drought_category: RiskCategory;
  confidence_level: string;
  contributing_factors: FactorContribution[];
  plain_english_explanation: string[];
  agricultural_recommendations: PersonaRecommendations;
  timestamp: string;
  is_demo: boolean;
}

export interface DistrictProfile {
  id: string;
  name: string;
  state: string;
  latitude: number;
  longitude: number;
  elevation: number;
  primary_hazard: PrimaryHazard;
  flood_risk_score: number;
  flood_category: RiskCategory;
  drought_risk_score: number;
  drought_category: RiskCategory;
  river_basin?: string;
  soil_type?: string;
  vulnerability_index: number;
  key_metrics: {
    avg_monsoon_rainfall_mm?: number;
    river_gauge_m?: number;
    soil_moisture_pct?: number;
    vegetation_condition_index?: number;
    consecutive_dry_days?: number;
    critical_warning?: string;
  };
}

export interface AlertItem {
  id: string;
  location: string;
  state: string;
  hazard_type: string;
  risk_level: RiskCategory;
  timestamp: string;
  title: string;
  description: string;
  recommended_action: string;
  status: 'Active' | 'Acknowledged' | 'Resolved';
  coordinates: [number, number];
  acknowledged_by?: string | null;
  acknowledged_at?: string | null;
}

export interface DashboardSummary {
  current_flood_risk_avg: number;
  current_drought_risk_avg: number;
  total_monitored_locations: number;
  high_risk_flood_count: number;
  high_risk_drought_count: number;
  active_alerts_count: number;
  immediate_attention_locations: Array<{
    id: string;
    name: string;
    state: string;
    primary_hazard: string;
    risk_score: number;
    category: RiskCategory;
    alert: string;
  }>;
  rainfall_summary: {
    national_trend: string;
    highest_rainfall_point: string;
    highest_deficit_point: string;
  };
  soil_moisture_summary: {
    saturated_hotspots: string[];
    parched_hotspots: string[];
  };
  recent_alerts: AlertItem[];
  risk_distribution: Record<string, number>;
}

export interface LiveWeatherData {
  source: string;
  latitude: number;
  longitude: number;
  temperature: number;
  relative_humidity: number;
  rainfall_intensity: number;
  rainfall_24h: number;
  rainfall_7d: number;
  soil_moisture: number;
  wind_speed: number;
  is_live: boolean;
}

export interface HistoricalTimelineData {
  district_id: string;
  timeline: Array<{
    month: string;
    rainfall_mm: number;
    soil_moisture_pct: number;
    temperature_c: number;
    vegetation_index: number;
    flood_risk_score: number;
    drought_risk_score: number;
  }>;
  historical_extreme_events: Array<{
    year: number;
    event: string;
    peak_risk_score: number;
    affected_population: string;
    loss_mitigated: string;
  }>;
}

export interface ComparisonData {
  district_1: DistrictProfile;
  district_2: DistrictProfile;
  comparison_highlights: Array<{
    metric: string;
    val1: any;
    val2: any;
    difference?: string;
  }>;
}

export interface RiverStation {
  id: string;
  river_name: string;
  station_name: string;
  state: string;
  water_level_m: number;
  warning_level_m: number;
  danger_level_m: number;
  discharge_cusecs?: number;
  status: 'Normal' | 'Rising' | 'High' | 'Critical';
  trend: 'Rising' | 'Steady' | 'Falling';
  simple_status: string;
  last_updated: string;
  is_demo: boolean;
}



export type UserRole = 'Citizen' | 'Farmer' | 'Disaster Management Official' | 'Administrator';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  organization?: string;
  location?: string;
  id_proof_type?: string;
  id_proof_number?: string;
  created_at?: string;
  status?: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  is_live_llm?: boolean;
  engine?: string;
  notice?: string;
}

export interface SystemStatusData {
  status: string;
  active_users: number;
  monitored_districts: number;
  active_river_stations: number;
  ml_inference_engine: string;
  open_meteo_live_telemetry: string;
  gemini_api_status: string;
  openai_api_status: string;
  last_system_health_check: string;
}

export interface RiverGeometry {
  id: string;
  name: string;
  origin: string;
  length_km: number;
  basin_area_sq_km: number;
  current_status: string;
  discharge_cusecs: number;
  is_demo: boolean;
  color: string;
  coordinates: [number, number][]; // [lon, lat]
}
