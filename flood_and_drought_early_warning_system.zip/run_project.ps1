# AquaSentinel AI - Full Stack Launcher Script (PowerShell)
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "   Starting AquaSentinel AI Early Warning Platform       " -ForegroundColor White
Write-Host "==========================================================" -ForegroundColor Cyan

# Detect Python interpreter (venv if present, otherwise system python)
$pythonPath = "python"
if (Test-Path "backend\.venv\Scripts\python.exe") {
    $pythonPath = "backend\.venv\Scripts\python.exe"
} elseif (Test-Path ".venv\Scripts\python.exe") {
    $pythonPath = ".venv\Scripts\python.exe"
}

# 1. Start FastAPI Backend
Write-Host "[1/2] Launching Python FastAPI Backend on port 8000..." -ForegroundColor Green
$backendProcess = Start-Process -FilePath $pythonPath -ArgumentList "-m", "uvicorn", "backend.app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload" -PassThru

Start-Sleep -Seconds 2

# 2. Start Frontend Dev Server
Write-Host "[2/2] Launching Vite React Frontend on port 5173..." -ForegroundColor Green
Set-Location frontend
npm run dev
