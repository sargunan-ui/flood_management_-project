import pytest
from backend.app.api.endpoints import (
    get_health,
    get_dashboard_summary,
    list_locations,
    get_risk_map_data,
    get_alerts,
    acknowledge_alert,
    compare_districts,
    predict_flood,
    predict_drought,
    get_history,
    get_rivers
)
from backend.app.schemas.models import FloodPredictionRequest, DroughtPredictionRequest

def test_health_endpoint():
    data = get_health()
    assert data["status"] == "healthy"
    assert data["system"] == "AquaSentinel AI"
    assert data["models"]["flood_model_loaded"] is True
    assert data["models"]["drought_model_loaded"] is True
    assert data["geospatial_locations_count"] >= 20

def test_dashboard_endpoint():
    data = get_dashboard_summary()
    assert data.current_flood_risk_avg > 0
    assert data.current_drought_risk_avg > 0
    assert data.total_monitored_locations >= 20
    assert len(data.recent_alerts) > 0
    assert len(data.immediate_attention_locations) > 0

def test_locations_and_map_endpoints():
    locs = list_locations()
    assert len(locs) >= 20
    assert any(d["name"] == "Dhemaji" for d in locs)
    assert any(d["name"] == "Barmer" for d in locs)

    map_data = get_risk_map_data()
    assert "markers" in map_data
    assert "legend" in map_data
    assert len(map_data["markers"]) >= 20

def test_alerts_and_acknowledge():
    alerts = get_alerts()
    assert len(alerts) > 0
    first_id = alerts[0]["id"]

    ack = acknowledge_alert(first_id, "Chief Disaster Response Officer")
    assert ack["status"] == "Acknowledged"
    assert ack["acknowledged_by"] == "Chief Disaster Response Officer"
    assert ack["acknowledged_at"] is not None

def test_compare_endpoint():
    data = compare_districts("assam_dhemaji", "rajasthan_barmer")
    assert "district_1" in data
    assert "district_2" in data
    assert data["district_1"]["name"] == "Dhemaji"
    assert data["district_2"]["name"] == "Barmer"
    assert len(data["comparison_highlights"]) >= 4

def test_history_endpoint():
    data = get_history("assam_dhemaji")
    assert "timeline" in data
    assert len(data["timeline"]) == 12
    assert len(data["historical_extreme_events"]) > 0

def test_rivers_endpoint():
    rivers = get_rivers()
    assert len(rivers) >= 10
    assert any(r["river_name"] == "Brahmaputra" for r in rivers)
    assert any(r["river_name"] == "Ganga (Ganges)" for r in rivers)
    assert "water_level_m" in rivers[0]
    assert "status" in rivers[0]

def test_api_predict_endpoints():
    fld_req = FloodPredictionRequest(
        location_name="Assam Plains",
        rainfall_intensity=35.0,
        rainfall_24h=140.0,
        rainfall_7d=320.0,
        river_water_level=15.0,
        soil_moisture=88.0,
        temperature=27.0,
        elevation=35.0,
        drainage_condition=0,
        historical_flood_occurrence=4
    )
    fld_res = predict_flood(fld_req)
    assert fld_res.risk_score >= 50.0
    assert fld_res.risk_category in ["High", "Severe", "Critical"]

    drt_req = DroughtPredictionRequest(
        location_name="Bundelkhand Plateau",
        rainfall_deficit=75.0,
        temperature=41.0,
        soil_moisture=12.0,
        relative_humidity=22.0,
        vegetation_condition=20.0,
        historical_rainfall=500.0,
        consecutive_dry_days=60
    )
    drt_res = predict_drought(drt_req)
    assert drt_res.severity_score > 70.0
    assert drt_res.drought_category in ["High", "Severe", "Critical"]

from backend.app.api.endpoints import (
    register,
    login,
    get_current_user,
    get_admin_users,
    get_admin_system_status,
    get_map_flood,
    get_map_drought,
    get_map_rivers,
    get_map_combined,
    chat_with_aqua_ai,
    get_safety_guide,
    get_location_risk
)
from backend.app.schemas.models import RegisterRequest, LoginRequest, ChatRequest

def test_auth_system():
    # 1. Login with pre-seeded demo Citizen account
    login_req = LoginRequest(email="citizen@aquasentinel.org", password="citizen123")
    res = login(login_req)
    assert "token" in res
    assert res["user"]["role"] == "Citizen"
    token = res["token"]

    # 2. Check /api/auth/me
    me = get_current_user(authorization=f"Bearer {token}")
    assert me["email"] == "citizen@aquasentinel.org"

    # 3. Register a new Farmer account
    reg_req = RegisterRequest(
        name="Harish Verma",
        email="harish.verma@testkisan.in",
        password="securePassword123",
        role="Farmer",
        organization="Punjab Farmers Union",
        location="Ludhiana, Punjab"
    )
    reg_res = register(reg_req)
    assert reg_res["user"]["name"] == "Harish Verma"
    assert reg_res["user"]["role"] == "Farmer"

    # 4. Verify login with newly created account
    new_login = login(LoginRequest(email="harish.verma@testkisan.in", password="securePassword123"))
    assert new_login["user"]["email"] == "harish.verma@testkisan.in"

def test_admin_endpoints():
    # Login as admin
    admin_login = login(LoginRequest(email="admin@aquasentinel.org", password="admin123"))
    admin_token = admin_login["token"]

    # Get users list
    users = get_admin_users(authorization=f"Bearer {admin_token}")
    assert len(users) >= 4
    assert any(u["role"] == "Administrator" for u in users)

    # Get system status
    status = get_admin_system_status(authorization=f"Bearer {admin_token}")
    assert status["status"] == "Operational"
    assert status["active_river_stations"] == 12

def test_map_geojson_endpoints():
    flood_geojson = get_map_flood()
    assert flood_geojson["type"] == "FeatureCollection"
    assert len(flood_geojson["features"]) >= 20
    assert "geometry" in flood_geojson["features"][0]
    assert flood_geojson["features"][0]["geometry"]["type"] == "Polygon"

    drought_geojson = get_map_drought()
    assert drought_geojson["type"] == "FeatureCollection"
    assert len(drought_geojson["features"]) >= 20

    rivers_geojson = get_map_rivers()
    assert rivers_geojson["type"] == "FeatureCollection"
    assert len(rivers_geojson["features"]) == 9
    assert any(f["properties"]["name"].startswith("Ganga") for f in rivers_geojson["features"])
    assert any(f["properties"]["name"].startswith("Brahmaputra") for f in rivers_geojson["features"])

    combined_geojson = get_map_combined()
    assert len(combined_geojson["features"]) >= 20

def test_aqua_ai_chat():
    chat_req = ChatRequest(
        message="What should I do during a flood?",
        context={
            "district_name": "Dhemaji",
            "state": "Assam",
            "flood_risk_score": 88.5,
            "flood_category": "Severe",
            "rainfall_24h": 142.0,
            "river_level": 16.8
        }
    )
    res = chat_with_aqua_ai(chat_req)
    assert "reply" in res
    assert len(res["reply"]) > 50
    assert "higher ground" in res["reply"].lower() or "safe" in res["reply"].lower()

def test_safety_guide_and_location_risk():
    guide = get_safety_guide()
    assert "flood" in guide
    assert "drought" in guide
    assert len(guide["flood"]["before"]) >= 7
    assert len(guide["flood"]["during"]) >= 7
    assert len(guide["flood"]["after"]) >= 6
    assert "emergency_contacts" in guide
    assert guide["emergency_contacts"]["national_emergency"] == "112"

    loc_risk = get_location_risk("assam_dhemaji")
    assert loc_risk["name"] == "Dhemaji"
    assert loc_risk["risk_score"] > 80
    assert len(loc_risk["recommended_actions"]) >= 4
