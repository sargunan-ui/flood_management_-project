import pytest
from backend.app.schemas.models import FloodPredictionRequest, DroughtPredictionRequest
from backend.app.ml.flood_predictor import flood_predictor_instance
from backend.app.ml.drought_predictor import drought_predictor_instance

def test_flood_prediction_high_risk():
    req = FloodPredictionRequest(
        location_name="Assam River Basin",
        rainfall_intensity=45.0,
        rainfall_24h=190.0,
        rainfall_7d=480.0,
        river_water_level=18.5,
        soil_moisture=92.0,
        temperature=28.0,
        elevation=25.0,
        drainage_condition=0,
        historical_flood_occurrence=6
    )
    res = flood_predictor_instance.predict(req)
    assert res.risk_score >= 70.0
    assert res.risk_category in ["High", "Severe", "Critical"]
    assert res.flood_probability > 0.70
    assert len(res.contributing_factors) > 0
    assert len(res.plain_english_explanation) > 0
    assert len(res.recommendations.farmers) > 0
    assert len(res.recommendations.residents) > 0
    assert len(res.recommendations.authorities) > 0

def test_flood_prediction_low_risk():
    req = FloodPredictionRequest(
        location_name="High Plateau",
        rainfall_intensity=2.0,
        rainfall_24h=5.0,
        rainfall_7d=15.0,
        river_water_level=2.0,
        soil_moisture=30.0,
        temperature=26.0,
        elevation=650.0,
        drainage_condition=2,
        historical_flood_occurrence=0
    )
    res = flood_predictor_instance.predict(req)
    assert res.risk_score < 40.0
    assert res.risk_category in ["Low", "Moderate"]
    assert res.flood_probability < 0.40

def test_drought_prediction_critical():
    req = DroughtPredictionRequest(
        location_name="Arid Thar Region",
        rainfall_deficit=85.0,
        temperature=44.0,
        soil_moisture=8.0,
        relative_humidity=18.0,
        vegetation_condition=12.0,
        historical_rainfall=250.0,
        consecutive_dry_days=80
    )
    res = drought_predictor_instance.predict(req)
    assert res.severity_score >= 75.0
    assert res.drought_category in ["Severe", "Critical"]
    assert res.drought_probability > 0.80
    assert len(res.contributing_factors) > 0
    assert len(res.plain_english_explanation) > 0
    assert len(res.agricultural_recommendations.farmers) > 0

def test_drought_prediction_normal():
    req = DroughtPredictionRequest(
        location_name="Humid Coastal Delta",
        rainfall_deficit=5.0,
        temperature=27.0,
        soil_moisture=75.0,
        relative_humidity=80.0,
        vegetation_condition=82.0,
        historical_rainfall=1400.0,
        consecutive_dry_days=2
    )
    res = drought_predictor_instance.predict(req)
    assert res.severity_score < 35.0
    assert res.drought_category in ["Low", "Moderate"]

