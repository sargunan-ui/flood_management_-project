"""
AquaSentinel AI - Indian Vulnerable Districts Registry
Contains baseline geospatial, hydrological, and vulnerability coordinates
for high-priority flood and drought hotspots across India.
"""

from typing import List, Dict, Any

INDIAN_DISTRICTS: List[Dict[str, Any]] = [
    # --- FLOOD HOTSPOTS ---
    {
        "id": "assam_dhemaji",
        "name": "Dhemaji",
        "state": "Assam",
        "latitude": 27.48,
        "longitude": 94.58,
        "elevation": 104.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 88.5,
        "flood_category": "Severe",
        "drought_risk_score": 12.0,
        "drought_category": "Low",
        "river_basin": "Brahmaputra / Subansiri",
        "soil_type": "Alluvial Silt Loam",
        "vulnerability_index": 0.89,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 2800,
            "river_gauge_m": 16.8,
            "soil_moisture_pct": 89.2,
            "critical_warning": "Subansiri embankment vulnerable to overtopping"
        }
    },
    {
        "id": "assam_cachar",
        "name": "Cachar (Silchar)",
        "state": "Assam",
        "latitude": 24.83,
        "longitude": 92.80,
        "elevation": 26.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 84.0,
        "flood_category": "Severe",
        "drought_risk_score": 15.0,
        "drought_category": "Low",
        "river_basin": "Barak Valley",
        "soil_type": "Clayey Alluvial",
        "vulnerability_index": 0.86,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 3100,
            "river_gauge_m": 21.2,
            "soil_moisture_pct": 91.0,
            "critical_warning": "Betkundi dyke breach history; low lying urban waterlogging"
        }
    },
    {
        "id": "bihar_darbhanga",
        "name": "Darbhanga",
        "state": "Bihar",
        "latitude": 26.15,
        "longitude": 85.90,
        "elevation": 52.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 91.2,
        "flood_category": "Critical",
        "drought_risk_score": 18.0,
        "drought_category": "Low",
        "river_basin": "Bagmati / Kamla Balan / Kosi",
        "soil_type": "Calcareous Alluvial",
        "vulnerability_index": 0.93,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1150,
            "river_gauge_m": 13.4,
            "soil_moisture_pct": 86.5,
            "critical_warning": "Flash surging from Nepal foothills catchments"
        }
    },
    {
        "id": "bihar_patna",
        "name": "Patna",
        "state": "Bihar",
        "latitude": 25.61,
        "longitude": 85.14,
        "elevation": 53.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 76.5,
        "flood_category": "Severe",
        "drought_risk_score": 24.0,
        "drought_category": "Low",
        "river_basin": "Ganga / Punpun / Son",
        "soil_type": "Older Alluvium",
        "vulnerability_index": 0.78,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1050,
            "river_gauge_m": 50.1,
            "soil_moisture_pct": 78.4,
            "critical_warning": "Punpun backwaters backflow during high Ganges crest"
        }
    },
    {
        "id": "kerala_wayanad",
        "name": "Wayanad",
        "state": "Kerala",
        "latitude": 11.68,
        "longitude": 76.13,
        "elevation": 750.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 82.0,
        "flood_category": "Severe",
        "drought_risk_score": 14.0,
        "drought_category": "Low",
        "river_basin": "Kabini / Chaliyar",
        "soil_type": "Laterite Loam (High Slope)",
        "vulnerability_index": 0.88,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 3500,
            "river_gauge_m": 8.5,
            "soil_moisture_pct": 94.0,
            "critical_warning": "Slope saturation trigger for debris flow and river surge"
        }
    },
    {
        "id": "kerala_alappuzha",
        "name": "Alappuzha (Kuttanad)",
        "state": "Kerala",
        "latitude": 9.50,
        "longitude": 76.33,
        "elevation": -1.5,
        "primary_hazard": "Flood",
        "flood_risk_score": 89.0,
        "flood_category": "Severe",
        "drought_risk_score": 10.0,
        "drought_category": "Low",
        "river_basin": "Pamba / Achankovil / Vembanad",
        "soil_type": "Peat / Acid Coastal Alluvial",
        "vulnerability_index": 0.91,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 2900,
            "river_gauge_m": 3.8,
            "soil_moisture_pct": 98.0,
            "critical_warning": "Below sea level paddy basin; dependent on Thanneermukkom barrage release"
        }
    },
    {
        "id": "maharashtra_kolhapur",
        "name": "Kolhapur",
        "state": "Maharashtra",
        "latitude": 16.70,
        "longitude": 74.24,
        "elevation": 569.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 79.0,
        "flood_category": "Severe",
        "drought_risk_score": 28.0,
        "drought_category": "Moderate",
        "river_basin": "Panchganga / Krishna",
        "soil_type": "Black Cotton / Deep Clay",
        "vulnerability_index": 0.79,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1850,
            "river_gauge_m": 43.5,
            "soil_moisture_pct": 84.0,
            "critical_warning": "Backwater effect from Almatti dam discharge bottlenecks"
        }
    },
    {
        "id": "maharashtra_mumbai",
        "name": "Mumbai Suburban",
        "state": "Maharashtra",
        "latitude": 19.07,
        "longitude": 72.87,
        "elevation": 14.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 83.5,
        "flood_category": "Severe",
        "drought_risk_score": 8.0,
        "drought_category": "Low",
        "river_basin": "Mithi River / Arabian Sea",
        "soil_type": "Urban Coastal Fill / Clay",
        "vulnerability_index": 0.85,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 2400,
            "river_gauge_m": 4.2,
            "soil_moisture_pct": 88.0,
            "critical_warning": "High tide storm surge concurrent with >100mm cloudburst"
        }
    },
    {
        "id": "odisha_puri",
        "name": "Puri",
        "state": "Odisha",
        "latitude": 19.81,
        "longitude": 85.83,
        "elevation": 8.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 74.0,
        "flood_category": "High",
        "drought_risk_score": 25.0,
        "drought_category": "Moderate",
        "river_basin": "Mahanadi Delta / Daya / Bhargavi",
        "soil_type": "Coastal Saline Alluvial",
        "vulnerability_index": 0.75,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1450,
            "river_gauge_m": 9.2,
            "soil_moisture_pct": 82.0,
            "critical_warning": "Bay of Bengal cyclone storm surges combined with Hirakud peak releases"
        }
    },
    {
        "id": "up_gorakhpur",
        "name": "Gorakhpur",
        "state": "Uttar Pradesh",
        "latitude": 26.76,
        "longitude": 83.37,
        "elevation": 84.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 77.0,
        "flood_category": "Severe",
        "drought_risk_score": 22.0,
        "drought_category": "Low",
        "river_basin": "Rapti / Rohini",
        "soil_type": "Gangetic Alluvium",
        "vulnerability_index": 0.76,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1280,
            "river_gauge_m": 75.1,
            "soil_moisture_pct": 81.0,
            "critical_warning": "Rapti River breaches vulnerable embankments during Terai downpours"
        }
    },
    {
        "id": "wb_murshidabad",
        "name": "Murshidabad",
        "state": "West Bengal",
        "latitude": 24.18,
        "longitude": 88.27,
        "elevation": 19.0,
        "primary_hazard": "Flood",
        "flood_risk_score": 73.0,
        "flood_category": "High",
        "drought_risk_score": 29.0,
        "drought_category": "Moderate",
        "river_basin": "Bhagirathi / Padma / Jalangi",
        "soil_type": "Newer Alluvium (Entisols)",
        "vulnerability_index": 0.72,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 1380,
            "river_gauge_m": 12.8,
            "soil_moisture_pct": 80.0,
            "critical_warning": "Riverbank erosion and transboundary high water flow"
        }
    },

    # --- DROUGHT HOTSPOTS ---
    {
        "id": "rajasthan_barmer",
        "name": "Barmer",
        "state": "Rajasthan",
        "latitude": 25.75,
        "longitude": 71.39,
        "elevation": 182.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 22.0,
        "flood_category": "Low",
        "drought_risk_score": 93.5,
        "drought_category": "Critical",
        "river_basin": "Luni Basin (Ephemeral)",
        "soil_type": "Desert / Aridisol Sand",
        "vulnerability_index": 0.94,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 270,
            "soil_moisture_pct": 9.5,
            "vegetation_condition_index": 18.0,
            "consecutive_dry_days": 82,
            "critical_warning": "Sub-surface salinity and severe pastoral fodder depletion"
        }
    },
    {
        "id": "rajasthan_jaisalmer",
        "name": "Jaisalmer",
        "state": "Rajasthan",
        "latitude": 26.91,
        "longitude": 70.91,
        "elevation": 225.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 15.0,
        "flood_category": "Low",
        "drought_risk_score": 96.0,
        "drought_category": "Critical",
        "river_basin": "Internal Thar Drainage",
        "soil_type": "Hyper-Arid Dune Sand",
        "vulnerability_index": 0.97,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 160,
            "soil_moisture_pct": 6.8,
            "vegetation_condition_index": 12.0,
            "consecutive_dry_days": 105,
            "critical_warning": "Extreme groundwater depletion; reliance on Indira Gandhi Canal feeder"
        }
    },
    {
        "id": "maharashtra_latur",
        "name": "Latur",
        "state": "Maharashtra",
        "latitude": 18.40,
        "longitude": 76.58,
        "elevation": 631.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 28.0,
        "flood_category": "Moderate",
        "drought_risk_score": 86.5,
        "drought_category": "Severe",
        "river_basin": "Manjara / Godavari Basin",
        "soil_type": "Deep Black Regur Soil",
        "vulnerability_index": 0.87,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 740,
            "soil_moisture_pct": 18.5,
            "vegetation_condition_index": 26.0,
            "consecutive_dry_days": 54,
            "critical_warning": "Soybean and pulse vegetative wilting; Manjara reservoir storage < 12%"
        }
    },
    {
        "id": "maharashtra_dharashiv",
        "name": "Dharashiv (Osmanabad)",
        "state": "Maharashtra",
        "latitude": 18.18,
        "longitude": 76.04,
        "elevation": 653.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 24.0,
        "flood_category": "Low",
        "drought_risk_score": 85.0,
        "drought_category": "Severe",
        "river_basin": "Sina / Bhima / Godavari",
        "soil_type": "Medium Shallow Black Soil",
        "vulnerability_index": 0.85,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 680,
            "soil_moisture_pct": 19.0,
            "vegetation_condition_index": 28.0,
            "consecutive_dry_days": 50,
            "critical_warning": "Rain shadow region; severely stressed rabi sowing prospects"
        }
    },
    {
        "id": "ap_anantapur",
        "name": "Anantapur",
        "state": "Andhra Pradesh",
        "latitude": 14.68,
        "longitude": 77.60,
        "elevation": 335.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 19.0,
        "flood_category": "Low",
        "drought_risk_score": 90.0,
        "drought_category": "Critical",
        "river_basin": "Pennar Basin",
        "soil_type": "Red Sandy Loam",
        "vulnerability_index": 0.92,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 550,
            "soil_moisture_pct": 12.0,
            "vegetation_condition_index": 21.0,
            "consecutive_dry_days": 68,
            "critical_warning": "Second lowest rainfall district in India; groundnut crop pod-formation failure"
        }
    },
    {
        "id": "karnataka_kalaburagi",
        "name": "Kalaburagi (Gulbarga)",
        "state": "Karnataka",
        "latitude": 17.33,
        "longitude": 76.83,
        "elevation": 454.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 30.0,
        "flood_category": "Moderate",
        "drought_risk_score": 84.5,
        "drought_category": "Severe",
        "river_basin": "Bhima / Krishna",
        "soil_type": "Deep Black Clay",
        "vulnerability_index": 0.84,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 750,
            "soil_moisture_pct": 17.2,
            "vegetation_condition_index": 29.0,
            "consecutive_dry_days": 46,
            "critical_warning": "Red gram (Tur) pulse distress; borewell depths exceeding 500ft"
        }
    },
    {
        "id": "karnataka_kolar",
        "name": "Kolar",
        "state": "Karnataka",
        "latitude": 13.13,
        "longitude": 78.13,
        "elevation": 822.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 18.0,
        "flood_category": "Low",
        "drought_risk_score": 81.0,
        "drought_category": "Severe",
        "river_basin": "Palar / Ponnaiyar",
        "soil_type": "Red Sandy Clay Loam",
        "vulnerability_index": 0.82,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 730,
            "soil_moisture_pct": 21.0,
            "vegetation_condition_index": 33.0,
            "consecutive_dry_days": 42,
            "critical_warning": "Horticultural irrigation deficit; tank cascade systems dry"
        }
    },
    {
        "id": "up_banda",
        "name": "Banda",
        "state": "Uttar Pradesh",
        "latitude": 25.48,
        "longitude": 80.33,
        "elevation": 123.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 38.0,
        "flood_category": "Moderate",
        "drought_risk_score": 87.0,
        "drought_category": "Severe",
        "river_basin": "Ken / Yamuna (Bundelkhand)",
        "soil_type": "Mixed Red & Black (Mar & Kabar)",
        "vulnerability_index": 0.88,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 890,
            "soil_moisture_pct": 16.5,
            "vegetation_condition_index": 25.0,
            "consecutive_dry_days": 58,
            "critical_warning": "Severe Bundelkhand agrarian drought; check-dams and dugwells depleted"
        }
    },
    {
        "id": "mp_tikamgarh",
        "name": "Tikamgarh",
        "state": "Madhya Pradesh",
        "latitude": 24.74,
        "longitude": 78.83,
        "elevation": 326.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 32.0,
        "flood_category": "Moderate",
        "drought_risk_score": 83.0,
        "drought_category": "Severe",
        "river_basin": "Betwa / Jamni",
        "soil_type": "Bundelkhand Granitic / Red Soil",
        "vulnerability_index": 0.83,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 850,
            "soil_moisture_pct": 19.4,
            "vegetation_condition_index": 31.0,
            "consecutive_dry_days": 47,
            "critical_warning": "Chandela tank cascade dry; livestock water availability scarce"
        }
    },
    {
        "id": "tn_ramanathapuram",
        "name": "Ramanathapuram",
        "state": "Tamil Nadu",
        "latitude": 9.36,
        "longitude": 78.83,
        "elevation": 10.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 42.0,
        "flood_category": "Moderate",
        "drought_risk_score": 82.5,
        "drought_category": "Severe",
        "river_basin": "Vaigai / Gundar",
        "soil_type": "Coastal Saline & Red Sandy",
        "vulnerability_index": 0.81,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 840,
            "soil_moisture_pct": 20.1,
            "vegetation_condition_index": 30.0,
            "consecutive_dry_days": 52,
            "critical_warning": "Rain-fed chili and paddy failure; coastal aquifer saline intrusion"
        }
    },
    {
        "id": "gujarat_kutch",
        "name": "Kutch",
        "state": "Gujarat",
        "latitude": 23.24,
        "longitude": 69.66,
        "elevation": 110.0,
        "primary_hazard": "Drought",
        "flood_risk_score": 26.0,
        "flood_category": "Moderate",
        "drought_risk_score": 89.5,
        "drought_category": "Severe",
        "river_basin": "Rann of Kutch Salt Flats",
        "soil_type": "Saline Coastal Desert",
        "vulnerability_index": 0.90,
        "key_metrics": {
            "avg_monsoon_rainfall_mm": 380,
            "soil_moisture_pct": 13.5,
            "vegetation_condition_index": 22.0,
            "consecutive_dry_days": 75,
            "critical_warning": "Banni grassland desiccation; Maldhari pastoralists migration alert"
        }
    }
]

def get_districts() -> List[Dict[str, Any]]:
    return INDIAN_DISTRICTS

def get_district_by_id(dist_id: str) -> Dict[str, Any]:
    for d in INDIAN_DISTRICTS:
        if d["id"] == dist_id or d["name"].lower() == dist_id.lower():
            return d
    return INDIAN_DISTRICTS[0]

