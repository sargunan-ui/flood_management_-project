"""
AquaSentinel AI - Authentication & Role-Based Access Control Manager
Provides secure password hashing (PBKDF2-HMAC-SHA256 with random salt),
token generation/verification, and role management for Citizen, Farmer,
Disaster Management Official, and Administrator users.
"""

import os
import hmac
import hashlib
import secrets
import json
import base64
import time
from typing import Optional, Dict, Any, List

JWT_SECRET = os.environ.get("AQUASENTINEL_JWT_SECRET", "aquasentinel-secret-key-green-planet-gp03-2026")
TOKEN_EXPIRY_SECONDS = 86400 * 7  # 7 days

def hash_password(password: str) -> tuple[str, str]:
    """Hashes a password with a fresh cryptographically secure salt using PBKDF2-HMAC-SHA256."""
    salt = secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100_000
    ).hex()
    return hashed, salt

def verify_password(password: str, hashed: str, salt: str) -> bool:
    """Verifies a password against a stored PBKDF2 hash using constant-time comparison."""
    test_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100_000
    ).hex()
    return hmac.compare_digest(test_hash, hashed)

def create_token(user_id: str, email: str, role: str) -> str:
    """Creates a signed, URL-safe authentication token with expiry."""
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "exp": int(time.time()) + TOKEN_EXPIRY_SECONDS
    }
    payload_bytes = json.dumps(payload, separators=(',', ':')).encode('utf-8')
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).decode('utf-8').rstrip('=')
    
    signature = hmac.new(
        JWT_SECRET.encode('utf-8'),
        payload_b64.encode('utf-8'),
        hashlib.sha256
    ).digest()
    sig_b64 = base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')
    
    return f"{payload_b64}.{sig_b64}"

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Verifies signature and expiration of an authentication token."""
    try:
        if not token or "." not in token:
            return None
        parts = token.split(".")
        if len(parts) != 2:
            return None
        payload_b64, sig_b64 = parts
        
        # Verify signature
        expected_sig = hmac.new(
            JWT_SECRET.encode('utf-8'),
            payload_b64.encode('utf-8'),
            hashlib.sha256
        ).digest()
        expected_sig_b64 = base64.urlsafe_b64encode(expected_sig).decode('utf-8').rstrip('=')
        
        if not hmac.compare_digest(sig_b64, expected_sig_b64):
            return None
        
        # Decode payload (add padding if needed)
        padding = 4 - (len(payload_b64) % 4)
        if padding != 4:
            payload_b64 += "=" * padding
        payload_json = base64.urlsafe_b64decode(payload_b64.encode('utf-8')).decode('utf-8')
        payload = json.loads(payload_json)
        
        # Check expiry
        if payload.get("exp", 0) < time.time():
            return None
        return payload
    except Exception:
        return None

class AuthManager:
    """In-memory user management with pre-seeded role accounts."""
    
    def __init__(self):
        self._users: Dict[str, Dict[str, Any]] = {}
        self._seed_default_users()
        
    def _seed_default_users(self):
        """Pre-seeds standard role accounts for testing and demonstration."""
        demo_accounts = [
            {
                "id": "usr_citizen_01",
                "email": "citizen@aquasentinel.org",
                "name": "Ramesh Kumar",
                "role": "Citizen",
                "password": "citizen123",
                "organization": "Local Community Resident",
                "location": "Dhemaji, Assam",
                "id_proof_type": "Aadhaar Card",
                "id_proof_number": "4812-9021-3456"
            },
            {
                "id": "usr_farmer_01",
                "email": "farmer@aquasentinel.org",
                "name": "Kishan Patel",
                "role": "Farmer",
                "password": "farmer123",
                "organization": "Kisan Cooperative Society",
                "location": "Barmer, Rajasthan",
                "id_proof_type": "Kisan Credit Card (KCC)",
                "id_proof_number": "KCC-RJ-4491"
            },
            {
                "id": "usr_official_01",
                "email": "official@aquasentinel.org",
                "name": "Dr. Neha Sharma",
                "role": "Disaster Management Official",
                "password": "official123",
                "organization": "District Disaster Management Authority (DDMA)",
                "location": "State Control Room",
                "id_proof_type": "NDMA Officer Badge ID",
                "id_proof_number": "DDMA-AS-102"
            },
            {
                "id": "usr_admin_01",
                "email": "admin@aquasentinel.org",
                "name": "Chief Admin Verma",
                "role": "Administrator",
                "password": "admin123",
                "organization": "AquaSentinel AI Command Centre",
                "location": "National Operations Hub",
                "id_proof_type": "Gov Security Clearance ID",
                "id_proof_number": "AQ-ADM-001"
            }
        ]
        
        for acc in demo_accounts:
            hashed, salt = hash_password(acc["password"])
            self._users[acc["email"].lower()] = {
                "id": acc["id"],
                "email": acc["email"].lower(),
                "name": acc["name"],
                "role": acc["role"],
                "organization": acc["organization"],
                "location": acc["location"],
                "id_proof_type": acc.get("id_proof_type", "Aadhaar Card"),
                "id_proof_number": acc.get("id_proof_number", ""),
                "password_hash": hashed,
                "salt": salt,
                "created_at": "2026-10-15T08:00:00Z",
                "status": "Active"
            }
            
    def register_user(self, name: str, email: str, password: str, role: str, organization: str = "", location: str = "", id_proof_type: str = "Aadhaar Card", id_proof_number: str = "") -> Dict[str, Any]:
        """Registers a new user after validation."""
        email_clean = email.strip().lower()
        if not email_clean or "@" not in email_clean:
            raise ValueError("Valid email address is required")
        if len(password) < 6:
            raise ValueError("Password must be at least 6 characters")
        if email_clean in self._users:
            raise ValueError("An account with this email already exists")
            
        valid_roles = ["Citizen", "Farmer", "Disaster Management Official", "Administrator"]
        if role not in valid_roles:
            raise ValueError(f"Invalid role. Choose from: {', '.join(valid_roles)}")
            
        hashed, salt = hash_password(password)
        user_id = f"usr_{secrets.token_hex(6)}"
        
        user_data = {
            "id": user_id,
            "email": email_clean,
            "name": name.strip() or "Registered User",
            "role": role,
            "organization": organization.strip() or "General Public",
            "location": location.strip() or "India",
            "id_proof_type": id_proof_type.strip() or "Aadhaar Card",
            "id_proof_number": id_proof_number.strip(),
            "password_hash": hashed,
            "salt": salt,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "status": "Active"
        }
        self._users[email_clean] = user_data
        
        token = create_token(user_id, email_clean, role)
        return {
            "token": token,
            "user": {
                "id": user_id,
                "email": email_clean,
                "name": user_data["name"],
                "role": role,
                "organization": user_data["organization"],
                "location": user_data["location"],
                "id_proof_type": user_data["id_proof_type"],
                "id_proof_number": user_data["id_proof_number"],
                "created_at": user_data["created_at"]
            }
        }
        
    def authenticate_user(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticates user credentials by Email OR Government ID Proof Number."""
        query = email.strip().lower()
        # Find by email first
        user = self._users.get(query)
        
        # If not found by email, search by id_proof_number
        if not user:
            norm_query = query.replace("-", "").replace(" ", "")
            for u in self._users.values():
                u_id_norm = u.get("id_proof_number", "").lower().replace("-", "").replace(" ", "")
                if u_id_norm and u_id_norm == norm_query:
                    user = u
                    break
                    
        if not user:
            raise ValueError("Invalid Email, ID Proof Number, or Password")
            
        if not verify_password(password, user["password_hash"], user["salt"]):
            raise ValueError("Invalid Email, ID Proof Number, or Password")
            
        token = create_token(user["id"], user["email"], user["role"])
        return {
            "token": token,
            "user": {
                "id": user["id"],
                "email": user["email"],
                "name": user["name"],
                "role": user["role"],
                "organization": user["organization"],
                "location": user["location"],
                "id_proof_type": user.get("id_proof_type", "Aadhaar Card"),
                "id_proof_number": user.get("id_proof_number", ""),
                "created_at": user["created_at"]
            }
        }
        
    def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        for u in self._users.values():
            if u["id"] == user_id:
                return {
                    "id": u["id"],
                    "email": u["email"],
                    "name": u["name"],
                    "role": u["role"],
                    "organization": u["organization"],
                    "location": u["location"],
                    "id_proof_type": u.get("id_proof_type", "Aadhaar Card"),
                    "id_proof_number": u.get("id_proof_number", ""),
                    "created_at": u["created_at"]
                }
        return None
        
    def get_all_users(self) -> List[Dict[str, Any]]:
        """Returns list of all registered users (excluding password hashes) for Admin."""
        result = []
        for u in self._users.values():
            result.append({
                "id": u["id"],
                "email": u["email"],
                "name": u["name"],
                "role": u["role"],
                "organization": u["organization"],
                "location": u["location"],
                "created_at": u["created_at"],
                "status": u["status"]
            })
        return result

auth_manager_instance = AuthManager()

