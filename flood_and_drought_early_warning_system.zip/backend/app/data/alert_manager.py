"""
AquaSentinel AI - Incident & Early Warning Alert Hub
Manages active disaster alerts, emergency broadcasts, and alert acknowledgments.
"""

import uuid
import datetime
from typing import List, Dict, Any, Optional

INITIAL_ALERTS: List[Dict[str, Any]] = [
    {
        "id": "alt_001",
        "location": "Darbhanga",
        "state": "Bihar",
        "hazard_type": "Flash Flood Risk",
        "risk_level": "Critical",
        "timestamp": "2026-11-03T07:15:00Z",
        "title": "Severe Flash Flood Warning — Kamla Balan Basin",
        "description": "Continuous cloudburst precipitation in upstream catchment (185mm / 24h) coupled with 94% soil saturation is causing rapid river surge nearing embankment crest.",
        "recommended_action": "Evacuate low-lying riverbed settlements in Ghanshyampur and Kiratpur blocks immediately. Stock emergency drinking water.",
        "status": "Active",
        "coordinates": [26.15, 85.90],
        "acknowledged_by": None,
        "acknowledged_at": None
    },
    {
        "id": "alt_002",
        "location": "Barmer",
        "state": "Rajasthan",
        "hazard_type": "Agricultural Drought",
        "risk_level": "Critical",
        "timestamp": "2026-11-03T06:30:00Z",
        "title": "Severe Agrarian Moisture Drought Warning",
        "description": "82 consecutive rainless days with 86% seasonal precipitation deficit. Topsoil moisture collapsed to 9.5%, triggering acute crop desiccation.",
        "recommended_action": "Deploy emergency GPS-tracked water tankers to pastoral habitations. Release subsidised fodder rations at panchayat points.",
        "status": "Active",
        "coordinates": [25.75, 71.39],
        "acknowledged_by": None,
        "acknowledged_at": None
    },
    {
        "id": "alt_003",
        "location": "Dhemaji",
        "state": "Assam",
        "hazard_type": "Flood Warning",
        "risk_level": "Severe",
        "timestamp": "2026-11-03T08:00:00Z",
        "title": "Subansiri River Embankment Inundation Alert",
        "description": "River level at 16.8m, exceeding danger mark by 1.2m. Jiadhal and Gainadi tributaries experiencing high discharge into farmland.",
        "recommended_action": "Move livestock and farm equipment to elevated community platforms (Chaprash). SDRF team on standby with rescue boats.",
        "status": "Active",
        "coordinates": [27.48, 94.58],
        "acknowledged_by": None,
        "acknowledged_at": None
    },
    {
        "id": "alt_004",
        "location": "Anantapur",
        "state": "Andhra Pradesh",
        "hazard_type": "Water Scarcity",
        "risk_level": "Critical",
        "timestamp": "2026-11-03T05:45:00Z",
        "title": "Groundwater Depletion & Rain-fed Pod Distress",
        "description": "68 consecutive rainless days with soil moisture at 12%. Groundwater tables declining below critical recharge thresholds.",
        "recommended_action": "Prioritize protective sprinkler irrigation for surviving horticulture; restrict industrial groundwater abstraction.",
        "status": "Active",
        "coordinates": [14.68, 77.60],
        "acknowledged_by": None,
        "acknowledged_at": None
    },
    {
        "id": "alt_005",
        "location": "Alappuzha (Kuttanad)",
        "state": "Kerala",
        "hazard_type": "Flood Warning",
        "risk_level": "Severe",
        "timestamp": "2026-11-03T07:45:00Z",
        "title": "Kuttanad Below-Sea-Level Polder Inundation",
        "description": "Pamba and Achankovil river discharge accumulating in Vembanad Lake. Thanneermukkom shutters operating at full capacity.",
        "recommended_action": "Maintain diesel dewatering pumps along polder bunds; relocate vulnerable houseboats to designated moorings.",
        "status": "Active",
        "coordinates": [9.50, 76.33],
        "acknowledged_by": None,
        "acknowledged_at": None
    },
    {
        "id": "alt_006",
        "location": "Latur",
        "state": "Maharashtra",
        "hazard_type": "Agricultural Drought",
        "risk_level": "Severe",
        "timestamp": "2026-11-03T06:00:00Z",
        "title": "Marathwada Kharif Crop Stress Notification",
        "description": "54 rainless days combined with 37°C temperatures causing rapid soybean leaf wilting. Reservoir storage at 14% live capacity.",
        "recommended_action": "Apply straw mulching to retain root moisture; operate drip irrigation only during dusk hours.",
        "status": "Active",
        "coordinates": [18.40, 76.58],
        "acknowledged_by": None,
        "acknowledged_at": None
    }
]

class AlertManager:
    def __init__(self):
        self.alerts = list(INITIAL_ALERTS)

    def get_all(self, status: Optional[str] = None, hazard_type: Optional[str] = None) -> List[Dict[str, Any]]:
        results = self.alerts
        if status:
            results = [a for a in results if a["status"].lower() == status.lower()]
        if hazard_type:
            results = [a for a in results if hazard_type.lower() in a["hazard_type"].lower()]
        return results

    def acknowledge(self, alert_id: str, operator_name: str = "District Disaster Officer") -> Optional[Dict[str, Any]]:
        for a in self.alerts:
            if a["id"] == alert_id:
                a["status"] = "Acknowledged"
                a["acknowledged_by"] = operator_name
                a["acknowledged_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
                return a
        return None

    def create_alert(self, data: Dict[str, Any]) -> Dict[str, Any]:
        alert_id = f"alt_{uuid.uuid4().hex[:6]}"
        new_alert = {
            "id": alert_id,
            "location": data.get("location", "Demonstration Zone"),
            "state": data.get("state", "India"),
            "hazard_type": data.get("hazard_type", "Flood Warning"),
            "risk_level": data.get("risk_level", "High"),
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "title": data.get("title", f"Early Warning Alert: {data.get('location')}"),
            "description": data.get("description", "Telemetry parameters breached early warning threshold."),
            "recommended_action": data.get("recommended_action", "Maintain high vigilance and monitor emergency channels."),
            "status": "Active",
            "coordinates": data.get("coordinates", [20.5937, 78.9629]),
            "acknowledged_by": None,
            "acknowledged_at": None
        }
        self.alerts.insert(0, new_alert)
        return new_alert

alert_manager_instance = AlertManager()

