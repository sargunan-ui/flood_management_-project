"""
AquaSentinel AI - Benchmark Hydrological & Meteorological Dataset Generator
Physics-grounded synthetic datasets for Flood and Drought early warning model training.

IMPORTANT DATASET GOVERNANCE NOTICE:
This dataset is physically calibrated using standard hydrometeorological principles
(Soil Conservation Service Curve Number principles, Thornthwaite evapotranspiration,
and Standardized Precipitation Index concepts). It is designed for algorithmic benchmarking,
hackathon demonstrations, and model architecture validation. In production settings,
these models should be calibrated with localized IMD (India Meteorological Department)
and CWC (Central Water Commission) observational station telemetry.
"""

import numpy as np
import pandas as pd
import os
import json

np.random.seed(42)

def generate_flood_dataset(n_samples: int = 4000) -> pd.DataFrame:
    """
    Generates synthetic flood telemetry samples based on physical hydrological runoff dynamics.
    """
    # 1. Rainfall intensity (mm/h): gamma distributed (mostly light/moderate, occasional torrential downpours)
    rainfall_intensity = np.random.gamma(shape=2.0, scale=12.0, size=n_samples)
    rainfall_intensity = np.clip(rainfall_intensity, 0.0, 180.0)

    # 2. 24h rainfall (mm): correlated with intensity + antecedent storm accumulation
    rainfall_24h = rainfall_intensity * np.random.uniform(2.5, 6.0, size=n_samples) + np.random.exponential(scale=25.0, size=n_samples)
    rainfall_24h = np.clip(rainfall_24h, 0.0, 480.0)

    # 3. 7-day cumulative rainfall (mm): historical storm fronts
    rainfall_7d = rainfall_24h * np.random.uniform(1.8, 3.5, size=n_samples) + np.random.exponential(scale=50.0, size=n_samples)
    rainfall_7d = np.clip(rainfall_7d, rainfall_24h, 1100.0)

    # 4. River water level (meters gauge height): baseline 3m to 18m
    river_water_level = 3.0 + (rainfall_7d / 120.0) * 1.8 + np.random.normal(0, 0.8, size=n_samples)
    river_water_level = np.clip(river_water_level, 0.5, 26.0)

    # 5. Soil moisture saturation (%): antecendent wetness
    soil_moisture = 25.0 + (rainfall_7d / 800.0) * 65.0 + np.random.normal(0, 6.0, size=n_samples)
    soil_moisture = np.clip(soil_moisture, 10.0, 99.5)

    # 6. Temperature (°C)
    temperature = np.random.normal(loc=27.0, scale=4.5, size=n_samples)
    temperature = np.clip(temperature, 12.0, 45.0)

    # 7. Elevation (meters above sea level): lower = higher basin runoff accumulation
    elevation = np.random.exponential(scale=180.0, size=n_samples) + 8.0
    elevation = np.clip(elevation, 5.0, 2500.0)

    # 8. Drainage condition: 0=Poor, 1=Moderate, 2=Good
    drainage_condition = np.random.choice([0, 1, 2], size=n_samples, p=[0.35, 0.45, 0.20])

    # 9. Historical flood occurrences in past 10 years
    historical_flood_occurrence = np.random.poisson(lam=2.5, size=n_samples)
    historical_flood_occurrence = np.clip(historical_flood_occurrence, 0, 12)

    # Calculate Hydrological Flood Index (0-100) using nonlinear runoff kinetics
    # Infiltration saturation threshold
    soil_saturation_factor = np.where(soil_moisture > 75.0, (soil_moisture - 75.0) / 25.0, 0.0)
    
    # Runoff pressure: high 24h rain + soil saturation + poor drainage
    drainage_penalty = np.where(drainage_condition == 0, 1.4, np.where(drainage_condition == 1, 1.0, 0.7))
    elevation_factor = np.exp(-elevation / 250.0)  # low elevation carries 3-5x higher pooling risk
    river_overtopping_factor = np.clip((river_water_level - 12.0) / 10.0, 0.0, 1.5)

    raw_risk = (
        (rainfall_24h / 250.0) * 32.0 * drainage_penalty +
        (rainfall_intensity / 80.0) * 18.0 +
        (soil_moisture / 100.0) * 15.0 +
        soil_saturation_factor * 12.0 +
        river_overtopping_factor * 20.0 +
        elevation_factor * 15.0 +
        (historical_flood_occurrence / 10.0) * 8.0 +
        np.random.normal(0, 2.5, size=n_samples)
    )

    risk_score = np.clip(raw_risk, 0.0, 100.0)
    flood_probability = 1.0 / (1.0 + np.exp(-(risk_score - 50.0) / 10.0))

    # Categories: Low (<25), Moderate (25-49), High (50-74), Severe (75-89), Critical (>=90)
    risk_category = pd.cut(
        risk_score,
        bins=[-1, 25, 50, 75, 90, 101],
        labels=["Low", "Moderate", "High", "Severe", "Critical"]
    )
    is_flood = (risk_score >= 50.0).astype(int)

    df = pd.DataFrame({
        "rainfall_intensity": np.round(rainfall_intensity, 2),
        "rainfall_24h": np.round(rainfall_24h, 2),
        "rainfall_7d": np.round(rainfall_7d, 2),
        "river_water_level": np.round(river_water_level, 2),
        "soil_moisture": np.round(soil_moisture, 2),
        "temperature": np.round(temperature, 1),
        "elevation": np.round(elevation, 1),
        "drainage_condition": drainage_condition,
        "historical_flood_occurrence": historical_flood_occurrence,
        "risk_score": np.round(risk_score, 1),
        "flood_probability": np.round(flood_probability, 4),
        "risk_category": risk_category,
        "is_flood": is_flood
    })

    return df

def generate_drought_dataset(n_samples: int = 4000) -> pd.DataFrame:
    """
    Generates synthetic agricultural and meteorological drought telemetry samples.
    """
    # 1. Rainfall deficit (% below normal 0-100%)
    rainfall_deficit = np.random.beta(a=2.0, b=2.2, size=n_samples) * 100.0
    rainfall_deficit = np.clip(rainfall_deficit, 0.0, 98.0)

    # 2. Temperature (°C): higher temperature accelerates evapotranspiration
    temperature = np.random.normal(loc=34.0, scale=6.0, size=n_samples)
    temperature = np.clip(temperature, 18.0, 49.0)

    # 3. Consecutive dry days (0-120 days)
    consecutive_dry_days = np.random.exponential(scale=24.0, size=n_samples)
    consecutive_dry_days = np.clip(consecutive_dry_days.astype(int), 0, 110)

    # 4. Soil moisture (%): strongly suppressed by deficit and consecutive dry days
    soil_moisture_base = 65.0 - (rainfall_deficit * 0.45) - (consecutive_dry_days * 0.3) + np.random.normal(0, 5.0, size=n_samples)
    soil_moisture = np.clip(soil_moisture_base, 4.0, 85.0)

    # 5. Relative humidity (%): inversely related to temperature and dry spell
    humidity_base = 70.0 - (temperature - 25.0) * 1.5 - (consecutive_dry_days * 0.25) + np.random.normal(0, 6.0, size=n_samples)
    relative_humidity = np.clip(humidity_base, 10.0, 95.0)

    # 6. Vegetation Condition Index (VCI / NDVI proxy %): drops with persistent soil deficit
    vci_base = 75.0 - (rainfall_deficit * 0.4) - (consecutive_dry_days * 0.35) - np.where(soil_moisture < 20.0, 18.0, 0.0) + np.random.normal(0, 5.0, size=n_samples)
    vegetation_condition = np.clip(vci_base, 5.0, 96.0)

    # 7. Historical normal rainfall (mm): 300mm (arid) to 2000mm (humid)
    historical_rainfall = np.random.uniform(350.0, 1800.0, size=n_samples)

    # Physical Drought Stress Calculation
    temp_stress = np.clip((temperature - 32.0) / 12.0, 0.0, 1.5) * 15.0
    deficit_stress = (rainfall_deficit / 100.0) * 35.0
    dry_days_stress = np.clip(consecutive_dry_days / 60.0, 0.0, 1.5) * 20.0
    soil_stress = np.clip((40.0 - soil_moisture) / 40.0, 0.0, 1.0) * 20.0
    veg_stress = np.clip((50.0 - vegetation_condition) / 50.0, 0.0, 1.0) * 15.0
    humidity_stress = np.clip((40.0 - relative_humidity) / 40.0, 0.0, 1.0) * 10.0

    raw_severity = (
        deficit_stress +
        temp_stress +
        dry_days_stress +
        soil_stress +
        veg_stress +
        humidity_stress +
        np.random.normal(0, 2.0, size=n_samples)
    )

    severity_score = np.clip(raw_severity, 0.0, 100.0)
    drought_probability = 1.0 / (1.0 + np.exp(-(severity_score - 48.0) / 11.0))

    drought_category = pd.cut(
        severity_score,
        bins=[-1, 25, 50, 75, 90, 101],
        labels=["Low", "Moderate", "High", "Severe", "Critical"]
    )
    is_drought = (severity_score >= 50.0).astype(int)

    df = pd.DataFrame({
        "rainfall_deficit": np.round(rainfall_deficit, 2),
        "temperature": np.round(temperature, 1),
        "soil_moisture": np.round(soil_moisture, 2),
        "relative_humidity": np.round(relative_humidity, 2),
        "vegetation_condition": np.round(vegetation_condition, 2),
        "historical_rainfall": np.round(historical_rainfall, 1),
        "consecutive_dry_days": consecutive_dry_days,
        "severity_score": np.round(severity_score, 1),
        "drought_probability": np.round(drought_probability, 4),
        "drought_category": drought_category,
        "is_drought": is_drought
    })

    return df

def save_datasets(base_dir: str):
    os.makedirs(base_dir, exist_ok=True)
    
    flood_df = generate_flood_dataset(4500)
    drought_df = generate_drought_dataset(4500)
    
    flood_path = os.path.join(base_dir, "flood_benchmark_dataset.csv")
    drought_path = os.path.join(base_dir, "drought_benchmark_dataset.csv")
    
    flood_df.to_csv(flood_path, index=False)
    drought_df.to_csv(drought_path, index=False)
    
    metadata = {
        "dataset_name": "AquaSentinel AI Physical Hydrometeorological Benchmark Dataset",
        "version": "1.0-synthetic-calibrated",
        "date_created": "2026-11-03",
        "flood_samples": len(flood_df),
        "drought_samples": len(drought_df),
        "governance_note": "Synthetic benchmark dataset generated with hydrological runoff and evapotranspiration physics for demonstration and model verification. Not to be presented as uncalibrated real-world observations."
    }
    
    with open(os.path.join(base_dir, "dataset_metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"Datasets successfully generated: {flood_path} and {drought_path}")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(current_dir, "../../../data"))
    save_datasets(data_dir)

