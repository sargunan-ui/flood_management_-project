"""
AquaSentinel AI - River Monitoring Stations Data
Provides monitored river telemetry, gauge levels, danger thresholds, and simplified status.
"""

from typing import List, Dict, Any
import datetime

RIVER_STATIONS: List[Dict[str, Any]] = [
    {
        "id": "riv_001",
        "river_name": "Brahmaputra",
        "station_name": "Dhemaji / Subansiri Confluence",
        "state": "Assam",
        "water_level_m": 16.8,
        "warning_level_m": 16.0,
        "danger_level_m": 17.0,
        "discharge_cusecs": 142000,
        "status": "Critical",
        "trend": "Rising",
        "simple_status": "Water level is near danger mark. Water is rising fast.",
        "last_updated": "Today, 10:30 AM",
        "is_demo": True
    },
    {
        "id": "riv_002",
        "river_name": "Kamla Balan",
        "station_name": "Jhanjharpur / Darbhanga",
        "state": "Bihar",
        "water_level_m": 13.4,
        "warning_level_m": 12.5,
        "danger_level_m": 13.0,
        "discharge_cusecs": 85000,
        "status": "Critical",
        "trend": "Rising",
        "simple_status": "Water has crossed danger level. Embankment risk in low areas.",
        "last_updated": "Today, 10:15 AM",
        "is_demo": True
    },
    {
        "id": "riv_003",
        "river_name": "Barak",
        "station_name": "Annapurna Ghat, Silchar",
        "state": "Assam",
        "water_level_m": 21.2,
        "warning_level_m": 20.0,
        "danger_level_m": 21.5,
        "discharge_cusecs": 62000,
        "status": "High",
        "trend": "Rising",
        "simple_status": "Water level is high and rising slowly.",
        "last_updated": "Today, 09:45 AM",
        "is_demo": True
    },
    {
        "id": "riv_004",
        "river_name": "Ganga (Ganges)",
        "station_name": "Gandhi Ghat, Patna",
        "state": "Bihar",
        "water_level_m": 50.1,
        "warning_level_m": 49.5,
        "danger_level_m": 50.5,
        "discharge_cusecs": 320000,
        "status": "High",
        "trend": "Steady",
        "simple_status": "Water level is high but steady. Low-lying riverbanks are waterlogged.",
        "last_updated": "Today, 09:30 AM",
        "is_demo": True
    },
    {
        "id": "riv_005",
        "river_name": "Panchganga",
        "station_name": "Rajaram Weir, Kolhapur",
        "state": "Maharashtra",
        "water_level_m": 43.5,
        "warning_level_m": 42.0,
        "danger_level_m": 44.0,
        "discharge_cusecs": 48000,
        "status": "High",
        "trend": "Rising",
        "simple_status": "Water level is high. Almatti dam backwaters being monitored.",
        "last_updated": "Today, 08:30 AM",
        "is_demo": True
    },
    {
        "id": "riv_006",
        "river_name": "Pamba",
        "station_name": "Chengannur / Kuttanad",
        "state": "Kerala",
        "water_level_m": 3.8,
        "warning_level_m": 3.5,
        "danger_level_m": 4.2,
        "discharge_cusecs": 29000,
        "status": "High",
        "trend": "Rising",
        "simple_status": "Water level is elevated due to heavy hill rains.",
        "last_updated": "Today, 08:00 AM",
        "is_demo": True
    },
    {
        "id": "riv_007",
        "river_name": "Rapti",
        "station_name": "Birdghat, Gorakhpur",
        "state": "Uttar Pradesh",
        "water_level_m": 75.1,
        "warning_level_m": 74.0,
        "danger_level_m": 76.0,
        "discharge_cusecs": 54000,
        "status": "Rising",
        "trend": "Rising",
        "simple_status": "Water level is rising after upstream rain.",
        "last_updated": "Today, 07:15 AM",
        "is_demo": True
    },
    {
        "id": "riv_008",
        "river_name": "Mahanadi",
        "station_name": "Naraj Barrage, Cuttack",
        "state": "Odisha",
        "water_level_m": 9.2,
        "warning_level_m": 10.5,
        "danger_level_m": 12.0,
        "discharge_cusecs": 78000,
        "status": "Normal",
        "trend": "Steady",
        "simple_status": "Water level is normal and within safe riverbanks.",
        "last_updated": "Today, 06:00 AM",
        "is_demo": True
    },
    {
        "id": "riv_009",
        "river_name": "Yamuna",
        "station_name": "Old Railway Bridge, Delhi",
        "state": "Delhi",
        "water_level_m": 204.5,
        "warning_level_m": 204.5,
        "danger_level_m": 205.3,
        "discharge_cusecs": 25000,
        "status": "Normal",
        "trend": "Steady",
        "simple_status": "Water level is in safe zone. No immediate flood threat.",
        "last_updated": "Today, 06:30 AM",
        "is_demo": True
    },
    {
        "id": "riv_010",
        "river_name": "Godavari",
        "station_name": "Dowleswaram Barrage, Rajahmundry",
        "state": "Andhra Pradesh",
        "water_level_m": 14.2,
        "warning_level_m": 16.0,
        "danger_level_m": 17.5,
        "discharge_cusecs": 95000,
        "status": "Normal",
        "trend": "Steady",
        "simple_status": "Flow is normal. Gates operating regularly.",
        "last_updated": "Today, 06:15 AM",
        "is_demo": True
    },
    {
        "id": "riv_011",
        "river_name": "Kaveri (Cauvery)",
        "station_name": "Upper Anicut / Mettur, Tamil Nadu",
        "state": "Tamil Nadu",
        "water_level_m": 18.0,
        "warning_level_m": 22.0,
        "danger_level_m": 24.5,
        "discharge_cusecs": 18000,
        "status": "Normal",
        "trend": "Steady",
        "simple_status": "River water level is normal with steady downstream release.",
        "last_updated": "Today, 05:45 AM",
        "is_demo": True
    },
    {
        "id": "riv_012",
        "river_name": "Mithi",
        "station_name": "Kurla Gauge, Mumbai",
        "state": "Maharashtra",
        "water_level_m": 3.2,
        "warning_level_m": 3.8,
        "danger_level_m": 4.5,
        "discharge_cusecs": 4500,
        "status": "Normal",
        "trend": "Steady",
        "simple_status": "Water level is currently normal. Monitored for high tide synchronization.",
        "last_updated": "Today, 08:45 AM",
        "is_demo": True
    }
]

def get_river_stations() -> List[Dict[str, Any]]:
    return RIVER_STATIONS

