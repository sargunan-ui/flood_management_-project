from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class FloodPredictionRequest(BaseModel):
    location_name: Optional[str] = Field("Custom Location", description="Name of the location or district")
    rainfall_intensity: float = Field(..., ge=0.0, le=250.0, description="Current rainfall intensity in mm/h")
    rainfall_24h: float = Field(..., ge=0.0, le=600.0, description="Cumulative rainfall in last 24h in mm")
    rainfall_7d: float = Field(..., ge=0.0, le=1500.0, description="Cumulative rainfall in last 7 days in mm")
    river_water_level: float = Field(..., ge=0.0, le=30.0, description="River water gauge level in meters")
    soil_moisture: float = Field(..., ge=0.0, le=100.0, description="Soil moisture saturation percentage (0-100%)")
    temperature: float = Field(28.0, ge=-10.0, le=55.0, description="Ambient temperature in Celsius")
    elevation: float = Field(..., ge=-10.0, le=5000.0, description="Elevation above sea level in meters")
    drainage_condition: int = Field(1, ge=0, le=2, description="Drainage condition: 0=Poor, 1=Moderate, 2=Good")
    historical_flood_occurrence: int = Field(2, ge=0, le=20, description="Historical flood events in past decade")

class FactorContribution(BaseModel):
    feature: str
    feature_label: str
    value: Any
    importance: float
    impact: str  # "increases_risk" or "decreases_risk"
    explanation: str

class PersonaRecommendations(BaseModel):
    farmers: List[str]
    residents: List[str]
    authorities: List[str]

class FloodPredictionResponse(BaseModel):
    prediction_id: str
    location_name: str
    flood_probability: float
    risk_score: float  # 0 to 100
    risk_category: str  # Low, Moderate, High, Severe, Critical
    confidence_level: str
    contributing_factors: List[FactorContribution]
    plain_english_explanation: List[str]
    recommendations: PersonaRecommendations
    timestamp: str
    is_demo: bool = False

class DroughtPredictionRequest(BaseModel):
    location_name: Optional[str] = Field("Custom Location", description="Name of the location or district")
    rainfall_deficit: float = Field(..., ge=0.0, le=100.0, description="Seasonal rainfall deficit percentage (0-100%)")
    temperature: float = Field(..., ge=10.0, le=55.0, description="Average temperature in Celsius")
    soil_moisture: float = Field(..., ge=0.0, le=100.0, description="Soil moisture saturation percentage (0-100%)")
    relative_humidity: float = Field(..., ge=0.0, le=100.0, description="Relative humidity percentage (0-100%)")
    vegetation_condition: float = Field(..., ge=0.0, le=100.0, description="Vegetation Condition Index / NDVI proxy (0-100%)")
    historical_rainfall: float = Field(..., ge=50.0, le=3000.0, description="Normal historical seasonal rainfall in mm")
    consecutive_dry_days: int = Field(..., ge=0, le=180, description="Consecutive days without significant rainfall")

class DroughtPredictionResponse(BaseModel):
    prediction_id: str
    location_name: str
    drought_probability: float
    severity_score: float  # 0 to 100
    drought_category: str  # Low, Moderate, High, Severe, Critical
    confidence_level: str
    contributing_factors: List[FactorContribution]
    plain_english_explanation: List[str]
    agricultural_recommendations: PersonaRecommendations
    timestamp: str
    is_demo: bool = False

class DistrictProfile(BaseModel):
    id: str
    name: str
    state: str
    latitude: float
    longitude: float
    elevation: float
    primary_hazard: str  # Flood, Drought, or Dual
    flood_risk_score: float
    flood_category: str
    drought_risk_score: float
    drought_category: str
    river_basin: Optional[str] = None
    soil_type: Optional[str] = None
    vulnerability_index: float
    key_metrics: Dict[str, Any]

class AlertItem(BaseModel):
    id: str
    location: str
    state: str
    hazard_type: str  # "Flood Warning", "Flash Flood Risk", "Agricultural Drought", "Water Scarcity"
    risk_level: str   # "Critical", "Severe", "High", "Moderate", "Low"
    timestamp: str
    title: str
    description: str
    recommended_action: str
    status: str       # "Active", "Acknowledged", "Resolved"
    coordinates: List[float]
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[str] = None

class DashboardSummary(BaseModel):
    current_flood_risk_avg: float
    current_drought_risk_avg: float
    total_monitored_locations: int
    high_risk_flood_count: int
    high_risk_drought_count: int
    active_alerts_count: int
    immediate_attention_locations: List[Dict[str, Any]]
    rainfall_summary: Dict[str, Any]
    soil_moisture_summary: Dict[str, Any]
    recent_alerts: List[AlertItem]
    risk_distribution: Dict[str, int]


class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2)
    email: str = Field(..., min_length=5)
    password: str = Field(..., min_length=6)
    role: str = Field("Citizen", description="Citizen, Farmer, Disaster Management Official, or Administrator")
    organization: Optional[str] = ""
    location: Optional[str] = ""

class LoginRequest(BaseModel):
    email: str = Field(..., min_length=3)
    password: str = Field(..., min_length=4)

class UserProfile(BaseModel):
    id: str
    email: str
    name: str
    role: str
    organization: Optional[str] = ""
    location: Optional[str] = ""
    created_at: Optional[str] = None

class AuthResponse(BaseModel):
    token: str
    user: UserProfile

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    history: Optional[List[Dict[str, str]]] = None
    context: Optional[Dict[str, Any]] = None

class ChatResponse(BaseModel):
    reply: str
    is_live_llm: bool
    engine: str
    status: str
    notice: Optional[str] = None
