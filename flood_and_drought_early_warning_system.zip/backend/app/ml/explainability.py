"""
AquaSentinel AI - Explainable AI (XAI) Attribution Engine
Provides feature importance attribution and physically coherent plain-English
explanations answering: "WHY IS THIS LOCATION AT RISK?"
"""

from typing import List, Dict, Any
from backend.app.schemas.models import FactorContribution

FEATURE_HUMAN_LABELS = {
    "rainfall_intensity": "Rainfall Intensity (mm/h)",
    "rainfall_24h": "24-Hour Cumulative Rainfall (mm)",
    "rainfall_7d": "7-Day Antecedent Rainfall (mm)",
    "river_water_level": "River Gauge Level (m)",
    "soil_moisture": "Soil Saturation Level (%)",
    "temperature": "Ambient Temperature (°C)",
    "elevation": "Terrain Elevation (m a.s.l.)",
    "drainage_condition": "Catchment Drainage Condition",
    "historical_flood_occurrence": "Decadal Flood Recurrence",
    "rainfall_deficit": "Seasonal Rainfall Deficit (%)",
    "relative_humidity": "Relative Humidity (%)",
    "vegetation_condition": "Vegetation Condition Index (VCI)",
    "historical_rainfall": "Long-Term Normal Rainfall (mm)",
    "consecutive_dry_days": "Consecutive Rainless Days"
}

def explain_flood_prediction(
    inputs: Dict[str, Any],
    base_importances: Dict[str, float],
    risk_score: float
) -> tuple[List[FactorContribution], List[str]]:
    """
    Computes local feature contribution and plain-English risk rationales for flood.
    """
    contributions: List[FactorContribution] = []
    plain_reasons: List[str] = []

    # 1. 24h rainfall
    r24 = inputs["rainfall_24h"]
    imp_r24 = base_importances.get("rainfall_24h", 0.28)
    if r24 > 120.0:
        weight = imp_r24 * 1.5
        impact = "increases_risk"
        exp = f"Torrential 24h precipitation ({r24:.1f} mm) severely exceeds local watershed holding limits."
        plain_reasons.append(f"Heavy rainfall of {r24:.1f} mm in the last 24 hours created immense runoff.")
    elif r24 > 60.0:
        weight = imp_r24 * 1.1
        impact = "increases_risk"
        exp = f"Moderate-heavy 24h rainfall ({r24:.1f} mm) is actively elevating runoff rates."
        plain_reasons.append(f"Accumulated 24-hour rainfall ({r24:.1f} mm) is pushing catchment near capacity.")
    else:
        weight = imp_r24 * 0.4
        impact = "decreases_risk"
        exp = f"24h precipitation ({r24:.1f} mm) is within normal catchment drainage capacity."
    contributions.append(FactorContribution(
        feature="rainfall_24h",
        feature_label=FEATURE_HUMAN_LABELS["rainfall_24h"],
        value=r24,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 2. Soil moisture
    sm = inputs["soil_moisture"]
    imp_sm = base_importances.get("soil_moisture", 0.18)
    if sm >= 85.0:
        weight = imp_sm * 1.4
        impact = "increases_risk"
        exp = f"Soil moisture at {sm:.1f}% indicates complete saturation; zero rainwater can infiltrate."
        plain_reasons.append(f"Ground saturation is critical ({sm:.1f}%), causing 100% of new rainfall to become surface runoff.")
    elif sm >= 70.0:
        weight = imp_sm * 1.0
        impact = "increases_risk"
        exp = f"High soil moisture ({sm:.1f}%) significantly retards infiltration capacity."
        plain_reasons.append(f"High ground moisture ({sm:.1f}%) limits soil absorption.")
    else:
        weight = imp_sm * 0.5
        impact = "decreases_risk"
        exp = f"Soil moisture ({sm:.1f}%) allows active subsurface percolation and infiltration."
    contributions.append(FactorContribution(
        feature="soil_moisture",
        feature_label=FEATURE_HUMAN_LABELS["soil_moisture"],
        value=sm,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 3. River water gauge
    rw = inputs["river_water_level"]
    imp_rw = base_importances.get("river_water_level", 0.20)
    if rw >= 15.0:
        weight = imp_rw * 1.6
        impact = "increases_risk"
        exp = f"River gauge level ({rw:.1f} m) is near or breaching regional danger mark."
        plain_reasons.append(f"River level reached {rw:.1f} m, posing immediate embankment breach/overtopping risk.")
    elif rw >= 10.0:
        weight = imp_rw * 1.0
        impact = "increases_risk"
        exp = f"River level ({rw:.1f} m) is elevated, narrowing safety buffer."
    else:
        weight = imp_rw * 0.4
        impact = "decreases_risk"
        exp = f"River level ({rw:.1f} m) has sufficient riverbed freeboard clearance."
    contributions.append(FactorContribution(
        feature="river_water_level",
        feature_label=FEATURE_HUMAN_LABELS["river_water_level"],
        value=rw,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 4. Elevation
    elev = inputs["elevation"]
    imp_elev = base_importances.get("elevation", 0.12)
    if elev <= 30.0:
        weight = imp_elev * 1.4
        impact = "increases_risk"
        exp = f"Low elevation ({elev:.1f} m a.s.l.) places the zone in a natural gravity collection depression."
        plain_reasons.append(f"Low elevation ({elev:.1f} m) makes this location a natural pooling sink for upstream discharge.")
    elif elev <= 80.0:
        weight = imp_elev * 0.9
        impact = "increases_risk"
        exp = f"Modest elevation ({elev:.1f} m) exhibits moderate drainage slope."
    else:
        weight = imp_elev * 0.3
        impact = "decreases_risk"
        exp = f"Higher terrain elevation ({elev:.1f} m) facilitates gravitational natural drainage."
    contributions.append(FactorContribution(
        feature="elevation",
        feature_label=FEATURE_HUMAN_LABELS["elevation"],
        value=elev,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 5. Drainage condition
    drainage = inputs["drainage_condition"]
    drain_names = {0: "Poor / Obstructed", 1: "Moderate", 2: "Well-maintained"}
    imp_dr = base_importances.get("drainage_condition", 0.10)
    if drainage == 0:
        weight = imp_dr * 1.5
        impact = "increases_risk"
        exp = "Obstructed or inadequate drainage network prevents stormwater evacuation."
        plain_reasons.append("Drainage channels are inadequate or clogged, multiplying inundation depth.")
    elif drainage == 1:
        weight = imp_dr * 0.8
        impact = "decreases_risk"
        exp = "Standard culverts and stormwater canals functioning at regular throughput."
    else:
        weight = imp_dr * 0.3
        impact = "decreases_risk"
        exp = "Engineered drainage network enables rapid stormwater evacuation."
    contributions.append(FactorContribution(
        feature="drainage_condition",
        feature_label=FEATURE_HUMAN_LABELS["drainage_condition"],
        value=drain_names.get(drainage, "Moderate"),
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 6. Rainfall intensity
    rint = inputs["rainfall_intensity"]
    imp_rint = base_importances.get("rainfall_intensity", 0.12)
    if rint >= 30.0:
        weight = imp_rint * 1.3
        impact = "increases_risk"
        exp = f"Intense burst rate ({rint:.1f} mm/h) exceeds surface flash-runoff threshold."
        plain_reasons.append(f"Flash-flood rate downpours ({rint:.1f} mm/h) occurring.")
    else:
        weight = imp_rint * 0.6
        impact = "decreases_risk"
        exp = f"Rainfall rate ({rint:.1f} mm/h) is manageable."
    contributions.append(FactorContribution(
        feature="rainfall_intensity",
        feature_label=FEATURE_HUMAN_LABELS["rainfall_intensity"],
        value=rint,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # Normalize relative importance percentages
    total_w = sum(c.importance for c in contributions) or 1.0
    for c in contributions:
        c.importance = round((c.importance / total_w) * 100.0, 1)

    # Sort by importance descending
    contributions.sort(key=lambda x: x.importance, reverse=True)

    if not plain_reasons:
        plain_reasons.append("Environmental metrics are currently within stable baseline tolerances with no impending flood threat.")

    return contributions, plain_reasons


def explain_drought_prediction(
    inputs: Dict[str, Any],
    base_importances: Dict[str, float],
    severity_score: float
) -> tuple[List[FactorContribution], List[str]]:
    """
    Computes local feature contribution and plain-English risk rationales for drought.
    """
    contributions: List[FactorContribution] = []
    plain_reasons: List[str] = []

    # 1. Rainfall deficit
    deficit = inputs["rainfall_deficit"]
    imp_def = base_importances.get("rainfall_deficit", 0.32)
    if deficit >= 50.0:
        weight = imp_def * 1.5
        impact = "increases_risk"
        exp = f"Severe precipitation deficit ({deficit:.1f}% below normal) created acute water deficiency."
        plain_reasons.append(f"Rainfall deficit of {deficit:.1f}% below normal has severely deprived the seasonal water balance.")
    elif deficit >= 25.0:
        weight = imp_def * 1.1
        impact = "increases_risk"
        exp = f"Moderate rainfall deficit ({deficit:.1f}% below normal) stresses rain-fed farming."
        plain_reasons.append(f"Seasonal rainfall is {deficit:.1f}% below normal seasonal average.")
    else:
        weight = imp_def * 0.4
        impact = "decreases_risk"
        exp = f"Rainfall deficit ({deficit:.1f}%) is within expected seasonal variation."
    contributions.append(FactorContribution(
        feature="rainfall_deficit",
        feature_label=FEATURE_HUMAN_LABELS["rainfall_deficit"],
        value=deficit,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 2. Consecutive dry days
    dry_days = inputs["consecutive_dry_days"]
    imp_dry = base_importances.get("consecutive_dry_days", 0.22)
    if dry_days >= 40:
        weight = imp_dry * 1.4
        impact = "increases_risk"
        exp = f"Protracted dry spell of {dry_days} continuous days depleted topsoil moisture."
        plain_reasons.append(f"Extended dry spell of {dry_days} days without rainfall broke the crop moisture cycle.")
    elif dry_days >= 20:
        weight = imp_dry * 1.0
        impact = "increases_risk"
        exp = f"Dry spell lasting {dry_days} days is inducing early vegetative stress."
        plain_reasons.append(f"Dry streak of {dry_days} rainless days is drying upper soil horizons.")
    else:
        weight = imp_dry * 0.4
        impact = "decreases_risk"
        exp = f"Recent rain intervals ({dry_days} dry days) preserve soil vitality."
    contributions.append(FactorContribution(
        feature="consecutive_dry_days",
        feature_label=FEATURE_HUMAN_LABELS["consecutive_dry_days"],
        value=dry_days,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 3. Soil moisture
    sm = inputs["soil_moisture"]
    imp_sm = base_importances.get("soil_moisture", 0.20)
    if sm <= 18.0:
        weight = imp_sm * 1.5
        impact = "increases_risk"
        exp = f"Soil moisture at {sm:.1f}% is below crop permanent wilting point."
        plain_reasons.append(f"Soil moisture critically degraded to {sm:.1f}%, halting plant root moisture uptake.")
    elif sm <= 30.0:
        weight = imp_sm * 1.1
        impact = "increases_risk"
        exp = f"Sub-optimal soil moisture ({sm:.1f}%) induces agricultural moisture stress."
    else:
        weight = imp_sm * 0.4
        impact = "decreases_risk"
        exp = f"Soil moisture ({sm:.1f}%) sustains root zone hydration."
    contributions.append(FactorContribution(
        feature="soil_moisture",
        feature_label=FEATURE_HUMAN_LABELS["soil_moisture"],
        value=sm,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 4. Temperature & Evapotranspiration
    temp = inputs["temperature"]
    imp_tmp = base_importances.get("temperature", 0.14)
    if temp >= 38.0:
        weight = imp_tmp * 1.3
        impact = "increases_risk"
        exp = f"Elevated temperature ({temp:.1f}°C) triggers extreme potential evapotranspiration (PET)."
        plain_reasons.append(f"High heat ({temp:.1f}°C) accelerates water evaporation from reservoirs and foliage.")
    else:
        weight = imp_tmp * 0.6
        impact = "decreases_risk"
        exp = f"Temperature ({temp:.1f}°C) causes normal seasonal evaporation."
    contributions.append(FactorContribution(
        feature="temperature",
        feature_label=FEATURE_HUMAN_LABELS["temperature"],
        value=temp,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # 5. Vegetation Condition Index
    vci = inputs["vegetation_condition"]
    imp_vci = base_importances.get("vegetation_condition", 0.12)
    if vci <= 25.0:
        weight = imp_vci * 1.4
        impact = "increases_risk"
        exp = f"Vegetation Condition Index ({vci:.1f}%) signals severe chlorophyll loss and crop desiccation."
        plain_reasons.append(f"Satellite vegetation index ({vci:.1f}%) reveals widespread canopy browning.")
    else:
        weight = imp_vci * 0.5
        impact = "decreases_risk"
        exp = f"Vegetation index ({vci:.1f}%) indicates healthy photosynthetic canopy."
    contributions.append(FactorContribution(
        feature="vegetation_condition",
        feature_label=FEATURE_HUMAN_LABELS["vegetation_condition"],
        value=vci,
        importance=round(weight, 3),
        impact=impact,
        explanation=exp
    ))

    # Normalize relative importance percentages
    total_w = sum(c.importance for c in contributions) or 1.0
    for c in contributions:
        c.importance = round((c.importance / total_w) * 100.0, 1)

    contributions.sort(key=lambda x: x.importance, reverse=True)

    if not plain_reasons:
        plain_reasons.append("Rainfall patterns and soil reservoir levels are healthy with low drought vulnerability.")

    return contributions, plain_reasons

