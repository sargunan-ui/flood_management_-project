"""
AquaSentinel AI - Persona-Specific Action Recommendation Engine
Generates tailored, actionable, and non-generic protocols for Farmers, Residents,
and Emergency Authorities across Flood and Drought hazard severities.
"""

from typing import Dict, List
from backend.app.schemas.models import PersonaRecommendations

def get_flood_recommendations(risk_category: str, metrics: Dict[str, float]) -> PersonaRecommendations:
    cat = risk_category.lower()
    
    if cat in ["critical", "severe"]:
        return PersonaRecommendations(
            farmers=[
                "Immediately evacuate livestock to elevated flood shelters or high-ground bunds.",
                "Harvest mature standing kharif/rabi crops immediately if inundation is imminent.",
                "Elevate harvested grain bags and fertilizers onto wooden pallets > 1.5m above ground.",
                "Clear farm drainage ditches, sluice gates, and bund spillways to minimize waterlogging depth.",
                "Disconnect electric motors, submersibles, and farm machinery to prevent terminal short circuits."
            ],
            residents=[
                "Activate household evacuation plan; move elderly, children, and pets to designated shelter.",
                "Pack emergency 'Go-Bag': 3 days potable water, dry rations, torch, powerbank, essential medicines & ID cards.",
                "Turn off main electrical circuit breaker and LPG cylinder regulators before evacuating.",
                "DO NOT attempt to walk, cycle, or drive through flooded roads or culverts ('Turn Around, Don't Drown').",
                "Store 20+ liters of boiled drinking water in airtight sterilized containers as water mains may be contaminated."
            ],
            authorities=[
                "Deploy NDRF / SDRF battalions with motorized inflatable rescue boats to predetermined vulnerable zones.",
                "Open and inspect multipurpose flood shelters with emergency food packets, halogen lamps, and chlorination tablets.",
                "Patrol vulnerable river embankments, barrages, and ring bunds 24/7; stockpile sandbags and geo-textile sheets.",
                "Issue targeted wireless emergency alerts (CAP format) across regional cellular towers and local FM radio.",
                "Coordinate controlled barrage discharges with downstream district magistrates to avoid compound flood peaks."
            ]
        )
    elif cat == "high":
        return PersonaRecommendations(
            farmers=[
                "Clear field perimeter drainage channels to ensure unobstructed gravity runoff.",
                "Prepare raised sheds for poultry and small ruminants.",
                "Postpone planned urea/nitrogen top-dressing as runoff will cause heavy fertilizer wash-off.",
                "Monitor farm pond and percolation tank spillway structures for erosion."
            ],
            residents=[
                "Check roof drainage pipes and storm grates around the house for silt or debris blockage.",
                "Relocate ground-floor valuable electronics, appliances, and documents to upper levels.",
                "Keep emergency phone numbers (112, 1070/1077 district disaster helpline) handy.",
                "Verify battery charge on emergency radios, torches, and powerbanks."
            ],
            authorities=[
                "Inspect critical stormwater pump stations and ensure backup diesel generators are fueled.",
                "Clear urban choke-points, major culverts, and underpasses of plastic and silt blockages.",
                "Pre-position heavy earthmoving equipment (JCBs) and de-watering pumps near known bottlenecks.",
                "Brief village disaster volunteers (Aapda Mitra) on standby readiness."
            ]
        )
    elif cat == "moderate":
        return PersonaRecommendations(
            farmers=[
                "Inspect bund heights around paddy fields to prevent premature breaching.",
                "Check drainage outlets and ensure culverts are free of weeds.",
                "Keep farm machinery parked on elevated concrete pads."
            ],
            residents=[
                "Clear residential balcony and courtyard drains.",
                "Check vehicle wipers, tires, and emergency flashers.",
                "Monitor local weather bulletins and AquaSentinel radar."
            ],
            authorities=[
                "Conduct routine hydrological gauge readings every 3 hours.",
                "Verify alert communication tree across gram panchayats.",
                "Check readiness of emergency dewatering pumps."
            ]
        )
    else:  # Low
        return PersonaRecommendations(
            farmers=[
                "Maintain standard field irrigation drainage practices.",
                "Conduct routine maintenance on drainage gates and field bunds.",
                "Proceed with regular sowing and weeding operations."
            ],
            residents=[
                "Standard seasonal vigilance; inspect home gutters before monsoon.",
                "Ensure home first-aid kit is restocked."
            ],
            authorities=[
                "Conduct annual pre-monsoon desilting of major stormwater drains.",
                "Review disaster management manual and inventory of rescue gear."
            ]
        )


def get_drought_recommendations(drought_category: str, metrics: Dict[str, float]) -> PersonaRecommendations:
    cat = drought_category.lower()
    
    if cat in ["critical", "severe"]:
        return PersonaRecommendations(
            farmers=[
                "Switch exclusively to micro-irrigation (drip / subsurface drip) during cool night or early morning hours.",
                "Apply thick organic crop residue mulching (straw, dry leaves) to cut soil evaporation by up to 60%.",
                "Spray 2% potassium chloride (KCl) or anti-transpirant (kaolin spray) to reduce crop transpiration losses.",
                "Prioritize life-saving protective irrigation only for high-value standing crops; suspend water-guzzling varieties.",
                "Enroll in Pradhan Mantri Fasal Bima Yojana (PMFBY) insurance claim window for moisture deficit distress.",
                "Establish community fodder banks and silages to preserve cattle from distress sales."
            ],
            residents=[
                "Implement strict greywater recycling: repurpose kitchen rinse water for garden and sanitation.",
                "Restrict household municipal water use strictly to drinking, cooking, and essential hygiene.",
                "Report pipeline leaks and municipal pipe fractures immediately to urban water supply boards.",
                "Install aerators on household taps to reduce flow rates by 40-50% without pressure loss.",
                "Prepare shaded water containers for neighborhood birds, community animals, and pets."
            ],
            authorities=[
                "Declare agricultural drought notification to trigger State Disaster Response Fund (SDRF) relief disbursement.",
                "Mobilize GPS-tracked drinking water tankers to chronically parched habitations on fixed schedules.",
                "Impose legal ban on non-essential water usage (swimming pools, lawn sprinklers, vehicle washing centers).",
                "Recharge emergency public borewells and install reverse osmosis (RO) purification kiosks in fluoride-prone pockets.",
                "Initiate MGNREGA works focused on desilting traditional check-dams, talabs, and johads before next rain."
            ]
        )
    elif cat == "high":
        return PersonaRecommendations(
            farmers=[
                "Adopt alternate-furrow irrigation to conserve up to 35% irrigation volume.",
                "Consider intercropping with short-duration drought-hardy legumes (moong, cowpea, moth bean).",
                "Avoid deep tillage to prevent moisture loss from exposed subsoil horizons.",
                "Test groundwater salinity before applying deep borewell water to sensitive crops."
            ],
            residents=[
                "Limit lawn watering and clean walkways using brooms instead of hosepipes.",
                "Inspect overhead tank float valves to prevent water overflow waste.",
                "Harvest any occasional unseasonal shower with rooftop catchment barrels."
            ],
            authorities=[
                "Conduct weekly water audits of surface reservoirs and release water strictly as per agricultural roster.",
                "Accelerate micro-irrigation subsidy disbursals for drip and sprinkler installations.",
                "Repair leaking distribution mains across rural pipeline grids."
            ]
        )
    elif cat == "moderate":
        return PersonaRecommendations(
            farmers=[
                "Monitor soil tensiometers or soil moisture readings before turning on pump sets.",
                "Maintain farm bunds to trap every millimeter of upcoming rainfall.",
                "Choose drought-tolerant seed varieties for upcoming sowing cycles."
            ],
            residents=[
                "Practice mindful domestic water usage; fix leaky faucets promptly.",
                "Avoid letting tap water run continuously during washing."
            ],
            authorities=[
                "Monitor reservoir live storage levels against historical rule curves.",
                "Promote community rainwater harvesting awareness in schools and panchayats."
            ]
        )
    else:  # Low
        return PersonaRecommendations(
            farmers=[
                "Standard crop cultivation cycle with regular irrigation management.",
                "Participate in soil health card testing to optimize organic matter and moisture retention."
            ],
            residents=[
                "Maintain home rainwater harvesting filters and recharge pits.",
                "Standard water conservation habits."
            ],
            authorities=[
                "Maintain watershed structures and recharge trenches.",
                "Update groundwater extraction telemetry logs."
            ]
        )

