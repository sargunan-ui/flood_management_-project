"""
AquaSentinel AI - Machine Learning Model Training & Evaluation Pipeline
Trains, evaluates, and serializes Flood Risk and Drought Risk models.

Outputs:
- models/flood_model.joblib
- models/drought_model.joblib
- models/model_metadata.json (Metrics, Confusion Matrix, Feature Importance, Explainability Weights)
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, mean_squared_error, r2_score
)

# Import dataset generators
from backend.app.data.generate_datasets import generate_flood_dataset, generate_drought_dataset

def train_and_evaluate_flood_model(output_dir: str):
    print("Generating flood benchmark dataset (4,500 samples)...")
    df = generate_flood_dataset(4500)
    
    feature_cols = [
        "rainfall_intensity",
        "rainfall_24h",
        "rainfall_7d",
        "river_water_level",
        "soil_moisture",
        "temperature",
        "elevation",
        "drainage_condition",
        "historical_flood_occurrence"
    ]
    
    X = df[feature_cols]
    y_class = df["is_flood"]
    y_score = df["risk_score"]
    
    X_train, X_test, y_train_cls, y_test_cls, y_train_scr, y_test_scr = train_test_split(
        X, y_class, y_score, test_size=0.2, random_state=42, stratify=y_class
    )
    
    # Random Forest Classifier (tuned to minimize false negatives - disaster critical)
    clf = RandomForestClassifier(
        n_estimators=150,
        max_depth=12,
        class_weight={0: 1.0, 1: 1.3},  # Disaster priority: Penalize false negatives higher
        random_state=42,
        n_jobs=-1
    )
    clf.fit(X_train, y_train_cls)
    
    # Regressor for calibrated continuous risk score (0-100)
    reg = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )
    reg.fit(X_train, y_train_scr)
    
    # Evaluate Classifier
    y_pred_cls = clf.predict(X_test)
    y_prob_cls = clf.predict_proba(X_test)[:, 1]
    
    acc = accuracy_score(y_test_cls, y_pred_cls)
    prec = precision_score(y_test_cls, y_pred_cls)
    rec = recall_score(y_test_cls, y_pred_cls)
    f1 = f1_score(y_test_cls, y_pred_cls)
    roc_auc = roc_auc_score(y_test_cls, y_prob_cls)
    cm = confusion_matrix(y_test_cls, y_pred_cls).tolist()
    
    # Evaluate Regressor
    y_pred_scr = reg.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test_scr, y_pred_scr)))
    r2 = float(r2_score(y_test_scr, y_pred_scr))
    
    # Feature importances
    feature_importance = {
        col: float(imp) for col, imp in zip(feature_cols, clf.feature_importances_)
    }
    # Sort descending
    feature_importance = dict(sorted(feature_importance.items(), key=lambda item: item[1], reverse=True))
    
    model_bundle = {
        "classifier": clf,
        "regressor": reg,
        "feature_cols": feature_cols
    }
    
    joblib.dump(model_bundle, os.path.join(output_dir, "flood_model.joblib"))
    
    metrics = {
        "accuracy": round(float(acc), 4),
        "precision": round(float(prec), 4),
        "recall": round(float(rec), 4),
        "f1_score": round(float(f1), 4),
        "roc_auc": round(float(roc_auc), 4),
        "rmse": round(rmse, 3),
        "r2_score": round(r2, 4),
        "confusion_matrix": {
            "true_negatives": cm[0][0],
            "false_positives": cm[0][1],
            "false_negatives": cm[1][0],
            "true_positives": cm[1][1]
        },
        "feature_importances": feature_importance,
        "training_samples": len(X_train),
        "test_samples": len(X_test),
        "model_architecture": "Ensemble (RandomForestClassifier + RandomForestRegressor)",
        "disaster_rationale": "High recall (minimizing false negatives) is prioritized because failing to issue a flood evacuation alert carries catastrophic human and economic costs."
    }
    
    print(f"Flood Model Trained -> Acc: {metrics['accuracy']}, Recall: {metrics['recall']}, ROC-AUC: {metrics['roc_auc']}")
    return metrics

def train_and_evaluate_drought_model(output_dir: str):
    print("Generating drought benchmark dataset (4,500 samples)...")
    df = generate_drought_dataset(4500)
    
    feature_cols = [
        "rainfall_deficit",
        "temperature",
        "soil_moisture",
        "relative_humidity",
        "vegetation_condition",
        "historical_rainfall",
        "consecutive_dry_days"
    ]
    
    X = df[feature_cols]
    y_class = df["is_drought"]
    y_score = df["severity_score"]
    
    X_train, X_test, y_train_cls, y_test_cls, y_train_scr, y_test_scr = train_test_split(
        X, y_class, y_score, test_size=0.2, random_state=42, stratify=y_class
    )
    
    # Gradient Boosting Classifier for Drought
    clf = GradientBoostingClassifier(
        n_estimators=150,
        learning_rate=0.08,
        max_depth=5,
        random_state=42
    )
    clf.fit(X_train, y_train_cls)
    
    # Regressor for continuous drought severity score (0-100)
    reg = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )
    reg.fit(X_train, y_train_scr)
    
    # Evaluate Classifier
    y_pred_cls = clf.predict(X_test)
    y_prob_cls = clf.predict_proba(X_test)[:, 1]
    
    acc = accuracy_score(y_test_cls, y_pred_cls)
    prec = precision_score(y_test_cls, y_pred_cls)
    rec = recall_score(y_test_cls, y_pred_cls)
    f1 = f1_score(y_test_cls, y_pred_cls)
    roc_auc = roc_auc_score(y_test_cls, y_prob_cls)
    cm = confusion_matrix(y_test_cls, y_pred_cls).tolist()
    
    # Evaluate Regressor
    y_pred_scr = reg.predict(X_test)
    rmse = float(np.sqrt(mean_squared_error(y_test_scr, y_pred_scr)))
    r2 = float(r2_score(y_test_scr, y_pred_scr))
    
    # Feature importances
    feature_importance = {
        col: float(imp) for col, imp in zip(feature_cols, clf.feature_importances_)
    }
    feature_importance = dict(sorted(feature_importance.items(), key=lambda item: item[1], reverse=True))
    
    model_bundle = {
        "classifier": clf,
        "regressor": reg,
        "feature_cols": feature_cols
    }
    
    joblib.dump(model_bundle, os.path.join(output_dir, "drought_model.joblib"))
    
    metrics = {
        "accuracy": round(float(acc), 4),
        "precision": round(float(prec), 4),
        "recall": round(float(rec), 4),
        "f1_score": round(float(f1), 4),
        "roc_auc": round(float(roc_auc), 4),
        "rmse": round(rmse, 3),
        "r2_score": round(r2, 4),
        "confusion_matrix": {
            "true_negatives": cm[0][0],
            "false_positives": cm[0][1],
            "false_negatives": cm[1][0],
            "true_positives": cm[1][1]
        },
        "feature_importances": feature_importance,
        "training_samples": len(X_train),
        "test_samples": len(X_test),
        "model_architecture": "GradientBoostingClassifier + RandomForestRegressor",
        "disaster_rationale": "Balanced recall and precision ensures agricultural credit, water rationing, and crop insurance triggers activate in time without exhausting contingent relief funds."
    }
    
    print(f"Drought Model Trained -> Acc: {metrics['accuracy']}, Recall: {metrics['recall']}, ROC-AUC: {metrics['roc_auc']}")
    return metrics

def run_training_pipeline():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    models_dir = os.path.abspath(os.path.join(current_dir, "../../../models"))
    data_dir = os.path.abspath(os.path.join(current_dir, "../../../data"))
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(data_dir, exist_ok=True)
    
    flood_metrics = train_and_evaluate_flood_model(models_dir)
    drought_metrics = train_and_evaluate_drought_model(models_dir)
    
    metadata = {
        "system": "AquaSentinel AI",
        "version": "1.0.0-hackathon-release",
        "pipeline": "Scikit-learn Hydrometeorological Risk Predictor",
        "flood_model": flood_metrics,
        "drought_model": drought_metrics,
        "evaluation_dataset_note": "Evaluated on physically calibrated benchmark test set with 20% holdout split. Metrics indicate algorithmic stability on physical runoff and evapotranspiration equations.",
        "responsible_ai_statement": "Predictions must be utilized as an advisory decision-support tool. For official disaster evacuations, align with district disaster management authority (DDMA / NDMA / CWC) protocols."
    }
    
    metadata_path = os.path.join(models_dir, "model_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)
        
    print(f"All models & metadata successfully written to {models_dir}")

if __name__ == "__main__":
    run_training_pipeline()

