"""
AquaSentinel AI - Flood Prediction Inference Engine
Executes ML inference using trained ensemble models, calls the XAI explainability
engine, and attaches persona-tailored actionable recommendations.
"""

import os
import uuid
import datetime
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any

from backend.app.schemas.models import (
    FloodPredictionRequest,
    FloodPredictionResponse
)
from backend.app.ml.explainability import explain_flood_prediction
from backend.app.ml.recommendations import get_flood_recommendations

class FloodPredictor:
    def __init__(self):
        self.model = None
        self.feature_cols = [
            "rainfall_intensity",
            "rainfall_24h",
            "rainfall_7d",
            "river_water_level",
            "soil_moisture",
            "temperature",
            "elevation",
            "drainage_condition",
            "historical_flood_occurrence"
        ]
        self.base_importances = {
            "rainfall_24h": 0.28,
            "soil_moisture": 0.20,
            "river_water_level": 0.18,
            "rainfall_intensity": 0.12,
            "elevation": 0.10,
            "drainage_condition": 0.08,
            "historical_flood_occurrence": 0.04
        }
        self._load_model()

    def _load_model(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.abspath(os.path.join(current_dir, "../../../models/flood_model.joblib"))
        if os.path.exists(model_path):
            try:
                bundle = joblib.load(model_path)
                self.model = bundle
                if hasattr(bundle["classifier"], "feature_importances_"):
                    self.base_importances = {
                        c: float(imp) for c, imp in zip(self.feature_cols, bundle["classifier"].feature_importances_)
                    }
                print(f"Loaded trained Flood Model from {model_path}")
            except Exception as e:
                print(f"Warning: Failed to load flood model from {model_path}: {e}")

    def predict(self, req: FloodPredictionRequest) -> FloodPredictionResponse:
        # Resolve user requested parameters
        drainage_val = req.drainage_condition if req.drainage_condition is not None else 1
        if req.drainage_facility:
            df_lower = req.drainage_facility.lower()
            if "poor" in df_lower or "clogged" in df_lower or "inadequate" in df_lower:
                drainage_val = 0
            elif "good" in df_lower or "engineered" in df_lower or "adequate" in df_lower:
                drainage_val = 2
            else:
                drainage_val = 1

        days_rain = req.no_of_days_rain if req.no_of_days_rain is not None else 3
        rainfall_7d = req.rainfall_7d if req.rainfall_7d is not None else (req.rainfall_24h * max(1.2, float(days_rain) * 0.75))
        soil_moisture = req.soil_moisture if req.soil_moisture is not None else min(100.0, 50.0 + days_rain * 5.0)
        elevation = req.elevation if req.elevation is not None else 45.0
        intensity = req.rainfall_intensity if req.rainfall_intensity is not None else max(5.0, req.rainfall_24h / 8.0)
        irrigation = req.irrigation_facility or "Canal"
        drainage_str = req.drainage_facility or ("Poor" if drainage_val == 0 else "Good" if drainage_val == 2 else "Moderate")

        inputs_dict = {
            "rainfall_intensity": intensity,
            "rainfall_24h": req.rainfall_24h,
            "rainfall_7d": rainfall_7d,
            "river_water_level": req.river_water_level,
            "soil_moisture": soil_moisture,
            "temperature": req.temperature if req.temperature is not None else 28.0,
            "elevation": elevation,
            "drainage_condition": drainage_val,
            "historical_flood_occurrence": req.historical_flood_occurrence or 2,
            "no_of_days_rain": days_rain,
            "drainage_facility": drainage_str,
            "irrigation_facility": irrigation
        }

        # Check if ML model is active
        if self.model and "classifier" in self.model and "regressor" in self.model:
            df_in = pd.DataFrame([{k: inputs_dict[k] for k in self.feature_cols}])[self.feature_cols]
            clf = self.model["classifier"]
            reg = self.model["regressor"]
            
            prob = float(clf.predict_proba(df_in)[0, 1])
            raw_score = float(reg.predict(df_in)[0])
            risk_score = raw_score
        else:
            # Physical fallback heuristic
            elev_fact = max(0.2, (200.0 - min(elevation, 200.0)) / 200.0)
            drain_penalty = 1.35 if drainage_val == 0 else (1.0 if drainage_val == 1 else 0.7)
            raw_score = (
                (req.rainfall_24h / 200.0) * 35.0 * drain_penalty +
                (soil_moisture / 100.0) * 25.0 +
                (req.river_water_level / 20.0) * 20.0 +
                (intensity / 60.0) * 10.0 +
                elev_fact * 10.0
            )
            risk_score = raw_score
            prob = float(1.0 / (1.0 + np.exp(-(risk_score - 50.0) / 10.0)))

        # Fine-tune with days of rain, drainage, and irrigation
        if days_rain >= 5:
            risk_score += min(15.0, (days_rain - 3) * 2.5)
        elif days_rain <= 1 and req.rainfall_24h < 40:
            risk_score -= 8.0

        if drainage_val == 0:
            risk_score += 8.0
        elif drainage_val == 2:
            risk_score -= 8.0

        if "canal" in irrigation.lower() and req.river_water_level >= 13.0:
            risk_score += 5.0
        elif "pond" in irrigation.lower() or "check dam" in irrigation.lower():
            risk_score -= 4.0

        risk_score = float(np.clip(risk_score, 0.0, 100.0))
        prob = float(np.clip(1.0 / (1.0 + np.exp(-(risk_score - 48.0) / 10.0)), 0.01, 0.99))

        # Assign risk category
        if risk_score >= 90.0:
            category = "Critical"
            confidence = "Very High (Multi-Factor Saturation)"
        elif risk_score >= 75.0:
            category = "Severe"
            confidence = "High (Hydrological Thresholds Breached)"
        elif risk_score >= 50.0:
            category = "High"
            confidence = "Moderate-High (Runoff Accumulation Likely)"
        elif risk_score >= 25.0:
            category = "Moderate"
            confidence = "Moderate (Vigilance Advised)"
        else:
            category = "Low"
            confidence = "High (Parameters Within Normal Limits)"

        # Generate XAI Contributions and Plain-English Explanations
        contributions, plain_reasons = explain_flood_prediction(
            inputs_dict, self.base_importances, risk_score
        )
        plain_reasons.insert(0, f"AI Flood Prediction: {prob*100:.1f}% chance of flood based on {req.rainfall_24h:.1f} mm rain over {days_rain} day(s), river flow at {req.river_water_level:.1f} m, {drainage_str} drainage, and {irrigation} irrigation system.")

        # Generate Persona Recommendations
        recommendations = get_flood_recommendations(category, inputs_dict)

        pred_id = f"fld_{uuid.uuid4().hex[:8]}"
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

        return FloodPredictionResponse(
            prediction_id=pred_id,
            location_name=req.location_name or "Custom Assessment Point",
            flood_probability=round(prob, 4),
            risk_score=round(risk_score, 1),
            risk_category=category,
            confidence_level=confidence,
            contributing_factors=contributions,
            plain_english_explanation=plain_reasons,
            recommendations=recommendations,
            timestamp=timestamp,
            is_demo=False
        )

# Global singleton
flood_predictor_instance = FloodPredictor()

