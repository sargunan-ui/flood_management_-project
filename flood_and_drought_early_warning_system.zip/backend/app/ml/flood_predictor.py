"""
AquaSentinel AI - Flood Prediction Inference Engine
Executes ML inference using trained ensemble models, calls the XAI explainability
engine, and attaches persona-tailored actionable recommendations.
"""

import os
import uuid
import datetime
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any

from backend.app.schemas.models import (
    FloodPredictionRequest,
    FloodPredictionResponse
)
from backend.app.ml.explainability import explain_flood_prediction
from backend.app.ml.recommendations import get_flood_recommendations

class FloodPredictor:
    def __init__(self):
        self.model = None
        self.feature_cols = [
            "rainfall_intensity",
            "rainfall_24h",
            "rainfall_7d",
            "river_water_level",
            "soil_moisture",
            "temperature",
            "elevation",
            "drainage_condition",
            "historical_flood_occurrence"
        ]
        self.base_importances = {
            "rainfall_24h": 0.28,
            "soil_moisture": 0.20,
            "river_water_level": 0.18,
            "rainfall_intensity": 0.12,
            "elevation": 0.10,
            "drainage_condition": 0.08,
            "historical_flood_occurrence": 0.04
        }
        self._load_model()

    def _load_model(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.abspath(os.path.join(current_dir, "../../../models/flood_model.joblib"))
        if os.path.exists(model_path):
            try:
                bundle = joblib.load(model_path)
                self.model = bundle
                if hasattr(bundle["classifier"], "feature_importances_"):
                    self.base_importances = {
                        c: float(imp) for c, imp in zip(self.feature_cols, bundle["classifier"].feature_importances_)
                    }
                print(f"Loaded trained Flood Model from {model_path}")
            except Exception as e:
                print(f"Warning: Failed to load flood model from {model_path}: {e}")

    def predict(self, req: FloodPredictionRequest) -> FloodPredictionResponse:
        inputs_dict = {
            "rainfall_intensity": req.rainfall_intensity,
            "rainfall_24h": req.rainfall_24h,
            "rainfall_7d": req.rainfall_7d,
            "river_water_level": req.river_water_level,
            "soil_moisture": req.soil_moisture,
            "temperature": req.temperature,
            "elevation": req.elevation,
            "drainage_condition": req.drainage_condition,
            "historical_flood_occurrence": req.historical_flood_occurrence
        }

        # Check if ML model is active
        if self.model and "classifier" in self.model and "regressor" in self.model:
            df_in = pd.DataFrame([inputs_dict])[self.feature_cols]
            clf = self.model["classifier"]
            reg = self.model["regressor"]
            
            prob = float(clf.predict_proba(df_in)[0, 1])
            raw_score = float(reg.predict(df_in)[0])
            risk_score = float(np.clip(raw_score, 0.0, 100.0))
        else:
            # Physical fallback heuristic
            elev_fact = max(0.2, (200.0 - min(req.elevation, 200.0)) / 200.0)
            drain_penalty = 1.3 if req.drainage_condition == 0 else (1.0 if req.drainage_condition == 1 else 0.7)
            raw_score = (
                (req.rainfall_24h / 200.0) * 35.0 * drain_penalty +
                (req.soil_moisture / 100.0) * 25.0 +
                (req.river_water_level / 20.0) * 20.0 +
                (req.rainfall_intensity / 60.0) * 10.0 +
                elev_fact * 10.0
            )
            risk_score = float(np.clip(raw_score, 0.0, 100.0))
            prob = float(1.0 / (1.0 + np.exp(-(risk_score - 50.0) / 10.0)))

        # Assign risk category
        if risk_score >= 90.0:
            category = "Critical"
            confidence = "Very High (Multi-Factor Saturation)"
        elif risk_score >= 75.0:
            category = "Severe"
            confidence = "High (Hydrological Thresholds Breached)"
        elif risk_score >= 50.0:
            category = "High"
            confidence = "Moderate-High (Runoff Accumulation Likely)"
        elif risk_score >= 25.0:
            category = "Moderate"
            confidence = "Moderate (Vigilance Advised)"
        else:
            category = "Low"
            confidence = "High (Parameters Within Normal Limits)"

        # Generate XAI Contributions and Plain-English Explanations
        contributions, plain_reasons = explain_flood_prediction(
            inputs_dict, self.base_importances, risk_score
        )

        # Generate Persona Recommendations
        recommendations = get_flood_recommendations(category, inputs_dict)

        pred_id = f"fld_{uuid.uuid4().hex[:8]}"
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

        return FloodPredictionResponse(
            prediction_id=pred_id,
            location_name=req.location_name or "Custom Assessment Point",
            flood_probability=round(prob, 4),
            risk_score=round(risk_score, 1),
            risk_category=category,
            confidence_level=confidence,
            contributing_factors=contributions,
            plain_english_explanation=plain_reasons,
            recommendations=recommendations,
            timestamp=timestamp,
            is_demo=False
        )

# Global singleton
flood_predictor_instance = FloodPredictor()

