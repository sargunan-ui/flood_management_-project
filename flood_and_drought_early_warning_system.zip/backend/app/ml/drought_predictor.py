"""
AquaSentinel AI - Drought Prediction Inference Engine
Executes ML inference using trained ensemble models, calls the XAI explainability
engine, and attaches agricultural and water management recommendations.
"""

import os
import uuid
import datetime
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any

from backend.app.schemas.models import (
    DroughtPredictionRequest,
    DroughtPredictionResponse
)
from backend.app.ml.explainability import explain_drought_prediction
from backend.app.ml.recommendations import get_drought_recommendations

class DroughtPredictor:
    def __init__(self):
        self.model = None
        self.feature_cols = [
            "rainfall_deficit",
            "temperature",
            "soil_moisture",
            "relative_humidity",
            "vegetation_condition",
            "historical_rainfall",
            "consecutive_dry_days"
        ]
        self.base_importances = {
            "rainfall_deficit": 0.32,
            "consecutive_dry_days": 0.22,
            "soil_moisture": 0.20,
            "temperature": 0.14,
            "vegetation_condition": 0.12
        }
        self._load_model()

    def _load_model(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.abspath(os.path.join(current_dir, "../../../models/drought_model.joblib"))
        if os.path.exists(model_path):
            try:
                bundle = joblib.load(model_path)
                self.model = bundle
                if hasattr(bundle["classifier"], "feature_importances_"):
                    self.base_importances = {
                        c: float(imp) for c, imp in zip(self.feature_cols, bundle["classifier"].feature_importances_)
                    }
                print(f"Loaded trained Drought Model from {model_path}")
            except Exception as e:
                print(f"Warning: Failed to load drought model from {model_path}: {e}")

    def predict(self, req: DroughtPredictionRequest) -> DroughtPredictionResponse:
        inputs_dict = {
            "rainfall_deficit": req.rainfall_deficit,
            "temperature": req.temperature,
            "soil_moisture": req.soil_moisture,
            "relative_humidity": req.relative_humidity,
            "vegetation_condition": req.vegetation_condition,
            "historical_rainfall": req.historical_rainfall,
            "consecutive_dry_days": req.consecutive_dry_days
        }

        if self.model and "classifier" in self.model and "regressor" in self.model:
            df_in = pd.DataFrame([inputs_dict])[self.feature_cols]
            clf = self.model["classifier"]
            reg = self.model["regressor"]
            
            prob = float(clf.predict_proba(df_in)[0, 1])
            raw_score = float(reg.predict(df_in)[0])
            severity_score = float(np.clip(raw_score, 0.0, 100.0))
        else:
            # Fallback heuristic
            raw_score = (
                (req.rainfall_deficit / 100.0) * 35.0 +
                (min(req.consecutive_dry_days, 60) / 60.0) * 25.0 +
                (max(0.0, 40.0 - req.soil_moisture) / 40.0) * 20.0 +
                (max(0.0, req.temperature - 30.0) / 15.0) * 10.0 +
                (max(0.0, 50.0 - req.vegetation_condition) / 50.0) * 10.0
            )
            severity_score = float(np.clip(raw_score, 0.0, 100.0))
            prob = float(1.0 / (1.0 + np.exp(-(severity_score - 48.0) / 11.0)))

        if severity_score >= 90.0:
            category = "Critical"
            confidence = "Very High (Severe Agrarian & Hydrological Drought)"
        elif severity_score >= 75.0:
            category = "Severe"
            confidence = "High (Acute Moisture Deficit & Vegetative Wilting)"
        elif severity_score >= 50.0:
            category = "High"
            confidence = "Moderate-High (Deficit Stress Emerging)"
        elif severity_score >= 25.0:
            category = "Moderate"
            confidence = "Moderate (Mild Seasonal Dry Spell)"
        else:
            category = "Low"
            confidence = "High (Adequate Soil Moisture & Normal Rainfall)"

        contributions, plain_reasons = explain_drought_prediction(
            inputs_dict, self.base_importances, severity_score
        )

        recommendations = get_drought_recommendations(category, inputs_dict)

        pred_id = f"drt_{uuid.uuid4().hex[:8]}"
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

        return DroughtPredictionResponse(
            prediction_id=pred_id,
            location_name=req.location_name or "Custom Assessment Point",
            drought_probability=round(prob, 4),
            severity_score=round(severity_score, 1),
            drought_category=category,
            confidence_level=confidence,
            contributing_factors=contributions,
            plain_english_explanation=plain_reasons,
            agricultural_recommendations=recommendations,
            timestamp=timestamp,
            is_demo=False
        )

# Global singleton
drought_predictor_instance = DroughtPredictor()

