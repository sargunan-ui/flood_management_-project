"""
AquaSentinel AI - Drought Prediction Inference Engine
Executes ML inference using trained ensemble models, calls the XAI explainability
engine, and attaches agricultural and water management recommendations.
"""

import os
import uuid
import datetime
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any

from backend.app.schemas.models import (
    DroughtPredictionRequest,
    DroughtPredictionResponse
)
from backend.app.ml.explainability import explain_drought_prediction
from backend.app.ml.recommendations import get_drought_recommendations

class DroughtPredictor:
    def __init__(self):
        self.model = None
        self.feature_cols = [
            "rainfall_deficit",
            "temperature",
            "soil_moisture",
            "relative_humidity",
            "vegetation_condition",
            "historical_rainfall",
            "consecutive_dry_days"
        ]
        self.base_importances = {
            "rainfall_deficit": 0.32,
            "consecutive_dry_days": 0.22,
            "soil_moisture": 0.20,
            "temperature": 0.14,
            "vegetation_condition": 0.12
        }
        self._load_model()

    def _load_model(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.abspath(os.path.join(current_dir, "../../../models/drought_model.joblib"))
        if os.path.exists(model_path):
            try:
                bundle = joblib.load(model_path)
                self.model = bundle
                if hasattr(bundle["classifier"], "feature_importances_"):
                    self.base_importances = {
                        c: float(imp) for c, imp in zip(self.feature_cols, bundle["classifier"].feature_importances_)
                    }
                print(f"Loaded trained Drought Model from {model_path}")
            except Exception as e:
                print(f"Warning: Failed to load drought model from {model_path}: {e}")

    def predict(self, req: DroughtPredictionRequest) -> DroughtPredictionResponse:
        # Resolve inputs
        historical_rf = req.historical_rainfall if req.historical_rainfall is not None else 650.0
        
        # Resolve rainfall & deficit
        if req.rainfall_deficit is not None:
            deficit = req.rainfall_deficit
        elif req.rainfall_24h is not None:
            deficit = float(np.clip(100.0 - (req.rainfall_24h / 40.0) * 50.0, 0.0, 100.0))
        else:
            deficit = 45.0

        # Resolve days of rain -> dry days
        days_rain = req.no_of_days_rain if req.no_of_days_rain is not None else 3
        if req.consecutive_dry_days is not None:
            dry_days = req.consecutive_dry_days
        else:
            dry_days = max(2, 40 - days_rain * 4)

        # Resolve river flow
        river_lvl = req.river_water_level if req.river_water_level is not None else 5.0

        irrigation = req.irrigation_facility or "Rainfed"
        drainage = req.drainage_facility or "Moderate"
        soil_moisture = req.soil_moisture if req.soil_moisture is not None else max(5.0, 45.0 - dry_days * 0.6)
        temp = req.temperature if req.temperature is not None else 35.0
        rh = req.relative_humidity if req.relative_humidity is not None else 35.0
        vc = req.vegetation_condition if req.vegetation_condition is not None else max(10.0, 60.0 - deficit * 0.5)

        rain_val = req.rainfall_24h if req.rainfall_24h is not None else round(historical_rf * max(0.05, 1.0 - deficit/100.0) / 12.0, 1)

        inputs_dict = {
            "rainfall_deficit": deficit,
            "temperature": temp,
            "soil_moisture": soil_moisture,
            "relative_humidity": rh,
            "vegetation_condition": vc,
            "historical_rainfall": historical_rf,
            "consecutive_dry_days": dry_days,
            "rain": rain_val,
            "river_flow": river_lvl,
            "no_of_days_rain": days_rain,
            "irrigation_facility": irrigation,
            "drainage_facility": drainage
        }

        if self.model and "classifier" in self.model and "regressor" in self.model:
            df_in = pd.DataFrame([{k: inputs_dict[k] for k in self.feature_cols}])[self.feature_cols]
            clf = self.model["classifier"]
            reg = self.model["regressor"]
            
            prob = float(clf.predict_proba(df_in)[0, 1])
            raw_score = float(reg.predict(df_in)[0])
            severity_score = raw_score
        else:
            # Fallback heuristic
            raw_score = (
                (deficit / 100.0) * 35.0 +
                (min(dry_days, 60) / 60.0) * 25.0 +
                (max(0.0, 40.0 - soil_moisture) / 40.0) * 20.0 +
                (max(0.0, temp - 30.0) / 15.0) * 10.0 +
                (max(0.0, 50.0 - vc) / 50.0) * 10.0
            )
            severity_score = raw_score
            prob = float(1.0 / (1.0 + np.exp(-(severity_score - 48.0) / 11.0)))

        # Fine-tune with user parameters
        if river_lvl <= 3.0:
            severity_score += max(0.0, (3.0 - river_lvl) * 3.5)

        if "drip" in irrigation.lower() or "micro" in irrigation.lower():
            severity_score -= 16.0
        elif "canal" in irrigation.lower():
            severity_score -= 8.0
        elif "pond" in irrigation.lower() or "check dam" in irrigation.lower():
            severity_score -= 10.0
        elif "rainfed" in irrigation.lower():
            severity_score += 10.0

        if "good" in drainage.lower() or "recharge" in drainage.lower():
            severity_score -= 6.0
        elif "poor" in drainage.lower() or "rapid" in drainage.lower():
            severity_score += 6.0

        severity_score = float(np.clip(severity_score, 0.0, 100.0))
        prob = float(np.clip(1.0 / (1.0 + np.exp(-(severity_score - 48.0) / 10.0)), 0.01, 0.99))

        if severity_score >= 90.0:
            category = "Critical"
            confidence = "Very High (Severe Agrarian & Hydrological Drought)"
        elif severity_score >= 75.0:
            category = "Severe"
            confidence = "High (Acute Moisture Deficit & Vegetative Wilting)"
        elif severity_score >= 50.0:
            category = "High"
            confidence = "Moderate-High (Deficit Stress Emerging)"
        elif severity_score >= 25.0:
            category = "Moderate"
            confidence = "Moderate (Mild Seasonal Dry Spell)"
        else:
            category = "Low"
            confidence = "High (Adequate Soil Moisture & Normal Rainfall)"

        contributions, plain_reasons = explain_drought_prediction(
            inputs_dict, self.base_importances, severity_score
        )
        plain_reasons.insert(0, f"AI Drought Prediction: {prob*100:.1f}% chance of drought based on rainfall ({rain_val} mm), river flow at {river_lvl:.1f} m, {days_rain} day(s) of rain, {drainage} drainage/retention condition, and {irrigation} irrigation system.")

        recommendations = get_drought_recommendations(category, inputs_dict)

        pred_id = f"drt_{uuid.uuid4().hex[:8]}"
        timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()

        return DroughtPredictionResponse(
            prediction_id=pred_id,
            location_name=req.location_name or "Custom Assessment Point",
            drought_probability=round(prob, 4),
            severity_score=round(severity_score, 1),
            drought_category=category,
            confidence_level=confidence,
            contributing_factors=contributions,
            plain_english_explanation=plain_reasons,
            agricultural_recommendations=recommendations,
            timestamp=timestamp,
            is_demo=False
        )

# Global singleton
drought_predictor_instance = DroughtPredictor()

