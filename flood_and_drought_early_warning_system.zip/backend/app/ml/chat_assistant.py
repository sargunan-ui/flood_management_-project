"""
AquaSentinel AI - Aqua AI Conversational Disaster Assistant Engine
Connects to Google Gemini API or OpenAI API when configured,
or utilizes the context-aware Aqua AI Built-in Disaster Safety Engine.
"""

import os
import json
import httpx
from typing import Dict, Any, List, Optional

AQUA_AI_SYSTEM_PROMPT = """You are Aqua AI, a disaster preparedness and environmental safety assistant for AquaSentinel AI.

You help ordinary citizens, farmers, and disaster management personnel understand flood risk, drought risk, environmental conditions, and disaster preparedness.

Explain information using simple English.
Give short, practical, easy-to-understand answers.
Avoid unnecessary technical theory.
Provide step-by-step safety instructions when requested.
Use the user's selected location and available environmental information when relevant.
Do not invent current weather, river levels, flood warnings, government alerts, or disaster information.
If live data is unavailable, clearly state that it is unavailable.
Never claim that you are an official government emergency service.
Do not provide dangerous instructions.
For emergency situations, prioritize personal safety and recommend following verified local authorities and emergency services.
If users report immediate danger, advise them to contact the appropriate local emergency service (112 / 1070 / 1077) and move to safety when instructed by authorities."""

def generate_local_safety_response(message: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    Context-aware deterministic safety engine for Aqua AI when no external LLM API key is present.
    Provides verified, step-by-step emergency guidance using actual district parameters.
    """
    msg = message.lower().strip()
    dist_name = context.get("district_name", "your area") if context else "your area"
    state_name = context.get("state", "India") if context else "India"
    flood_score = context.get("flood_risk_score", 0.0) if context else 0.0
    drought_score = context.get("drought_risk_score", 0.0) if context else 0.0
    flood_cat = context.get("flood_category", "Moderate") if context else "Moderate"
    drought_cat = context.get("drought_category", "Low") if context else "Low"
    rainfall = context.get("rainfall_24h", None) if context else None
    river_level = context.get("river_level", None) if context else None

    # 1. Flood risk inquiry for current location
    if any(k in msg for k in ["flood", "flooding", "waterlogging", "submerged"]) and any(k in msg for k in ["my area", "risk", "why", "current", "situation", "status", "high", "danger", "district"]):
        response = f"In **{dist_name}, {state_name}**, the flood risk level is currently evaluated as **{flood_cat.upper()}** (Score: {flood_score}/100).\n\n"
        if rainfall is not None:
            response += f"- **Recent Rainfall:** {rainfall} mm recorded in the past 24 hours.\n"
        if river_level is not None:
            response += f"- **River Level:** {river_level} meters recorded at the nearest monitoring station.\n\n"
            
        if flood_score >= 75.0:
            response += "**Immediate Safety Advice:**\n"
            response += "1. Move to higher ground or upper floors immediately if advised by local administration.\n"
            response += "2. Keep drinking water and essential medicines in a waterproof bag.\n"
            response += "3. Avoid walking or driving through flooded roads or culverts.\n"
            response += "4. In an emergency, dial **112** for State Disaster Response."
        else:
            response += "**Current Advice:** The situation is currently under normal watch. Continue monitoring local weather bulletins and keep drains around your premises clear."
        return response

    # 2. What to do during a flood
    if "during" in msg and "flood" in msg:
        return (
            "**Key Steps During a Flood:**\n\n"
            "1. **Move to Higher Ground:** Follow evacuation alerts from local authorities without delay.\n"
            "2. **Stay Away from Floodwater:** Never walk or drive through moving water. Just 15 cm of fast-moving water can knock an adult down.\n"
            "3. **Avoid Electricity:** Stay clear of downed power cables, electric poles, and submerged wiring.\n"
            "4. **Drink Safe Water:** Drink only boiled or chlorinated water. Contaminated floodwater carries waterborne diseases.\n"
            "5. **Protect the Vulnerable:** Assist elderly relatives, children, and persons with disabilities.\n"
            "6. **Emergency Contacts:** If trapped, call **112** (National Emergency) or **1077** (District Disaster Control Room)."
        )

    # 3. Emergency kit preparation
    if any(k in msg for k in ["emergency kit", "go-bag", "prepare kit", "supplies", "kit", "bag"]):
        return (
            "**Essential Family Emergency Kit Checklist:**\n\n"
            "1. **Clean Water:** At least 3 liters of potable drinking water per person per day (3-day minimum supply).\n"
            "2. **Dry Food:** Non-perishable, ready-to-eat items (roasted gram, biscuits, dried fruits, energy bars).\n"
            "3. **Documents:** Identity cards (Aadhaar, Voter ID), land titles, and ration cards sealed in a waterproof ziplock pouch.\n"
            "4. **Medicine:** Prescription medicines for 7 days, ORS sachets, antiseptic lotion, and bandages.\n"
            "5. **Light & Power:** Battery-powered flashlight, extra alkaline batteries, and a charged mobile power bank.\n"
            "6. **Communication:** Whistle for signaling rescue teams, battery-operated radio, and a permanent marker.\n"
            "7. **Cash:** Small denomination currency notes."
        )

    # 4. Drought advice & farmer instructions
    if any(k in msg for k in ["drought", "dry", "farmer", "crop", "irrigation", "water conservation"]):
        response = f"Regarding drought conditions in **{dist_name}, {state_name}**, the drought severity is currently categorized as **{drought_cat.upper()}** (Score: {drought_score}/100).\n\n"
        response += "**Practical Steps for Farmers:**\n"
        response += "1. **Adopt Micro-Irrigation:** Use drip or sprinkler lines during evening or dawn hours to minimize evaporative loss.\n"
        response += "2. **Apply Organic Mulching:** Cover crop rows with 5 to 8 cm of organic straw or crop residue to retain soil moisture.\n"
        response += "3. **Conserve Farm Ponds:** Clean, deepen, and desilt farm ponds and trenches ahead of next rain.\n"
        response += "4. **Consider Drought-Hardy Crops:** Plan for millets (Bajra, Ragi, Jowar) or short-duration pulses suited to moisture deficits.\n"
        response += "5. **Insurance Documentation:** Photograph standing crops to support PMFBY claims if deficit persists."
        return response

    # 5. Explaining risk map
    if any(k in msg for k in ["map", "explain map", "color", "legend", "layer"]):
        return (
            "**How to Read the AquaSentinel India Risk Map:**\n\n"
            "- **Green:** Low Risk (0–24) — Standard routine conditions.\n"
            "- **Yellow:** Moderate Risk (25–49) — Heightened vigilance required.\n"
            "- **Orange:** High Risk (50–74) — Preparedness protocols activated.\n"
            "- **Red:** Severe Risk (75–89) — Emergency teams alerted; localized hazards imminent.\n"
            "- **Dark Red:** Critical Risk (90–100) — Immediate life safety priority and active evacuation.\n\n"
            "Use the top layer selector to toggle between Flood Risk polygons, Drought Severity polygons, Combined Risk, and Major River flow lines."
        )

    # 6. Default practical safety response
    return (
        f"Hello! I am **Aqua AI**, your disaster preparedness assistant. Currently looking at **{dist_name}, {state_name}**.\n\n"
        "Here are key ways I can help:\n"
        "- Check flood risk & river warning levels for your district\n"
        "- Step-by-step flood evacuation & home safety guidance\n"
        "- Farm irrigation and drought mitigation advice\n"
        "- Emergency go-bag preparation checklist\n"
        "- Understanding map severity layers\n\n"
        "What specific emergency or weather question would you like help with?"
    )

def ask_aqua_ai(
    message: str,
    history: Optional[List[Dict[str, str]]] = None,
    context: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Coordinates AI query resolution. Uses Gemini API or OpenAI API if configured,
    or falls back safely to the local Aqua AI disaster engine.
    """
    gemini_key = os.environ.get("GEMINI_API_KEY")
    openai_key = os.environ.get("OPENAI_API_KEY")
    
    # 1. Try Gemini API if key is present
    if gemini_key:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={gemini_key}"
            
            context_str = ""
            if context:
                context_str = (
                    f"\n[CURRENT USER APPLICATION CONTEXT]\n"
                    f"- Selected District: {context.get('district_name')}, {context.get('state')}\n"
                    f"- Flood Risk Score: {context.get('flood_risk_score')}/100 ({context.get('flood_category')})\n"
                    f"- Drought Risk Score: {context.get('drought_risk_score')}/100 ({context.get('drought_category')})\n"
                    f"- Recent 24h Rainfall: {context.get('rainfall_24h')} mm\n"
                    f"- River Gauge Level: {context.get('river_level')} m\n"
                    f"- Telemetry Timestamp: {context.get('timestamp')}\n"
                )
                
            contents = []
            contents.append({
                "role": "user",
                "parts": [{"text": AQUA_AI_SYSTEM_PROMPT + "\n\n" + context_str}]
            })
            
            if history:
                for turn in history[-6:]:
                    role = "user" if turn.get("sender") == "user" else "model"
                    contents.append({
                        "role": role,
                        "parts": [{"text": turn.get("text", "")}]
                    })
                    
            contents.append({
                "role": "user",
                "parts": [{"text": message}]
            })
            
            with httpx.Client(timeout=6.0) as client:
                res = client.post(url, json={"contents": contents})
                if res.status_code == 200:
                    data = res.json()
                    candidates = data.get("candidates", [])
                    if candidates and "content" in candidates[0]:
                        parts = candidates[0]["content"].get("parts", [])
                        if parts:
                            return {
                                "reply": parts[0].get("text", "").strip(),
                                "is_live_llm": True,
                                "engine": "Google Gemini 1.5 Flash (Generative API)",
                                "status": "success"
                            }
        except Exception as e:
            print(f"Gemini API call failed, falling back to local disaster engine: {e}")

    # 2. Try OpenAI API if key is present
    if openai_key:
        try:
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {openai_key}",
                "Content-Type": "application/json"
            }
            
            context_str = ""
            if context:
                context_str = (
                    f"\n[USER APPLICATION CONTEXT]\n"
                    f"District: {context.get('district_name')}, {context.get('state')}\n"
                    f"Flood Risk: {context.get('flood_risk_score')}/100 ({context.get('flood_category')})\n"
                    f"Drought Risk: {context.get('drought_risk_score')}/100 ({context.get('drought_category')})\n"
                    f"24h Rain: {context.get('rainfall_24h')} mm\n"
                    f"River Level: {context.get('river_level')} m\n"
                )
                
            messages = [{"role": "system", "content": AQUA_AI_SYSTEM_PROMPT + "\n" + context_str}]
            if history:
                for turn in history[-6:]:
                    role = "user" if turn.get("sender") == "user" else "assistant"
                    messages.append({"role": role, "content": turn.get("text", "")})
            messages.append({"role": "user", "content": message})
            
            with httpx.Client(timeout=6.0) as client:
                res = client.post(url, headers=headers, json={"model": "gpt-4o-mini", "messages": messages, "max_tokens": 500})
                if res.status_code == 200:
                    data = res.json()
                    reply = data["choices"][0]["message"]["content"]
                    return {
                        "reply": reply.strip(),
                        "is_live_llm": True,
                        "engine": "OpenAI GPT-4o-mini (Generative API)",
                        "status": "success"
                    }
        except Exception as e:
            print(f"OpenAI API call failed, falling back to local disaster engine: {e}")

    # 3. Deterministic Local Safety Engine Fallback
    local_reply = generate_local_safety_response(message, context)
    return {
        "reply": local_reply,
        "is_live_llm": False,
        "engine": "Aqua AI Built-in Disaster Safety Engine",
        "status": "offline_mode",
        "notice": "Operating in local safety mode. For external LLM API calls, set GEMINI_API_KEY or OPENAI_API_KEY in backend environment."
    }
