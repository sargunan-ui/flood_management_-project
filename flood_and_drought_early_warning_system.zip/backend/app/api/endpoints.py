"""
AquaSentinel AI - Primary API Router & Endpoints
Implements all core REST endpoints for dashboard, ML prediction, explainability,
incident alerts, geospatial data, and Open-Meteo real-time telemetry.
"""

import os
import json
import httpx
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Query, Body, Header

from backend.app.schemas.models import (
    FloodPredictionRequest,
    FloodPredictionResponse,
    DroughtPredictionRequest,
    DroughtPredictionResponse,
    DistrictProfile,
    AlertItem,
    DashboardSummary,
    RegisterRequest,
    LoginRequest,
    AuthResponse,
    UserProfile,
    ChatRequest,
    ChatResponse
)
from backend.app.data.indian_districts import get_districts, get_district_by_id
from backend.app.data.alert_manager import alert_manager_instance
from backend.app.data.history_data import get_historical_timeline
from backend.app.data.river_data import get_river_stations
from backend.app.data.auth_manager import auth_manager_instance, verify_token
from backend.app.data.india_geojson import get_flood_geojson, get_drought_geojson, get_rivers_geojson
from backend.app.ml.flood_predictor import flood_predictor_instance
from backend.app.ml.drought_predictor import drought_predictor_instance
from backend.app.ml.chat_assistant import ask_aqua_ai

router = APIRouter(prefix="/api")

# Store in-memory prediction cache for /api/explain/{prediction_id}
PREDICTION_CACHE: Dict[str, Any] = {}

@router.get("/health")
def get_health():
    """Health check endpoint providing system status and active ML model versions."""
    models_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../models"))
    flood_loaded = flood_predictor_instance.model is not None
    drought_loaded = drought_predictor_instance.model is not None
    
    return {
        "status": "healthy",
        "system": "AquaSentinel AI",
        "version": "1.0.0-hackathon-release",
        "models": {
            "flood_model_loaded": flood_loaded,
            "drought_model_loaded": drought_loaded
        },
        "geospatial_locations_count": len(get_districts()),
        "active_alerts_count": len(alert_manager_instance.get_all(status="Active")),
        "open_meteo_live_support": True
    }

@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard_summary():
    """Returns top-level KPI metrics, hazard distribution, and high-risk hotspots."""
    districts = get_districts()
    flood_scores = [d["flood_risk_score"] for d in districts]
    drought_scores = [d["drought_risk_score"] for d in districts]

    avg_flood = sum(flood_scores) / len(flood_scores) if flood_scores else 0.0
    avg_drought = sum(drought_scores) / len(drought_scores) if drought_scores else 0.0

    high_flood = [d for d in districts if d["flood_risk_score"] >= 75.0]
    high_drought = [d for d in districts if d["drought_risk_score"] >= 75.0]

    # Critical attention list
    immediate_attention = []
    for d in districts:
        max_risk = max(d["flood_risk_score"], d["drought_risk_score"])
        if max_risk >= 80.0:
            immediate_attention.append({
                "id": d["id"],
                "name": d["name"],
                "state": d["state"],
                "primary_hazard": d["primary_hazard"],
                "risk_score": max_risk,
                "category": d["flood_category"] if d["primary_hazard"] == "Flood" else d["drought_category"],
                "alert": d["key_metrics"].get("critical_warning", "Elevated hazard threshold")
            })

    # Sort descending by risk
    immediate_attention.sort(key=lambda x: x["risk_score"], reverse=True)

    recent_alerts = [AlertItem(**a) for a in alert_manager_instance.get_all()[:6]]

    # Distribution counts
    categories = {"Low": 0, "Moderate": 0, "High": 0, "Severe": 0, "Critical": 0}
    for d in districts:
        cat = d["flood_category"] if d["primary_hazard"] == "Flood" else d["drought_category"]
        categories[cat] = categories.get(cat, 0) + 1

    return DashboardSummary(
        current_flood_risk_avg=round(avg_flood, 1),
        current_drought_risk_avg=round(avg_drought, 1),
        total_monitored_locations=len(districts),
        high_risk_flood_count=len(high_flood),
        high_risk_drought_count=len(high_drought),
        active_alerts_count=len(alert_manager_instance.get_all(status="Active")),
        immediate_attention_locations=immediate_attention[:6],
        rainfall_summary={
            "national_trend": "Monsoon withdrawal in northern states; coastal depression active",
            "highest_rainfall_point": "Wayanad, Kerala (142 mm / 24h)",
            "highest_deficit_point": "Barmer, Rajasthan (-86% seasonal deficit)"
        },
        soil_moisture_summary={
            "saturated_hotspots": ["Alappuzha (98%)", "Wayanad (94%)", "Dhemaji (89%)"],
            "parched_hotspots": ["Jaisalmer (6.8%)", "Barmer (9.5%)", "Anantapur (12.0%)"]
        },
        recent_alerts=recent_alerts,
        risk_distribution=categories
    )

@router.post("/predict/flood", response_model=FloodPredictionResponse)
def predict_flood(payload: FloodPredictionRequest):
    """Executes Flood Risk ML inference, generates XAI attribution and action guidelines."""
    res = flood_predictor_instance.predict(payload)
    PREDICTION_CACHE[res.prediction_id] = res.model_dump()
    return res

@router.post("/predict/drought", response_model=DroughtPredictionResponse)
def predict_drought(payload: DroughtPredictionRequest):
    """Executes Drought Risk ML inference, generates XAI attribution and crop advisories."""
    res = drought_predictor_instance.predict(payload)
    PREDICTION_CACHE[res.prediction_id] = res.model_dump()
    return res

@router.get("/locations")
def list_locations():
    """Returns list of monitored Indian districts with geospatial coordinates and vulnerability profiles."""
    return get_districts()

@router.get("/locations/{district_id}")
def get_location_details(district_id: str):
    """Returns granular telemetry and profile for a specific district."""
    dist = get_district_by_id(district_id)
    return dist

@router.get("/risk-map")
def get_risk_map_data(hazard_type: Optional[str] = None):
    """Returns geospatial features and markers for the Leaflet risk map."""
    districts = get_districts()
    markers = []
    
    for d in districts:
        if hazard_type and hazard_type.lower() != "all" and d["primary_hazard"].lower() != hazard_type.lower():
            continue
            
        markers.append({
            "id": d["id"],
            "name": d["name"],
            "state": d["state"],
            "lat": d["latitude"],
            "lng": d["longitude"],
            "elevation": d["elevation"],
            "hazard_type": d["primary_hazard"],
            "flood_score": d["flood_risk_score"],
            "flood_category": d["flood_category"],
            "drought_score": d["drought_risk_score"],
            "drought_category": d["drought_category"],
            "vulnerability_index": d["vulnerability_index"],
            "critical_warning": d["key_metrics"].get("critical_warning", ""),
            "key_metrics": d["key_metrics"],
            "soil_type": d.get("soil_type", "Standard Soil"),
            "river_basin": d.get("river_basin", "Local Watershed")
        })
        
    return {
        "markers": markers,
        "legend": {
            "Critical": {"color": "#ef4444", "range": "90 - 100", "action": "Immediate evacuation / emergency water"},
            "Severe": {"color": "#f97316", "range": "75 - 89", "action": "High alert / SDRF deploy / fodder rationing"},
            "High": {"color": "#eab308", "range": "50 - 74", "action": "Precautionary watch / drain clearing"},
            "Moderate": {"color": "#06b6d4", "range": "25 - 49", "action": "Routine vigilance"},
            "Low": {"color": "#10b981", "range": "0 - 24", "action": "Normal operations"}
        }
    }

@router.get("/rivers")
def get_rivers():
    """Returns river monitoring gauge stations, water levels, thresholds, and simplified status."""
    return get_river_stations()

@router.get("/alerts")
def get_alerts(status: Optional[str] = None, hazard_type: Optional[str] = None):
    """Returns active and acknowledged disaster alerts."""
    return alert_manager_instance.get_all(status=status, hazard_type=hazard_type)

@router.post("/alerts/generate")
def generate_custom_alert(payload: Dict[str, Any] = Body(...)):
    """Simulates generation of a new localized early warning alert broadcast."""
    new_alert = alert_manager_instance.create_alert(payload)
    return new_alert

@router.post("/alerts/{alert_id}/acknowledge")
def acknowledge_alert(alert_id: str, operator_name: Optional[str] = Body("District Disaster Officer", embed=True)):
    """Acknowledges an active alert, updating status with responder verification."""
    updated = alert_manager_instance.acknowledge(alert_id, operator_name)
    if not updated:
        raise HTTPException(status_code=404, detail="Alert not found")
    return updated

@router.get("/history")
def get_history(district_id: Optional[str] = Query("assam_dhemaji")):
    """Returns historical risk trajectory and disaster escalation logs for timeline graphs."""
    return get_historical_timeline(district_id)

@router.get("/explain/{prediction_id}")
def get_prediction_explanation(prediction_id: str):
    """Retrieves cached XAI feature importance breakdown and plain-English explanation."""
    if prediction_id in PREDICTION_CACHE:
        return PREDICTION_CACHE[prediction_id]
    
    # Generate generic explanation response if not found
    return {
        "prediction_id": prediction_id,
        "message": "Detailed XAI factors are generated with every prediction call. Provide valid prediction ID or re-run inference."
    }

@router.get("/model-metadata")
def get_model_metadata():
    """Returns machine learning pipeline training results, evaluation metrics, and governance notes."""
    models_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../models"))
    meta_path = os.path.join(models_dir, "model_metadata.json")
    if os.path.exists(meta_path):
        with open(meta_path, "r") as f:
            return json.load(f)
    return {
        "status": "Models running in active inference mode",
        "note": "Execute train_models.py to inspect refreshed evaluation report."
    }

@router.get("/live-weather")
async def get_live_weather(lat: float = Query(..., ge=-90, le=90), lon: float = Query(..., ge=-180, le=180)):
    """
    Fetches real-time weather and soil moisture from Open-Meteo free API (no API key required).
    Maps real-world telemetry directly into AquaSentinel input schemas.
    """
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,relative_humidity_2m,precipitation,rain,surface_pressure,wind_speed_10m&hourly=precipitation,soil_moisture_0_to_1cm,soil_moisture_1_to_3cm&daily=precipitation_sum,precipitation_hours&timezone=auto"
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                current = data.get("current", {})
                hourly = data.get("hourly", {})
                daily = data.get("daily", {})
                
                # Derive 24h rain
                rain_24h = sum(daily.get("precipitation_sum", [0])[:1]) if daily.get("precipitation_sum") else 0.0
                rain_7d = sum(daily.get("precipitation_sum", [0])[:7]) if daily.get("precipitation_sum") else rain_24h * 2.5
                
                # Derive soil moisture percentage (Open-Meteo m3/m3 to approx %)
                sm_raw = 0.35
                if hourly.get("soil_moisture_0_to_1cm") and len(hourly["soil_moisture_0_to_1cm"]) > 0:
                    sm_raw = hourly["soil_moisture_0_to_1cm"][0]
                soil_moisture_pct = min(100.0, max(5.0, sm_raw * 180.0))

                return {
                    "source": "Open-Meteo Live API",
                    "latitude": lat,
                    "longitude": lon,
                    "temperature": current.get("temperature_2m", 28.0),
                    "relative_humidity": current.get("relative_humidity_2m", 65.0),
                    "rainfall_intensity": current.get("precipitation", 0.0),
                    "rainfall_24h": round(rain_24h, 1),
                    "rainfall_7d": round(rain_7d, 1),
                    "soil_moisture": round(soil_moisture_pct, 1),
                    "wind_speed": current.get("wind_speed_10m", 10.0),
                    "is_live": True
                }
    except Exception as e:
        print(f"Open-Meteo live call fallback: {e}")
        
    # Reliable fallback if network call fails or times out
    return {
        "source": "AquaSentinel Calibrated Telemetry (Offline Fallback)",
        "latitude": lat,
        "longitude": lon,
        "temperature": 29.5,
        "relative_humidity": 68.0,
        "rainfall_intensity": 15.0,
        "rainfall_24h": 45.0,
        "rainfall_7d": 120.0,
        "soil_moisture": 72.0,
        "wind_speed": 14.0,
        "is_live": False
    }

@router.get("/compare")
def compare_districts(loc1: str = Query(...), loc2: str = Query(...)):
    """Returns side-by-side comparative vulnerability and hydrological metrics between two districts."""
    d1 = get_district_by_id(loc1)
    d2 = get_district_by_id(loc2)
    
    return {
        "district_1": d1,
        "district_2": d2,
        "comparison_highlights": [
            {
                "metric": "Primary Hazard",
                "val1": d1["primary_hazard"],
                "val2": d2["primary_hazard"]
            },
            {
                "metric": "Elevation (a.s.l.)",
                "val1": f"{d1['elevation']} m",
                "val2": f"{d2['elevation']} m",
                "difference": f"{abs(d1['elevation'] - d2['elevation']):.1f} m"
            },
            {
                "metric": "Flood Risk Score",
                "val1": d1["flood_risk_score"],
                "val2": d2["flood_risk_score"],
                "difference": f"{abs(d1['flood_risk_score'] - d2['flood_risk_score']):.1f} pts"
            },
            {
                "metric": "Drought Severity Score",
                "val1": d1["drought_risk_score"],
                "val2": d2["drought_risk_score"],
                "difference": f"{abs(d1['drought_risk_score'] - d2['drought_risk_score']):.1f} pts"
            },
            {
                "metric": "Vulnerability Index",
                "val1": d1["vulnerability_index"],
                "val2": d2["vulnerability_index"]
            }
        ]
    }

# ============================================================================
# AUTHENTICATION & ROLE-BASED ACCESS CONTROL ENDPOINTS
# ============================================================================

@router.post("/auth/register", response_model=AuthResponse)
def register(payload: RegisterRequest):
    """Registers a new citizen, farmer, official, or admin user."""
    try:
        res = auth_manager_instance.register_user(
            name=payload.name,
            email=payload.email,
            password=payload.password,
            role=payload.role,
            organization=payload.organization or "",
            location=payload.location or "",
            id_proof_type=payload.id_proof_type or "Aadhaar Card",
            id_proof_number=payload.id_proof_number or ""
        )
        return res
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/auth/login", response_model=AuthResponse)
def login(payload: LoginRequest):
    """Authenticates a user and returns a cryptographically secure token."""
    try:
        res = auth_manager_instance.authenticate_user(
            email=payload.email,
            password=payload.password
        )
        return res
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))

@router.get("/auth/me")
def get_current_user(authorization: Optional[str] = Header(None)):
    """Verifies token and returns the current user profile."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization token missing")
    token = authorization.replace("Bearer ", "").strip()
    payload = verify_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired session token")
    user = auth_manager_instance.get_user_by_id(payload["sub"])
    if not user:
        raise HTTPException(status_code=404, detail="User record not found")
    return user

@router.get("/admin/users")
def get_admin_users(authorization: Optional[str] = Header(None)):
    """Returns all registered system users (restricted to Administrator role)."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization token missing")
    token = authorization.replace("Bearer ", "").strip()
    payload = verify_token(token)
    if not payload or payload.get("role") != "Administrator":
        raise HTTPException(status_code=403, detail="Administrator role required")
    return auth_manager_instance.get_all_users()

@router.get("/admin/system-status")
def get_admin_system_status(authorization: Optional[str] = Header(None)):
    """System telemetry and diagnostic status for the Administrator dashboard."""
    if authorization:
        token = authorization.replace("Bearer ", "").strip()
        payload = verify_token(token)
        if not payload or payload.get("role") != "Administrator":
            raise HTTPException(status_code=403, detail="Administrator role required")
            
    districts = get_districts()
    return {
        "status": "Operational",
        "active_users": len(auth_manager_instance.get_all_users()),
        "monitored_districts": len(districts),
        "active_river_stations": 12,
        "ml_inference_engine": "Active (Scikit-Learn Random Forest & Gradient Boosting)",
        "open_meteo_live_telemetry": "Active (Keyless Global API)",
        "gemini_api_status": "Configured" if os.environ.get("GEMINI_API_KEY") else "Offline Safety Engine Active",
        "openai_api_status": "Configured" if os.environ.get("OPENAI_API_KEY") else "Offline Safety Engine Active",
        "last_system_health_check": "2026-11-03T05:45:00Z"
    }

# ============================================================================
# REAL GEOSPATIAL MAP & RIVER GEOJSON ENDPOINTS
# ============================================================================

@router.get("/map/flood")
def get_map_flood():
    """Returns genuine GeoJSON polygon boundaries for Indian districts styled with Flood Risk."""
    return get_flood_geojson()

@router.get("/map/drought")
def get_map_drought():
    """Returns genuine GeoJSON polygon boundaries for Indian districts styled with Drought Severity."""
    return get_drought_geojson()

@router.get("/map/rivers-geojson")
def get_map_rivers():
    """Returns authentic GeoJSON LineStrings for 9 major Indian rivers and station points."""
    return get_rivers_geojson()

@router.get("/map/combined")
def get_map_combined():
    """Returns combined hazard GeoJSON FeatureCollection."""
    flood_data = get_flood_geojson()
    drought_data = get_drought_geojson()
    
    # Merge properties
    combined_features = []
    drought_map = {f["id"]: f["properties"] for f in drought_data["features"]}
    
    for f in flood_data["features"]:
        props = dict(f["properties"])
        d_props = drought_map.get(f["id"], {})
        props["drought_risk_score"] = d_props.get("risk_score", 0.0)
        props["drought_category"] = d_props.get("risk_category", "Low")
        props["rainfall_deficit_pct"] = d_props.get("rainfall_deficit_pct", 0.0)
        props["combined_risk_score"] = max(props["risk_score"], props["drought_risk_score"])
        
        # Color based on dominant hazard
        combined_features.append({
            "type": "Feature",
            "id": f["id"],
            "geometry": f["geometry"],
            "properties": props
        })
        
    return {
        "type": "FeatureCollection",
        "name": "AquaSentinel_Combined_Hazard_Districts",
        "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
        "features": combined_features
    }

# ============================================================================
# CONVERSATIONAL AI CHATBOT (AQUA AI) ENDPOINT
# ============================================================================

@router.post("/chat", response_model=ChatResponse)
def chat_with_aqua_ai(payload: ChatRequest):
    """
    Conversational AI safety assistant endpoint.
    Invokes external LLM (Gemini/OpenAI) if API key is present in environment,
    or falls back to the context-aware Aqua AI Built-in Disaster Safety Engine.
    """
    res = ask_aqua_ai(
        message=payload.message,
        history=payload.history,
        context=payload.context
    )
    return res

# ============================================================================
# PROCEDURAL SAFETY GUIDE & LOCATION RISK ENDPOINTS
# ============================================================================

@router.get("/safety-guide")
def get_safety_guide():
    """Structured step-by-step procedures for Flood and Drought preparedness."""
    return {
        "flood": {
            "before": [
                "Monitor official weather bulletins, CWC river gauge forecasts, and AquaSentinel alerts.",
                "Prepare an emergency kit: 3 days of potable water, dry food, flashlights, and power banks.",
                "Store important identity cards, land records, and deeds in sealed waterproof pouches.",
                "Identify high-ground evacuation shelters and verified access routes.",
                "Keep mobile phones and emergency lanterns fully charged.",
                "Protect essential prescription medicines in waterproof containers.",
                "Strictly follow local administration and disaster management directives."
            ],
            "during": [
                "Move immediately to designated higher ground or elevated shelters when warned.",
                "Stay completely away from swollen rivers, flooded causeways, and storm drains.",
                "Never walk, swim, or drive through flowing water (15 cm of current can sweep a person away).",
                "Stay clear of submerged electrical installations, meter boxes, and fallen wires.",
                "Follow official evacuation instructions from NDRF, SDRF, and civil defense personnel.",
                "Prioritize children, elderly relatives, and vulnerable neighbors.",
                "Dial national emergency helpline 112 or disaster control 1070/1077 for emergency rescue."
            ],
            "after": [
                "Return home only after authorities officially declare the area safe.",
                "Have electrical wiring inspected by a certified technician before restoring power.",
                "Avoid contact with stagnating, contaminated floodwater to prevent waterborne diseases.",
                "Boil drinking water vigorously for 3 minutes or use chlorine tablets.",
                "Report broken culverts, compromised bunds, and damaged embankments immediately.",
                "Seek medical attention at your nearest primary health center for fevers or wounds."
            ]
        },
        "drought": {
            "before": [
                "Monitor weekly rainfall departure advisories and soil moisture depletion trends.",
                "Store domestic and drinking water safely in covered, sanitized storage tanks.",
                "Audit plumbing fixtures and repair leaks across household and community taps.",
                "Formulate agricultural contingency plans (drought-tolerant crops and mulching).",
                "Desilt and maintain farm ponds, check dams, and rooftop rainwater harvesting units."
            ],
            "during": {
                "citizens": [
                    "Conserve drinking water strictly; suspend lawn watering and car washing.",
                    "Follow municipal water supply rationing rosters and storage recommendations.",
                    "Reuse greywater from washing vegetables for domestic sanitation.",
                    "Keep drinking water vessels tightly covered to prevent insect breeding."
                ],
                "farmers": [
                    "Deploy drip or micro-sprinkler irrigation exclusively during early dawn or dusk.",
                    "Check soil moisture depth before scheduling irrigation cycles.",
                    "Apply 5 to 8 cm of organic straw or biomass mulching to prevent soil evaporation.",
                    "Spray 1% potassium chloride (KCl) foliar solution to induce stomatal drought tolerance.",
                    "Pivot to drought-resilient crops such as millets (Bajra, Ragi, Jowar) or pulses."
                ]
            },
            "after": [
                "Continue water conservation discipline as seasonal rains commence.",
                "Test groundwater salinity and TDS before utilizing new borewells.",
                "Document standing crop loss for Pradhan Mantri Fasal Bima Yojana (PMFBY) insurance.",
                "Adopt green manuring to replenish desiccated soil organic carbon.",
                "Deepen catchment bunds and percolation trenches to capture future monsoon run-off."
            ]
        },
        "emergency_contacts": {
            "national_emergency": "112",
            "state_disaster_management": "1070",
            "district_disaster_control": "1077",
            "ambulance": "108",
            "fire_service": "101"
        }
    }

@router.get("/location-risk")
def get_location_risk(district_id: str = Query(...)):
    """Returns immediate 5-second risk summary and recommended actions for a given district."""
    dist = get_district_by_id(district_id)
    if not dist:
        raise HTTPException(status_code=404, detail="District not found")
        
    is_flood = dist["primary_hazard"] == "Flood"
    score = dist["flood_risk_score"] if is_flood else dist["drought_risk_score"]
    category = dist["flood_category"] if is_flood else dist["drought_category"]
    
    if is_flood:
        simple_explanation = f"Flooding may occur in this area. River gauge at {dist['key_metrics'].get('river_gauge_m', 12)}m." if score >= 75 else "Current flood risk is low to moderate. Continue normal vigilance."
        actions = [
            "Store 3 days of clean drinking water and non-perishable food.",
            "Move livestock and valuable equipment to higher ground.",
            "Avoid walking or driving across submerged bridges or culverts.",
            "Keep emergency contact 112 saved on your mobile phone."
        ]
    else:
        simple_explanation = f"Rainfall has been below normal with soil moisture stress at {dist['key_metrics'].get('soil_moisture_pct', 15)}%." if score >= 75 else "No immediate severe drought concern based on seasonal data."
        actions = [
            "Conserve household drinking water and eliminate leaks.",
            "Use drip or micro-sprinkler irrigation during early morning hours.",
            "Apply straw mulching on crop rows to preserve ground moisture.",
            "Follow district agricultural extension water management advisories."
        ]
        
    return {
        "district_id": dist["id"],
        "name": dist["name"],
        "state": dist["state"],
        "primary_hazard": dist["primary_hazard"],
        "risk_score": score,
        "risk_category": category,
        "simple_explanation": simple_explanation,
        "recommended_actions": actions,
        "key_metrics": dist["key_metrics"],
        "timestamp": "Live - Telemetry synchronized"
    }
