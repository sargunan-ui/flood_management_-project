"""
AquaSentinel AI - Backend Server Entrypoint
FastAPI application serving flood & drought early warning intelligence.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.api.endpoints import router as api_router

app = FastAPI(
    title="AquaSentinel AI API",
    description="AI-Powered Flood & Drought Early Warning and Climate Resilience Platform",
    version="1.0.0-hackathon-release",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS for local development and deployment
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include main API router
app.include_router(api_router)

@app.get("/")
def root():
    return {
        "message": "Welcome to AquaSentinel AI early warning API",
        "docs": "/docs",
        "health": "/api/health",
        "dashboard": "/api/dashboard"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="0.0.0.0", port=8000, reload=True)

