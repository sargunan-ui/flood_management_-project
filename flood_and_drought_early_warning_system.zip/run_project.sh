#!/usr/bin/env bash
# AquaSentinel AI - Full Stack Launcher Script (Linux / macOS)
echo "=========================================================="
echo "   Starting AquaSentinel AI Early Warning Platform       "
echo "=========================================================="

# 1. Start Backend in background
echo "[1/2] Launching Python FastAPI Backend on port 8000..."
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!

sleep 2

# 2. Start Frontend
echo "[2/2] Launching Vite React Frontend on port 5173..."
cd frontend && npm run dev

# Trap exit to kill backend
trap "kill $BACKEND_PID" EXIT

