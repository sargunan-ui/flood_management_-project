@echo off
title AquaSentinel AI - Early Warning Platform Launcher
echo ==========================================================
echo    Starting AquaSentinel AI Early Warning Platform       
echo ==========================================================
echo.

:: Detect Python executable
set PYTHON_EXE=python
if exist "backend\.venv\Scripts\python.exe" (
    set PYTHON_EXE="backend\.venv\Scripts\python.exe"
) else if exist ".venv\Scripts\python.exe" (
    set PYTHON_EXE=".venv\Scripts\python.exe"
)

:: 1. Launch FastAPI Backend
echo [1/2] Starting Python FastAPI Backend on port 8000...
start "AquaSentinel AI - Backend (Port 8000)" %PYTHON_EXE% -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload

timeout /t 3 /nobreak >nul

:: 2. Launch Vite React Frontend
echo [2/2] Starting React Frontend on port 5173...
cd frontend
start "AquaSentinel AI - Frontend (Port 5173)" cmd /k "npm run dev"

echo.
echo ==========================================================
echo  AquaSentinel AI is running!
echo  - Frontend: http://localhost:5173
echo  - Backend API & Swagger Docs: http://localhost:8000/docs
echo ==========================================================
echo.
pause

